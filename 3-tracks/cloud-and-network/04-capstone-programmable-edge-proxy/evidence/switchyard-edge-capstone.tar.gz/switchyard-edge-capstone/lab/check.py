"""Loopback checks against the built edge executable."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from http.client import HTTPConnection
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import select
import subprocess
import threading
import time


class Origin(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 128

    def __init__(self, name):
        super().__init__(("127.0.0.1", 0), Handler)
        self.name = name
        self.sockets = 0
        self.hits = 0
        self.active = 0
        self.peak = 0
        self.status = 200
        self.hold = False
        self.changed = threading.Condition()
        self.release = threading.Event()

    @property
    def address(self):
        host, port = self.server_address
        return f"{host}:{port}"

    def get_request(self):
        pair = super().get_request()
        with self.changed:
            self.sockets += 1
        return pair

    def wait_for_hits(self, count):
        with self.changed:
            assert self.changed.wait_for(lambda: self.hits >= count, timeout=3)


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def do_GET(self):
        origin = self.server
        size = int(self.headers.get("Content-Length", 0))
        incoming = self.rfile.read(size)
        with origin.changed:
            origin.hits += 1
            origin.active += 1
            origin.peak = max(origin.peak, origin.active)
            origin.changed.notify_all()
            status = origin.status
            hold = origin.hold
        try:
            if hold:
                origin.release.wait(5)
            body = f"{origin.name} {self.path} ".encode() + incoming
            self.send_response(status)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Origin", origin.name)
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            with origin.changed:
                origin.active -= 1

    do_POST = do_GET

    def log_message(self, *_):
        pass


@contextmanager
def cluster(binary):
    with Origin("a") as a, Origin("b") as b:
        threads = [
            threading.Thread(target=origin.serve_forever, kwargs={"poll_interval": 0.05})
            for origin in (a, b)
        ]
        for thread in threads:
            thread.start()
        try:
            with subprocess.Popen(
                [binary, "http", "127.0.0.1:0", a.address, b.address],
                stdout=subprocess.PIPE,
                text=True,
            ) as proxy:
                try:
                    assert select.select([proxy.stdout], [], [], 5)[0], "proxy startup timed out"
                    line = proxy.stdout.readline()
                    assert line.startswith("listening "), line
                    port = int(line.rstrip().rsplit(":", 1)[1])
                    yield port, a, b
                finally:
                    proxy.terminate()
                    try:
                        proxy.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        proxy.kill()
                        proxy.wait()
        finally:
            for origin in (a, b):
                origin.release.set()
                origin.shutdown()
            for thread in threads:
                thread.join()


def request(port, path, body=None):
    connection = HTTPConnection("127.0.0.1", port, timeout=5)
    try:
        connection.request("POST" if body is not None else "GET", path, body)
        response = connection.getresponse()
        assert response.version == 11
        return response.status, response.read(), response.getheader("X-Origin")
    finally:
        connection.close()


def routing(port, a, b):
    path = "/a/item?raw=%2f&item=1&item=2"
    assert request(port, path, b"\x00abc") == (200, b"a " + path.encode() + b" \x00abc", "a")
    assert request(port, "/b/item") == (200, b"b /b/item ", "b")
    assert request(port, "/abc/item")[0] == 404
    assert request(port, "/a/item", b"x" * (64 * 1024 + 1))[0] == 413
    assert (a.hits, b.hits) == (1, 1)
    print("routing: HTTP/1.1, exact query and bytes, separate origins, 404 and 413")


def pool(port, a, _):
    for _ in range(12):
        assert request(port, "/a/item") == (200, b"a /a/item ", "a")
    assert a.hits == 12
    assert a.sockets < a.hits, f"pool: {a.sockets} sockets for {a.hits} requests"
    print(f"pool: {a.sockets} upstream socket for {a.hits} serial requests")


def capacity(port, a, _):
    a.hold = True
    with ThreadPoolExecutor(max_workers=32) as workers:
        jobs = [workers.submit(request, port, "/a/item") for _ in range(32)]
        a.wait_for_hits(32)
        try:
            assert request(port, "/a/item")[:2] == (503, b"origin at capacity")
            assert request(port, "/b/item") == (200, b"b /b/item ", "b")
            assert all(job.result()[0] == 504 for job in jobs)
        finally:
            a.release.set()
    assert (a.hits, a.peak) == (32, 32)
    time.sleep(2.05)
    with a.changed:
        a.hold = False
    assert request(port, "/a/item")[0] == 200
    print("capacity: 32 timed out at the stalled origin, excess got 503, other origin got 200, stalled origin recovered")


def breaker(port, a, _):
    a.status = 502
    for _ in range(3):
        assert request(port, "/a/item")[0] == 502
    observed = request(port, "/a/item")
    assert a.hits == 3, f"breaker: open request reached origin (count={a.hits})"
    assert observed[:2] == (503, b"origin circuit open")
    assert request(port, "/b/item")[0] == 200

    time.sleep(2.05)
    assert request(port, "/a/item")[0] == 502
    assert request(port, "/a/item")[0] == 503
    with a.changed:
        a.status = 200
        a.hold = True
    time.sleep(2.05)
    with ThreadPoolExecutor(max_workers=1) as workers:
        probe = workers.submit(request, port, "/a/item")
        a.wait_for_hits(5)
        try:
            assert request(port, "/a/item")[0] == 503
            assert a.hits == 5
        finally:
            a.release.set()
        assert probe.result()[0] == 200
    assert request(port, "/a/item")[0] == 200
    assert a.hits == 6
    print("breaker: open blocked origin work; failed probe reopened; single healthy probe recovered")


if __name__ == "__main__":
    checks = {check.__name__: check for check in (routing, pool, capacity, breaker,)}
    parser = argparse.ArgumentParser()
    parser.add_argument("binary")
    parser.add_argument("names", nargs="+", choices=list(checks))
    args = parser.parse_args()
    for name in args.names:
        with cluster(args.binary) as running:
            checks[name](*running)
