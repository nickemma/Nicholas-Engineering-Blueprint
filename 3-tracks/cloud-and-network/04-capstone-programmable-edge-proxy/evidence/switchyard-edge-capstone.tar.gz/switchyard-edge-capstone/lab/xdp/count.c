#include <linux/bpf.h>
#include <bpf/bpf_helpers.h>

struct {
    __uint(type, BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 1);
    __type(key, __u32);
    __type(value, __u64);
} packets SEC(".maps");

SEC("xdp")
int count_packets(struct xdp_md *ctx)
{
    __u32 key = 0;
    __u64 *counter = bpf_map_lookup_elem(&packets, &key);

    if (counter)
        __sync_fetch_and_add(counter, 1);
    return XDP_PASS;
}

char license_text[] SEC("license") = "GPL";
