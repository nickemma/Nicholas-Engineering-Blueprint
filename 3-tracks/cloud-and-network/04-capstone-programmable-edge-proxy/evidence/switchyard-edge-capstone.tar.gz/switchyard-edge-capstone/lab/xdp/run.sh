#!/usr/bin/env bash
set -euo pipefail

mount --make-rprivate /
mount -t bpf bpf /sys/fs/bpf
trap 'ip netns del client 2>/dev/null || true; umount /sys/fs/bpf' EXIT
ip netns add client
ip link add edge-lab type veth peer name client-lab
ip link set client-lab netns client
ip addr add 10.200.0.1/30 dev edge-lab
ip link set edge-lab up
ip -n client addr add 10.200.0.2/30 dev client-lab
ip -n client link set client-lab up
ip -n client link set lo up

mkdir /sys/fs/bpf/maps
bpftool prog load /lab/count.o /sys/fs/bpf/count type xdp pinmaps /sys/fs/bpf/maps
bpftool net attach xdpgeneric pinned /sys/fs/bpf/count dev edge-lab

fixture="$(mktemp)"
/work/origin origin >"$fixture" &
for (( attempt=0; attempt<50; attempt++ )); do
    if [[ -s "$fixture" ]]; then break; fi
    sleep 0.05
done
read -r origin observer <"$fixture"
/work/proxy http 10.200.0.1:8080 "$origin" 127.0.0.1:1 &
for (( attempt=0; attempt<50; attempt++ )); do
    if curl --max-time 1 --noproxy '*' -fsS http://10.200.0.1:8080/a/obj/4096/1 >/tmp/direct; then
        break
    fi
    sleep 0.05
done
test "$(wc -c </tmp/direct)" -eq 4096

packets() {
    bpftool -j map lookup pinned /sys/fs/bpf/maps/packets key hex 00 00 00 00 |
        python3 -c '
import json, sys
row = json.load(sys.stdin)
value = row["value"]
print(int.from_bytes(bytes(int(part, 16) for part in value), sys.byteorder) if isinstance(value, list) else value)
'
}
requests() {
    curl --max-time 1 --noproxy '*' -fsS "http://$observer/stats" |
        python3 -c 'import json, sys; print(json.load(sys.stdin)["requests"])'
}
before="$(packets)"
origin_before="$(requests)"
for (( request=0; request<5; request++ )); do
    ip netns exec client curl --max-time 2 --noproxy '*' -fsS \
        http://10.200.0.1:8080/a/obj/4096/1 -o /tmp/forwarded
    cmp /tmp/direct /tmp/forwarded
done
after="$(packets)"
origin_after="$(requests)"
test "$after" -gt "$before"
test "$((origin_after - origin_before))" -eq 5
printf 'kernel=%s interface=edge-lab mode=xdpgeneric packets=%s..%s origin_requests=%s..%s\n' \
    "$(uname -r)" "$before" "$after" "$origin_before" "$origin_after"
