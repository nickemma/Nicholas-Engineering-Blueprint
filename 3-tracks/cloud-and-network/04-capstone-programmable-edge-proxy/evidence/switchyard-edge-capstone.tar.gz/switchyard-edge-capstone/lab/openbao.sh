#!/usr/bin/env bash
set -euo pipefail

token="$(openssl rand -hex 24)"
name="switchyard-bao-$(openssl rand -hex 6)"
image=openbao/openbao:2.7.1
docker run --detach --rm --name "$name" --publish 127.0.0.1::8200 \
    --env BAO_DEV_ROOT_TOKEN_ID="$token" "$image" server -dev -dev-listen-address=0.0.0.0:8200 >/dev/null
trap 'docker rm -f "$name" >/dev/null 2>&1 || true' EXIT
address="$(docker port "$name" 8200/tcp)"
for (( attempt=0; attempt<50; attempt++ )); do
    if curl --noproxy '*' -fsS --max-time 1 "http://$address/v1/sys/health" >/dev/null 2>&1; then
        EDGE_BAO_ROOT="$token" EDGE_BAO_ADDRESS="$address" go test -count=1 -v ./control -run '^TestOpenBao$'
        exit
    fi
    sleep 0.2
done
echo "OpenBao dev fixture did not become healthy" >&2
exit 1
