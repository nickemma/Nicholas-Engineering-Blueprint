package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net"
	"os"
	"strconv"
	"time"

	"switchyard/edge/control"
)

func main() {
	if err := run(os.Args[1:]); err != nil {
		log.Fatal(err)
	}
}

func run(args []string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Second)
	defer cancel()
	if len(args) == 5 && args[0] == "sidecar" {
		config, err := control.ServerTLS(args[3], args[4])
		if err != nil {
			return err
		}
		listener, err := net.Listen("tcp", args[1])
		if err != nil {
			return err
		}
		fmt.Println("listening", listener.Addr())
		return control.NewSidecar(config, args[2]).ServeTLS(listener, "", "")
	}
	if len(args) == 4 && args[0] == "status" || len(args) == 8 && args[0] == "apply" {
		config, err := control.ClientTLS(args[2], args[3])
		if err != nil {
			return err
		}
		send := control.HTTPS(args[1], config)
		if args[0] == "status" {
			ack, err := send(ctx, control.Command{Op: "status"})
			if err != nil {
				return err
			}
			return json.NewEncoder(os.Stdout).Encode(ack)
		}
		generation, err := strconv.ParseUint(args[6], 10, 64)
		if err != nil {
			return err
		}
		var order [2]int
		switch args[7] {
		case "0,1":
			order = [2]int{0, 1}
		case "1,0":
			order = [2]int{1, 0}
		default:
			return errors.New("order must be 0,1 or 1,0")
		}
		controller := control.Controller{Origins: [2]string{args[4], args[5]}, Send: send}
		ack, err := controller.Apply(ctx, control.NewSnapshot(generation, order))
		if err != nil {
			return err
		}
		if err := json.NewEncoder(os.Stdout).Encode(ack); err != nil {
			return err
		}
		if ack.Result != "applied" && ack.Result != "unchanged" {
			return fmt.Errorf("route update: %s", ack.Result)
		}
		return nil
	}
	return errors.New("usage: sidecar LISTEN SOCKET CA LEAF | status URL CA LEAF | apply URL CA LEAF ORIGIN0 ORIGIN1 GENERATION ORDER")
}
