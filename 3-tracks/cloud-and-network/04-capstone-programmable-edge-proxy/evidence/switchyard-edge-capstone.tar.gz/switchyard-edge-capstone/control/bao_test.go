package control

import (
	"bytes"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"net/netip"
	"os"
	"sync/atomic"
	"testing"
	"time"
)

func TestOpenBao(t *testing.T) {
	root := os.Getenv("EDGE_BAO_ROOT")
	if root == "" {
		t.Skip("run the isolated OpenBao profile")
	}
	address, err := netip.ParseAddrPort(os.Getenv("EDGE_BAO_ADDRESS"))
	if err != nil || !address.Addr().IsLoopback() {
		t.Fatal("OpenBao fixture requires a loopback service")
	}
	api := func(method, path, token string, payload any, expected int) []byte {
		t.Helper()
		body, err := json.Marshal(payload)
		if err != nil {
			t.Fatal(err)
		}
		request, err := http.NewRequestWithContext(t.Context(), method,
			"http://"+address.String()+"/v1/"+path, bytes.NewReader(body))
		if err != nil {
			t.Fatal(err)
		}
		request.Header.Set("Content-Type", "application/json")
		request.Header.Set("X-Vault-Token", token)
		response, err := requestClient().Do(request)
		if err != nil {
			t.Fatal(err)
		}
		defer response.Body.Close()
		if response.StatusCode != expected {
			t.Fatalf("OpenBao %s %s: HTTP %d, expected %d", method, path, response.StatusCode, expected)
		}
		data, err := io.ReadAll(io.LimitReader(response.Body, 8192))
		if err != nil {
			t.Fatal(err)
		}
		return data
	}
	api("PUT", "sys/policies/acl/edge-signer", root,
		map[string]any{"policy": `path "secret/data/edge-signing" { capabilities = ["read"] }`}, 204)
	result := api("POST", "auth/token/create", root, map[string]any{
		"policies": []string{"edge-signer"}, "no_default_policy": true, "ttl": "5m",
	}, 200)
	var token struct {
		Auth struct {
			Token string `json:"client_token"`
		} `json:"auth"`
	}
	if err := json.Unmarshal(result, &token); err != nil || token.Auth.Token == "" {
		t.Fatal("OpenBao test token unavailable")
	}

	store := func(path string) {
		t.Helper()
		secret := make([]byte, 32)
		if _, err := rand.Read(secret); err != nil {
			t.Fatal(err)
		}
		api("POST", "secret/data/"+path, root,
			map[string]any{"data": map[string]string{"key": hex.EncodeToString(secret)}}, 200)
	}
	store("edge-signing")
	store("unrelated")
	api("GET", "secret/data/unrelated", token.Auth.Token, nil, 403)

	var current atomic.Pointer[SigningKey]
	inbox := &Inbox{}
	now := time.Now()
	fixture := httptest.NewServer(inbox.Handler(func(version uint64) []byte {
		key := current.Load()
		if key != nil && key.Version == version {
			return key.Secret
		}
		return nil
	}, func() time.Time { return now }))
	defer fixture.Close()
	destination := Deliverer{Destinations: map[string]netip.AddrPort{
		"jobs": netip.MustParseAddrPort(fixture.Listener.Addr().String()),
	}}
	deliver := func(version uint64, id string) SigningKey {
		t.Helper()
		key, err := ReadSigningKey(t.Context(), address, token.Auth.Token)
		if err != nil || key.Version != version {
			t.Fatalf("read version %d: got version %d, error %v", version, key.Version, err)
		}
		current.Store(&key)
		if err := destination.Send(t.Context(), "jobs", key, now, id, []byte("route changed")); err != nil {
			t.Fatal(err)
		}
		return key
	}
	first := deliver(1, "update-1")
	store("edge-signing")
	second := deliver(2, "update-2")
	if bytes.Equal(first.Secret, second.Secret) || inbox.Count() != 2 {
		t.Fatal("rotation or event receipt missing")
	}
	if err := destination.Send(t.Context(), "jobs", first, now, "retired", nil); err == nil || inbox.Count() != 2 {
		t.Fatal("retired version accepted")
	}
	t.Log("OpenBao allowed signing path, denied unrelated path, and deliveries used versions 1 then 2")
}
