package control

import (
	"context"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/netip"
)

func ReadSigningKey(ctx context.Context, address netip.AddrPort, token string) (SigningKey, error) {
	if !address.Addr().IsLoopback() || address.Port() == 0 || token == "" {
		return SigningKey{}, errors.New("invalid OpenBao endpoint or missing token")
	}
	request, err := http.NewRequestWithContext(ctx, http.MethodGet,
		"http://"+address.String()+"/v1/secret/data/edge-signing", nil)
	if err != nil {
		return SigningKey{}, err
	}
	request.Header.Set("X-Vault-Token", token)
	response, err := requestClient().Do(request)
	if err != nil {
		return SigningKey{}, err
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return SigningKey{}, fmt.Errorf("OpenBao signing key read: HTTP %d", response.StatusCode)
	}
	var envelope struct {
		Data struct {
			Data struct {
				Key string `json:"key"`
			} `json:"data"`
			Metadata struct {
				Version uint64 `json:"version"`
			} `json:"metadata"`
		} `json:"data"`
	}
	body, err := io.ReadAll(io.LimitReader(response.Body, 16385))
	if err != nil || len(body) > 16384 || json.Unmarshal(body, &envelope) != nil {
		return SigningKey{}, errors.New("invalid OpenBao key response")
	}
	key, err := hex.DecodeString(envelope.Data.Data.Key)
	if err != nil || len(key) != 32 || envelope.Data.Metadata.Version == 0 {
		return SigningKey{}, errors.New("invalid signing key")
	}
	return SigningKey{Version: envelope.Data.Metadata.Version, Secret: key}, nil
}
