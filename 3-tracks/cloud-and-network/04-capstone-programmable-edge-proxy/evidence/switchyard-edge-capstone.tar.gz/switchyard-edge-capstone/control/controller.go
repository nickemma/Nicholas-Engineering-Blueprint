package control

import (
	"context"
	"fmt"
	"net/http"
	"net/netip"
	"time"
)

type Controller struct {
	Origins [2]string
	Send    Send
}

func requestClient() *http.Client {
	return &http.Client{
		Transport:     &http.Transport{DisableKeepAlives: true},
		Timeout:       2 * time.Second,
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse },
	}
}

func (c Controller) Apply(ctx context.Context, snapshot Snapshot) (Ack, error) {
	if snapshot.Order != [2]int{0, 1} && snapshot.Order != [2]int{1, 0} ||
		snapshot.Digest != NewSnapshot(snapshot.Generation, snapshot.Order).Digest {
		return Ack{}, fmt.Errorf("invalid snapshot")
	}
	client := requestClient()
	client.Timeout = 250 * time.Millisecond
	for _, index := range snapshot.Order {
		address, err := netip.ParseAddrPort(c.Origins[index])
		if err != nil || !address.Addr().IsLoopback() || address.Port() == 0 {
			return Ack{}, fmt.Errorf("invalid configured origin %d", index)
		}
		request, err := http.NewRequestWithContext(ctx, http.MethodGet, "http://"+address.String()+"/health", nil)
		if err != nil {
			return Ack{}, err
		}
		response, err := client.Do(request)
		if err != nil {
			return Ack{}, fmt.Errorf("origin %d health check: %w", index, err)
		}
		response.Body.Close()
		if response.StatusCode != http.StatusOK {
			return Ack{}, fmt.Errorf("origin %d unhealthy: HTTP %d", index, response.StatusCode)
		}
	}
	return c.Send(ctx, Command{Op: "apply", Snapshot: &snapshot})
}
