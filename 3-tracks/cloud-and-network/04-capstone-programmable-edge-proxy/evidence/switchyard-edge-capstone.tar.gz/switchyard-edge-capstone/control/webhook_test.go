package control

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"net/netip"
	"testing"
	"time"
)

func TestEvents(t *testing.T) {
	now := time.Unix(1700000000, 0)
	key := SigningKey{1, bytes.Repeat([]byte("a"), 32)}
	inbox := &Inbox{}
	receiver := httptest.NewServer(inbox.Handler(func(v uint64) []byte {
		if v == key.Version {
			return key.Secret
		}
		return nil
	}, func() time.Time { return now }))
	defer receiver.Close()
	delivery := Deliverer{Destinations: map[string]netip.AddrPort{
		"jobs": netip.MustParseAddrPort(receiver.Listener.Addr().String()),
	}}
	for range 2 {
		if err := delivery.Send(t.Context(), "jobs", key, now, "job-1", []byte("completed")); err != nil {
			t.Fatal(err)
		}
	}
	cases := []struct {
		name string
		key  SigningKey
		time time.Time
	}{
		{"wrong signature", SigningKey{1, bytes.Repeat([]byte("b"), 32)}, now},
		{"expired", key, now.Add(-2 * time.Minute)},
	}
	for _, c := range cases {
		if err := delivery.Send(t.Context(), "jobs", c.key, c.time, "job-2", nil); err == nil {
			t.Fatalf("%s accepted", c.name)
		}
	}
	if err := delivery.Send(t.Context(), "unknown", key, now, "job-2", nil); err == nil {
		t.Fatal("unregistered destination accepted")
	}
	if err := delivery.Send(t.Context(), "jobs", key, now, "job-1", []byte("changed")); err == nil {
		t.Fatal("conflicting duplicate accepted")
	}
	if inbox.Count() != 1 {
		t.Fatalf("recipient stored %d events", inbox.Count())
	}
	redirect := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, receiver.URL+"/events", http.StatusTemporaryRedirect)
	}))
	defer redirect.Close()
	delivery.Destinations["redirect"] = netip.MustParseAddrPort(redirect.Listener.Addr().String())
	if err := delivery.Send(t.Context(), "redirect", key, now, "job-3", nil); err == nil || inbox.Count() != 1 {
		t.Fatal("outbound redirect followed")
	}
	t.Log("signed event stored once; invalid, expired, conflicting, unregistered, and redirected delivery refused")
}
