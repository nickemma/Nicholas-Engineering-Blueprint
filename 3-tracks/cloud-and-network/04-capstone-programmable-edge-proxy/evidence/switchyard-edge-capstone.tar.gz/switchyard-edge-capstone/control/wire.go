package control

import (
	"bufio"
	"context"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"time"
)

const maxFrame = 2048

type Snapshot struct {
	Generation uint64 `json:"generation"`
	Order      [2]int `json:"order"`
	Digest     string `json:"digest"`
}

func NewSnapshot(generation uint64, order [2]int) Snapshot {
	digest := sha256.Sum256(fmt.Appendf(nil, "%d,%d", order[0], order[1]))
	return Snapshot{generation, order, fmt.Sprintf("%x", digest)}
}

type Command struct {
	Op       string    `json:"op"`
	Snapshot *Snapshot `json:"snapshot,omitempty"`
}

type Ack struct {
	Result   string   `json:"result"`
	Snapshot Snapshot `json:"snapshot"`
}

type Send func(context.Context, Command) (Ack, error)

func Unix(socket string) Send {
	return func(ctx context.Context, command Command) (Ack, error) {
		ctx, cancel := context.WithTimeout(ctx, time.Second)
		defer cancel()
		conn, err := (&net.Dialer{}).DialContext(ctx, "unix", socket)
		if err != nil {
			return Ack{}, err
		}
		defer conn.Close()
		stop := context.AfterFunc(ctx, func() { conn.Close() })
		defer stop()
		if err := json.NewEncoder(conn).Encode(command); err != nil {
			return Ack{}, err
		}
		line, err := bufio.NewReaderSize(conn, maxFrame+1).ReadSlice('\n')
		if err != nil {
			return Ack{}, err
		}
		if len(line) > maxFrame {
			return Ack{}, errors.New("admin acknowledgement too large")
		}
		var ack Ack
		err = json.Unmarshal(line, &ack)
		return ack, err
	}
}
