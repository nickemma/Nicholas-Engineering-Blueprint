package control

import (
	"bytes"
	"context"
	"crypto/x509"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strconv"
	"sync/atomic"
	"testing"
	"time"
)

const objectPath = "/a/obj/4096/1"

type fixtureOrigin struct {
	id      int
	healthy atomic.Bool
	entered chan struct{}
	release chan struct{}
}

func (o *fixtureOrigin) payload() []byte {
	return bytes.Repeat([]byte{byte('a' + o.id)}, 4096)
}

func (o *fixtureOrigin) handler() http.Handler {
	mux := http.NewServeMux()
	payload := o.payload()
	mux.HandleFunc("GET /health", func(w http.ResponseWriter, _ *http.Request) {
		if !o.healthy.Load() {
			w.WriteHeader(http.StatusServiceUnavailable)
			return
		}
		w.WriteHeader(http.StatusOK)
	})
	respond := func(w http.ResponseWriter) {
		w.Header().Set("X-Origin-Slot", strconv.Itoa(o.id))
		w.Header().Set("Content-Length", strconv.Itoa(len(payload)))
		_, _ = w.Write(payload)
	}
	mux.HandleFunc("GET "+objectPath, func(w http.ResponseWriter, _ *http.Request) {
		respond(w)
	})
	mux.HandleFunc("GET /a/held", func(w http.ResponseWriter, r *http.Request) {
		select {
		case o.entered <- struct{}{}:
		case <-r.Context().Done():
			return
		}
		select {
		case <-o.release:
			respond(w)
		case <-r.Context().Done():
		}
	})
	return mux
}

type capstone struct {
	origins    [2]*fixtureOrigin
	controller Controller
	edge       string
	pid        int
}

func startCapstone(t *testing.T) capstone {
	t.Helper()
	var c capstone
	var addresses [2]string
	for slot := range c.origins {
		origin := &fixtureOrigin{id: slot, entered: make(chan struct{}), release: make(chan struct{})}
		origin.healthy.Store(true)
		server := httptest.NewServer(origin.handler())
		t.Cleanup(server.Close)
		addresses[slot] = server.Listener.Addr().String()
		c.origins[slot] = origin
	}
	edge, socket, pid := launchEdge(t, addresses)
	c.edge, c.pid = edge, pid

	ca := testCA(t)
	dir := t.TempDir()
	sidecarLeaf := filepath.Join(dir, "sidecar.pem")
	controllerLeaf := filepath.Join(dir, "controller.pem")
	ca.issue(t, sidecarLeaf, sidecarRole, 2, x509.ExtKeyUsageServerAuth)
	ca.issue(t, controllerLeaf, controllerRole, 3, x509.ExtKeyUsageClientAuth)
	serverConfig, err := ServerTLS(ca.path, sidecarLeaf)
	if err != nil {
		t.Fatal(err)
	}
	config, err := ClientTLS(ca.path, controllerLeaf)
	if err != nil {
		t.Fatal(err)
	}
	listener, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	server := NewSidecar(serverConfig, socket)
	t.Cleanup(func() { server.Close() })
	go server.ServeTLS(listener, "", "")
	c.controller = Controller{Origins: addresses, Send: HTTPS("https://"+listener.Addr().String(), config)}
	return c
}

func (c capstone) origin(ctx context.Context, client *http.Client, path string) (int, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, c.edge+path, nil)
	if err != nil {
		return -1, err
	}
	response, err := client.Do(req)
	if err != nil {
		return -1, err
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK || response.ProtoMajor != 1 || response.ProtoMinor != 1 {
		return -1, fmt.Errorf("unexpected HTTP result: %s status %d", response.Proto, response.StatusCode)
	}
	body, err := io.ReadAll(io.LimitReader(response.Body, 4097))
	if err != nil {
		return -1, err
	}
	slot, err := strconv.Atoi(response.Header.Get("X-Origin-Slot"))
	if err != nil || slot < 0 || slot >= len(c.origins) || !bytes.Equal(body, c.origins[slot].payload()) {
		return -1, fmt.Errorf("response bytes or origin identity did not match")
	}
	return slot, nil
}

func (c capstone) apply(t *testing.T, generation uint64, slot int) {
	t.Helper()
	desired := NewSnapshot(generation, [2]int{slot, 1 - slot})
	ack, err := c.controller.Apply(t.Context(), desired)
	if err != nil || ack.Result != "applied" || ack.Snapshot != desired {
		t.Fatalf("publish generation %d: %+v, %v", generation, ack, err)
	}
}

func (c capstone) assertOrigin(t *testing.T, expected int) {
	t.Helper()
	slot, err := c.origin(t.Context(), requestClient(), objectPath)
	if err != nil || slot != expected {
		t.Fatalf("new request: want origin %d, got %d, %v", expected, slot, err)
	}
}

func (c capstone) handoff(t *testing.T, generation uint64, previous, next int) {
	t.Helper()
	origin := c.origins[previous]
	held := make(chan error, 1)
	go func() {
		slot, err := c.origin(t.Context(), requestClient(), "/a/held")
		if err == nil && slot != previous {
			err = fmt.Errorf("expected origin %d, observed %d", previous, slot)
		}
		held <- err
	}()
	select {
	case <-origin.entered:
	case <-time.After(2 * time.Second):
		t.Fatal("held request did not reach its original origin")
	}
	c.apply(t, generation, next)
	c.assertOrigin(t, next)
	select {
	case origin.release <- struct{}{}:
	case err := <-held:
		t.Fatalf("held request interrupted at publication: %v", err)
	case <-time.After(time.Second):
		t.Fatal("held request did not drain")
	}
	if err := <-held; err != nil {
		t.Fatalf("held request interrupted at publication: %v", err)
	}
	t.Logf("generation %d: held request finished at %d, post-ack request reached %d", generation, previous, next)
}

func TestCapstoneHandoff(t *testing.T) {
	c := startCapstone(t)
	c.handoff(t, 1, 0, 1)
	c.handoff(t, 2, 1, 0)
}
