package control

import (
	"bufio"
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

type lab struct {
	origins [2]string
	edge    string
	socket  string
	healthy atomic.Bool
	entered chan struct{}
	release chan struct{}
}

func startLab(t *testing.T) *lab {
	t.Helper()
	binary := os.Getenv("EDGE_BIN")
	if binary == "" {
		t.Skip("set EDGE_BIN to the built Rust proxy")
	}
	l := &lab{entered: make(chan struct{}, 1), release: make(chan struct{}, 1)}
	l.healthy.Store(true)
	for index, name := range [2]string{"origin-a", "origin-b"} {
		origin := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if r.URL.Path == "/health" && index == 1 && !l.healthy.Load() {
				http.Error(w, "unhealthy", http.StatusServiceUnavailable)
				return
			}
			if index == 0 && r.URL.Path == "/a/held" {
				l.entered <- struct{}{}
				select {
				case <-l.release:
				case <-r.Context().Done():
					return
				}
			}
			fmt.Fprint(w, name)
		}))
		t.Cleanup(origin.Close)
		l.origins[index] = origin.Listener.Addr().String()
	}
	l.edge, l.socket, _ = launchEdge(t, l.origins)
	return l
}

func launchEdge(t *testing.T, origins [2]string) (string, string, int) {
	t.Helper()
	// Unix sockets have short platform path limits. Use a private short directory.
	dir, err := os.MkdirTemp("", "edge-")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { os.RemoveAll(dir) })
	socket := filepath.Join(dir, "admin.sock")
	cmd := exec.Command(os.Getenv("EDGE_BIN"), "managed", "127.0.0.1:0", origins[0], origins[1], socket)
	cmd.Stderr = os.Stderr
	out, err := cmd.StdoutPipe()
	if err != nil {
		t.Fatal(err)
	}
	if err := cmd.Start(); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { cmd.Process.Kill(); cmd.Wait() })
	startup := make(chan string, 1)
	go func() {
		line, _ := bufio.NewReader(out).ReadString('\n')
		startup <- strings.TrimSpace(line)
	}()
	var edgeURL string
	select {
	case line := <-startup:
		address, ok := strings.CutPrefix(line, "listening ")
		if !ok {
			t.Fatalf("invalid startup response %q", line)
		}
		edgeURL = "http://" + address
	case <-time.After(3 * time.Second):
		t.Fatal("edge startup timed out")
	}
	for deadline := time.Now().Add(time.Second); ; {
		ack, err := Unix(socket)(t.Context(), Command{Op: "status"})
		if err == nil && ack.Result == "current" {
			return edgeURL, socket, cmd.Process.Pid
		}
		if time.Now().After(deadline) {
			t.Fatalf("edge status unavailable: %v", err)
		}
		time.Sleep(10 * time.Millisecond)
	}
}

func fetch(ctx context.Context, url string) (string, error) {
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return "", err
	}
	response, err := requestClient().Do(request)
	if err != nil {
		return "", err
	}
	defer response.Body.Close()
	body, err := io.ReadAll(io.LimitReader(response.Body, 64))
	if response.StatusCode != 200 {
		return "", fmt.Errorf("HTTP %d: %s", response.StatusCode, body)
	}
	return string(body), err
}

func routeScenarios(t *testing.T, l *lab, send Send) {
	t.Helper()
	ctx := t.Context()
	check := func(cmd Command, result string, generation uint64) {
		t.Helper()
		ack, err := send(ctx, cmd)
		if err != nil || ack.Result != result || ack.Snapshot.Generation != generation {
			t.Fatalf("expected %s generation %d, got %+v, %v", result, generation, ack, err)
		}
	}
	desired := NewSnapshot(1, [2]int{1, 0})
	update := Command{Op: "apply", Snapshot: &desired}
	controller := Controller{Origins: l.origins, Send: send}
	l.healthy.Store(false)
	if _, err := controller.Apply(ctx, desired); err == nil {
		t.Fatal("unhealthy candidate accepted")
	}
	check(Command{Op: "status"}, "current", 0)
	l.healthy.Store(true)

	held := make(chan error, 1)
	go func() {
		body, err := fetch(ctx, l.edge+"/a/held")
		if err == nil && body != "origin-a" {
			err = fmt.Errorf("held request reached %s", body)
		}
		held <- err
	}()
	select {
	case <-l.entered:
	case <-time.After(time.Second):
		t.Fatal("held request did not reach first origin")
	}
	controller.Send = func(ctx context.Context, cmd Command) (Ack, error) {
		ack, err := send(ctx, cmd)
		if err != nil || ack.Result != "applied" {
			t.Fatalf("first publish: %+v %v", ack, err)
		}
		return Ack{}, io.ErrUnexpectedEOF
	}
	if _, err := controller.Apply(ctx, desired); !errors.Is(err, io.ErrUnexpectedEOF) {
		t.Fatalf("lost acknowledgement: %v", err)
	}
	l.release <- struct{}{}
	if err := <-held; err != nil {
		t.Fatal(err)
	}
	check(update, "unchanged", 1)
	body, err := fetch(ctx, l.edge+"/a/new")
	if err != nil || body != "origin-b" {
		t.Fatalf("new request: %q %v", body, err)
	}
	stale := NewSnapshot(0, [2]int{0, 1})
	conflict := NewSnapshot(1, [2]int{0, 1})
	check(Command{Op: "apply", Snapshot: &stale}, "stale", 1)
	check(Command{Op: "apply", Snapshot: &conflict}, "conflict", 1)
	check(Command{Op: "status"}, "current", 1)
	rollback := NewSnapshot(2, [2]int{0, 1})
	controller.Send = send
	ack, err := controller.Apply(ctx, rollback)
	if err != nil || ack.Result != "applied" || ack.Snapshot != rollback {
		t.Fatalf("rollback: %+v %v", ack, err)
	}
	body, err = fetch(ctx, l.edge+"/a/new")
	if err != nil || body != "origin-a" {
		t.Fatalf("rolled-back request: %q %v", body, err)
	}
	t.Log("unhealthy candidate rejected, old request drained, new route served, retry acknowledged, rollback applied")
}

func TestRoutes(t *testing.T) {
	l := startLab(t)
	routeScenarios(t, l, Unix(l.socket))
}
