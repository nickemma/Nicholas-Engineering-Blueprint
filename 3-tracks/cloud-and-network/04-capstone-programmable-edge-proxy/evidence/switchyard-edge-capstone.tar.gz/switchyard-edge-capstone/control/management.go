package control

import (
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"time"
)

const (
	controllerRole = "urn:switchyard:controller"
	sidecarRole    = "urn:switchyard:sidecar"
	sidecarName    = "sidecar.edge.invalid"
)

func peerRole(role string) func(tls.ConnectionState) error {
	return func(state tls.ConnectionState) error {
		if len(state.VerifiedChains) == 0 || len(state.PeerCertificates) == 0 {
			return errors.New("unverified peer")
		}
		for _, name := range state.PeerCertificates[0].URIs {
			if name.String() == role {
				return nil
			}
		}
		return errors.New("unexpected peer identity")
	}
}

func roots(path string) (*x509.CertPool, error) {
	pem, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	pool := x509.NewCertPool()
	if !pool.AppendCertsFromPEM(pem) {
		return nil, errors.New("invalid CA PEM")
	}
	return pool, nil
}

func readLeaf(path string) (*tls.Certificate, error) {
	bundle, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	pair, err := tls.X509KeyPair(bundle, bundle)
	return &pair, err
}

func ServerTLS(ca, leaf string) (*tls.Config, error) {
	pool, err := roots(ca)
	if err != nil {
		return nil, err
	}
	if _, err := readLeaf(leaf); err != nil {
		return nil, err
	}
	return &tls.Config{
		MinVersion: tls.VersionTLS13, ClientAuth: tls.RequireAndVerifyClientCert,
		ClientCAs: pool, VerifyConnection: peerRole(controllerRole),
		GetCertificate:         func(*tls.ClientHelloInfo) (*tls.Certificate, error) { return readLeaf(leaf) },
		SessionTicketsDisabled: true,
	}, nil
}

func ClientTLS(ca, leaf string) (*tls.Config, error) {
	pool, err := roots(ca)
	if err != nil {
		return nil, err
	}
	if _, err := readLeaf(leaf); err != nil {
		return nil, err
	}
	return &tls.Config{
		MinVersion: tls.VersionTLS13, RootCAs: pool, ServerName: sidecarName,
		VerifyConnection:     peerRole(sidecarRole),
		GetClientCertificate: func(*tls.CertificateRequestInfo) (*tls.Certificate, error) { return readLeaf(leaf) },
	}, nil
}

func Handler(send Send) http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /v1/admin", func(w http.ResponseWriter, r *http.Request) {
		body, err := io.ReadAll(http.MaxBytesReader(w, r.Body, maxFrame-1))
		var command Command
		if err != nil || json.Unmarshal(body, &command) != nil {
			http.Error(w, "invalid admin request", http.StatusBadRequest)
			return
		}
		switch {
		case command.Op == "status" && command.Snapshot == nil,
			command.Op == "apply" && command.Snapshot != nil:
		default:
			http.Error(w, "unsupported admin request", http.StatusBadRequest)
			return
		}
		ack, err := send(r.Context(), command)
		if err != nil {
			http.Error(w, "local admin unavailable", http.StatusBadGateway)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(ack)
	})
	return mux
}

func NewSidecar(config *tls.Config, socket string) *http.Server {
	return &http.Server{
		TLSConfig: config, Handler: Handler(Unix(socket)),
		ReadTimeout: 2 * time.Second, WriteTimeout: 3 * time.Second,
		ReadHeaderTimeout: time.Second, IdleTimeout: 5 * time.Second,
	}
}

func HTTPS(base string, config *tls.Config) Send {
	client := requestClient()
	client.Transport.(*http.Transport).TLSClientConfig = config
	return func(ctx context.Context, command Command) (Ack, error) {
		if !strings.HasPrefix(base, "https://") {
			return Ack{}, errors.New("management endpoint must use HTTPS")
		}
		body, err := json.Marshal(command)
		if err != nil {
			return Ack{}, err
		}
		req, err := http.NewRequestWithContext(ctx, http.MethodPost,
			strings.TrimRight(base, "/")+"/v1/admin", bytes.NewReader(body))
		if err != nil {
			return Ack{}, err
		}
		req.Header.Set("Content-Type", "application/json")
		resp, err := client.Do(req)
		if err != nil {
			return Ack{}, err
		}
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			return Ack{}, fmt.Errorf("management response: HTTP %d", resp.StatusCode)
		}
		data, err := io.ReadAll(io.LimitReader(resp.Body, maxFrame+1))
		if err != nil {
			return Ack{}, err
		}
		if len(data) > maxFrame {
			return Ack{}, errors.New("management response too large")
		}
		var ack Ack
		err = json.Unmarshal(data, &ack)
		return ack, err
	}
}
