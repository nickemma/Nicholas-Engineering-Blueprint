package control

import (
	"bytes"
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/netip"
	"strconv"
	"strings"
	"sync"
	"time"
)

const eventLimit = 8 * 1024

type SigningKey struct {
	Version uint64
	Secret  []byte
}

type Deliverer struct {
	Destinations map[string]netip.AddrPort
}

func validID(id string) bool {
	return len(id) > 0 && len(id) <= 64 && strings.IndexFunc(id, func(r rune) bool {
		return !(r >= 'a' && r <= 'z' || r >= 'A' && r <= 'Z' || r >= '0' && r <= '9' || r == '-')
	}) == -1
}

func eventMAC(key []byte, version, timestamp, id string, body []byte) []byte {
	hash := hmac.New(sha256.New, key)
	fmt.Fprintf(hash, "%s\n%s\n%s\n", version, timestamp, id)
	hash.Write(body)
	return hash.Sum(nil)
}

func eventRequest(ctx context.Context, destination string, key SigningKey, now time.Time, id string, body []byte) (*http.Request, error) {
	if !validID(id) || key.Version == 0 || len(key.Secret) < 32 || len(body) > eventLimit {
		return nil, errors.New("invalid event or signing key")
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, destination, bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	version := strconv.FormatUint(key.Version, 10)
	timestamp := strconv.FormatInt(now.Unix(), 10)
	req.Header.Set("X-Event-ID", id)
	req.Header.Set("X-Event-Time", timestamp)
	req.Header.Set("X-Key-Version", version)
	req.Header.Set("X-Event-MAC", hex.EncodeToString(eventMAC(key.Secret, version, timestamp, id, body)))
	return req, nil
}

func (d Deliverer) Send(ctx context.Context, destination string, key SigningKey, now time.Time, id string, body []byte) error {
	address, found := d.Destinations[destination]
	if !found || !address.Addr().IsLoopback() || address.Port() == 0 {
		return errors.New("destination outside the configured allowlist")
	}
	req, err := eventRequest(ctx, "http://"+address.String()+"/events", key, now, id, body)
	if err != nil {
		return err
	}
	resp, err := requestClient().Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusNoContent {
		return fmt.Errorf("delivery refused: HTTP %d", resp.StatusCode)
	}
	return nil
}

type Inbox struct {
	mu   sync.Mutex
	seen map[string][32]byte
}

func (in *Inbox) Count() int {
	in.mu.Lock()
	defer in.mu.Unlock()
	return len(in.seen)
}

func (in *Inbox) Handler(lookup func(uint64) []byte, clock func() time.Time) http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /events", func(w http.ResponseWriter, r *http.Request) {
		id, timestamp, version := r.Header.Get("X-Event-ID"), r.Header.Get("X-Event-Time"), r.Header.Get("X-Key-Version")
		seconds, timeErr := strconv.ParseInt(timestamp, 10, 64)
		keyVersion, versionErr := strconv.ParseUint(version, 10, 64)
		signature, macErr := hex.DecodeString(r.Header.Get("X-Event-MAC"))
		now := clock()
		date := time.Unix(seconds, 0)
		if !validID(id) || timeErr != nil || versionErr != nil || macErr != nil ||
			date.Before(now.Add(-time.Minute)) || date.After(now.Add(5*time.Second)) {
			http.Error(w, "event rejected", http.StatusUnauthorized)
			return
		}
		body, err := io.ReadAll(http.MaxBytesReader(w, r.Body, eventLimit))
		secret := lookup(keyVersion)
		if err != nil || len(secret) < 32 ||
			!hmac.Equal(signature, eventMAC(secret, version, timestamp, id, body)) {
			http.Error(w, "event rejected", http.StatusUnauthorized)
			return
		}

		digest := sha256.Sum256(body)
		in.mu.Lock()
		defer in.mu.Unlock()
		if in.seen == nil {
			in.seen = make(map[string][32]byte)
		}
		if existing, seen := in.seen[id]; seen {
			if existing != digest {
				http.Error(w, "event identity conflict", http.StatusConflict)
				return
			}
		} else {
			if len(in.seen) >= 1024 {
				http.Error(w, "inbox full", http.StatusServiceUnavailable)
				return
			}
			in.seen[id] = digest
		}
		w.WriteHeader(http.StatusNoContent)
	})
	return mux
}
