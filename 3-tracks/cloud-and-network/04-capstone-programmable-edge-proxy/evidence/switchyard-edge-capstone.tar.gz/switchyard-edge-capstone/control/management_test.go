package control

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"math/big"
	"net"
	"net/url"
	"os"
	"path/filepath"
	"sync/atomic"
	"testing"
	"time"
)

type authority struct {
	cert *x509.Certificate
	key  ed25519.PrivateKey
	path string
}

func testCA(t *testing.T) authority {
	t.Helper()
	public, key, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	cert := &x509.Certificate{
		SerialNumber: big.NewInt(1), Subject: pkix.Name{CommonName: "Edge lab CA"},
		NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().Add(time.Hour),
		IsCA: true, BasicConstraintsValid: true, KeyUsage: x509.KeyUsageCertSign,
	}
	der, err := x509.CreateCertificate(rand.Reader, cert, cert, public, key)
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "ca.pem")
	if err := os.WriteFile(path, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der}), 0o600); err != nil {
		t.Fatal(err)
	}
	return authority{cert, key, path}
}

func (a authority) issue(t *testing.T, path, role string, serial int64, usage x509.ExtKeyUsage) {
	t.Helper()
	public, private, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	uri, err := url.Parse(role)
	if err != nil {
		t.Fatal(err)
	}
	cert := &x509.Certificate{
		SerialNumber: big.NewInt(serial), NotBefore: time.Now().Add(-time.Hour),
		NotAfter: time.Now().Add(time.Hour), ExtKeyUsage: []x509.ExtKeyUsage{usage},
		URIs: []*url.URL{uri}, KeyUsage: x509.KeyUsageDigitalSignature,
	}
	if usage == x509.ExtKeyUsageServerAuth {
		cert.DNSNames = []string{sidecarName}
	}
	der, err := x509.CreateCertificate(rand.Reader, cert, a.cert, public, a.key)
	if err != nil {
		t.Fatal(err)
	}
	key, err := x509.MarshalPKCS8PrivateKey(private)
	if err != nil {
		t.Fatal(err)
	}
	bundle := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
	bundle = append(bundle, pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: key})...)
	if err := os.WriteFile(path, bundle, 0o600); err != nil {
		t.Fatal(err)
	}
}

func TestManagement(t *testing.T) {
	lab := startLab(t)
	ca := testCA(t)
	dir := t.TempDir()
	serverLeaf := filepath.Join(dir, "sidecar.pem")
	clientLeaf := filepath.Join(dir, "controller.pem")
	otherLeaf := filepath.Join(dir, "other.pem")
	ca.issue(t, serverLeaf, sidecarRole, 2, x509.ExtKeyUsageServerAuth)
	ca.issue(t, clientLeaf, controllerRole, 3, x509.ExtKeyUsageClientAuth)
	ca.issue(t, otherLeaf, "urn:switchyard:observer", 4, x509.ExtKeyUsageClientAuth)
	server, err := ServerTLS(ca.path, serverLeaf)
	if err != nil {
		t.Fatal(err)
	}
	var seenController atomic.Int64
	verifyController := server.VerifyConnection
	server.VerifyConnection = func(state tls.ConnectionState) error {
		if err := verifyController(state); err != nil {
			return err
		}
		seenController.Store(state.PeerCertificates[0].SerialNumber.Int64())
		return nil
	}
	sidecar := NewSidecar(server, lab.socket)
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	go sidecar.ServeTLS(listener, "", "")
	t.Cleanup(func() { sidecar.Close() })
	base := "https://" + listener.Addr().String()
	client, err := ClientTLS(ca.path, clientLeaf)
	if err != nil {
		t.Fatal(err)
	}
	other, err := ClientTLS(ca.path, otherLeaf)
	if err != nil {
		t.Fatal(err)
	}

	bad := NewSnapshot(99, [2]int{1, 0})
	if _, err := HTTPS(base, other)(t.Context(), Command{Op: "apply", Snapshot: &bad}); err == nil {
		t.Fatal("wrong peer role accepted")
	}
	routeScenarios(t, lab, HTTPS(base, client))
	t.Log("wrong-role peer left generation unchanged")
	var seenSidecar atomic.Int64
	verifySidecar := client.VerifyConnection
	client.VerifyConnection = func(state tls.ConnectionState) error {
		if err := verifySidecar(state); err != nil {
			return err
		}
		seenSidecar.Store(state.PeerCertificates[0].SerialNumber.Int64())
		return nil
	}
	send := HTTPS(base, client)
	status := Command{Op: "status"}
	checkSerials := func(controller, sidecar int64) {
		t.Helper()
		ack, err := send(t.Context(), status)
		if err != nil || ack.Snapshot.Generation != 2 ||
			seenController.Load() != controller || seenSidecar.Load() != sidecar {
			t.Fatalf("rotation readback: %+v controller=%d sidecar=%d error=%v",
				ack, seenController.Load(), seenSidecar.Load(), err)
		}
	}
	replace := func(path, role string, serial int64, usage x509.ExtKeyUsage) {
		t.Helper()
		ca.issue(t, path+".new", role, serial, usage)
		if err := os.Rename(path+".new", path); err != nil {
			t.Fatal(err)
		}
	}
	checkSerials(3, 2)
	replace(serverLeaf, sidecarRole, 5, x509.ExtKeyUsageServerAuth)
	checkSerials(3, 5)
	replace(clientLeaf, controllerRole, 6, x509.ExtKeyUsageClientAuth)
	checkSerials(6, 5)
	next := NewSnapshot(3, [2]int{1, 0})
	ack, err := (Controller{Origins: lab.origins, Send: send}).Apply(t.Context(), next)
	if err != nil || ack.Result != "applied" || ack.Snapshot != next {
		t.Fatalf("apply after rotation: %+v %v", ack, err)
	}
	ack, err = send(t.Context(), status)
	if err != nil || ack.Snapshot != next {
		t.Fatalf("readback after rotation: %+v %v", ack, err)
	}
	t.Log("fresh TLS handshakes observed serial pairs 3/2, 3/5, 6/5; generation 3 read back")
}
