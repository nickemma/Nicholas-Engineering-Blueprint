"""Compare direct, Rust and Envoy HTTP/1.1 paths against the same local origin."""
import argparse
from collections import Counter
from contextlib import contextmanager
import gzip
import json
import math
import os
from pathlib import Path
import platform
import select
import socket
import subprocess
import threading
import time
from urllib.error import URLError
from urllib.request import ProxyHandler, build_opener
from uuid import uuid4


IMAGE = "envoyproxy/envoy@sha256:36a2dc72f4b0b2639af3dfeaf92dced4063058f200664c6c4f5d443f5d9ea51d"
OBJECT = "/a/obj/4096/1"
PAYLOAD = b"switchyard-edge\n" * 256
LOCAL = build_opener(ProxyHandler({}))
ENV = {**os.environ, "GOMAXPROCS": "2"}


@contextmanager
def process(args, *, cleanup=None, stdout=None, stderr=None):
    with subprocess.Popen(args, env=ENV, text=True, stdout=stdout, stderr=stderr) as child:
        try:
            if stdout == subprocess.PIPE:
                if not select.select([child.stdout], [], [], 10)[0]:
                    raise RuntimeError(f"startup timed out: {args[0]}")
                line = child.stdout.readline().strip()
                if not line:
                    raise RuntimeError(f"no startup address: {args[0]}")
                yield child, line
            else:
                yield child
        finally:
            if cleanup:
                cleanup()
            if child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait()


def envoy_config(port, origin):
    return {
        "static_resources": {
            "listeners": [{
                "name": "edge",
                "address": {"socket_address": {"address": "127.0.0.1", "port_value": port}},
                "filter_chains": [{"filters": [{
                    "name": "envoy.filters.network.http_connection_manager",
                    "typed_config": {
                        "@type": "type.googleapis.com/envoy.extensions.filters.network.http_connection_manager.v3.HttpConnectionManager",
                        "stat_prefix": "edge",
                        "codec_type": "HTTP1",
                        "common_http_protocol_options": {"idle_timeout": "30s"},
                        "route_config": {"name": "edge", "virtual_hosts": [{
                            "name": "objects",
                            "domains": ["*"],
                            "routes": [{
                                "match": {"path": OBJECT},
                                "route": {"cluster": "origin", "timeout": "0.750s"},
                            }],
                        }]},
                        "http_filters": [{
                            "name": "envoy.filters.http.router",
                            "typed_config": {"@type": "type.googleapis.com/envoy.extensions.filters.http.router.v3.Router"},
                        }],
                    },
                }]}],
            }],
            "clusters": [{
                "name": "origin",
                "type": "STATIC",
                "connect_timeout": "0.750s",
                "typed_extension_protocol_options": {
                    "envoy.extensions.upstreams.http.v3.HttpProtocolOptions": {
                        "@type": "type.googleapis.com/envoy.extensions.upstreams.http.v3.HttpProtocolOptions",
                        "common_http_protocol_options": {"idle_timeout": "30s"},
                        "explicit_http_config": {"http_protocol_options": {}},
                    },
                },
                "load_assignment": {
                    "cluster_name": "origin",
                    "endpoints": [{"lb_endpoints": [{"endpoint": {"address": {
                        "socket_address": {"address": "127.0.0.1", "port_value": origin},
                    }}}]}],
                },
            }],
        },
    }


def read(url, timeout=2):
    with LOCAL.open(url, timeout=timeout) as result:
        return result.read()


def wait_for_envoy(child, address):
    deadline = time.monotonic() + 15
    while child.poll() is None and time.monotonic() < deadline:
        try:
            if read(f"http://{address}{OBJECT}", timeout=0.4) == PAYLOAD:
                return
        except (URLError, TimeoutError):
            pass
        time.sleep(0.1)
    raise RuntimeError("Envoy did not serve the fixture; see envoy.log")


def percentile(values, p):
    ordered = sorted(values)
    return ordered[math.ceil(len(ordered) * p) - 1] if ordered else None


def vmrss(pid):
    for line in Path(f"/proc/{pid}/status").read_text().splitlines():
        if line.startswith("VmRSS:"):
            _, count, unit = line.split()
            if unit == "kB":
                return int(count)
    raise RuntimeError(f"VmRSS unavailable for process {pid}")


@contextmanager
def sampling_rss(pid, interval=0.025):
    samples = []
    if pid is None:
        yield samples
        return
    start = time.monotonic_ns()
    stop = threading.Event()
    errors = []

    def sample():
        try:
            while not stop.is_set():
                elapsed = (time.monotonic_ns() - start) // 1000
                samples.append({"at_us": elapsed, "kib": vmrss(pid)})
                stop.wait(interval)
        except (OSError, RuntimeError) as error:
            errors.append(error)

    thread = threading.Thread(target=sample)
    thread.start()
    try:
        yield samples
    finally:
        stop.set()
        thread.join()
    if errors or len(samples) < 2:
        raise RuntimeError(f"RSS sampling failed for process {pid}: {errors}")


def trial(driver, address, stats, rate, seconds, path, pid):
    before = json.loads(read(stats))
    with sampling_rss(pid) as memory:
        raw = subprocess.check_output(
            [driver, "load", f"http://{address}{OBJECT}", str(rate), str(seconds)],
            env=ENV, timeout=seconds + 15,
        )
    after = json.loads(read(stats))
    data = json.loads(raw)
    data["proxy_rss"] = memory
    data["origin"] = {key: after[key] - before[key] for key in before}
    with gzip.open(path, "wt", encoding="utf-8") as stream:
        json.dump(data, stream, separators=(",", ":"))
    rows = data["samples"]
    outcomes = Counter(row["outcome"] for row in rows)
    success = [row["finished_us"] - row["scheduled_us"] for row in rows if row["outcome"] == "ok"]
    assert len(rows) == rate * seconds
    assert outcomes["mismatch"] == 0 and success, outcomes
    lag = [row["started_us"] - row["scheduled_us"] for row in rows]
    return {
        "ok_rps": round(outcomes["ok"] * 1_000_000 / data["elapsed_us"], 1),
        "p50_us": percentile(success, 0.50),
        "p99_us": percentile(success, 0.99),
        "p99_launch_lag_us": percentile(lag, 0.99),
        "outcomes": dict(outcomes),
        "status_counts": dict(Counter(row["status"] for row in rows)),
        "origin": data["origin"],
        "sampled_peak_rss_kib": max((item["kib"] for item in memory), default=None),
        "rss_samples": len(memory),
        "raw": path.name,
    }


def capture(args):
    args.out.mkdir()
    with process([args.driver, "origin"], stdout=subprocess.PIPE) as (_, first):
        address, observer = first.split()
        stats = f"http://{observer}/stats"
        with process([args.driver, "origin"], stdout=subprocess.PIPE) as (_, second):
            other, _ = second.split()
            with process(
                [args.proxy, "http", "127.0.0.1:0", address, other], stdout=subprocess.PIPE,
            ) as (proxy, listening):
                rust = listening.removeprefix("listening ")
                run_comparison(args, address, stats, rust, proxy.pid)


def run_comparison(args, address, stats, rust, rust_pid):
    # Docker starts Envoy in the host network namespace so all paths are loopback.
    with socket.socket() as candidate:
        candidate.bind(("127.0.0.1", 0))
        port = candidate.getsockname()[1]
    envoy = f"127.0.0.1:{port}"
    config = envoy_config(port, int(address.split(":")[1]))
    (args.out / "envoy.json").write_text(json.dumps(config, indent=2) + "\n")
    name = "switchyard-edge-" + uuid4().hex[:12]
    docker = ["docker", "run", "--pull=never", "--rm", "--network", "host"]

    def stop_envoy():
        subprocess.run(["docker", "rm", "-f", name], capture_output=True, timeout=10, check=False)

    metadata = {
        "envoy_image": IMAGE,
        "envoy_version": subprocess.check_output(
            ["docker", "run", "--pull=never", "--rm", IMAGE, "--version"], text=True,
        ).strip(),
        "rust": subprocess.check_output(["rustc", "--version"], text=True).strip(),
        "go": subprocess.check_output(["go", "version"], text=True).strip(),
        "kernel": platform.platform(),
        "available_cpus": len(os.sched_getaffinity(0)),
        "workers_per_process": 2,
        "warmup_requests_per_trial": 32,
        "payload_bytes": len(PAYLOAD),
        "rss_scope": "Rust proxy process from driver launch through sample collection",
        "rss_sampling_ms": 25,
        "rates": args.rates,
        "trials": args.trials,
        "seconds": args.seconds,
        "path": OBJECT,
    }
    (args.out / "environment.json").write_text(json.dumps(metadata, indent=2) + "\n")
    cmd = [*docker, "--name", name, IMAGE, "--concurrency", "2",
           "--log-level", "warning", "--config-yaml", json.dumps(config)]
    paths = [("direct", address), ("rust", rust), ("envoy", envoy)]
    with (args.out / "envoy.log").open("w") as log:
        with process(cmd, cleanup=stop_envoy, stdout=log, stderr=log) as child:
            wait_for_envoy(child, envoy)
            with (args.out / "results.jsonl").open("w") as results:
                for rate in args.rates:
                    for repeat in range(args.trials):
                        offset = repeat % len(paths)
                        for label, target in paths[offset:] + paths[:offset]:
                            path = args.out / f"{rate}-{repeat + 1}-{label}.json.gz"
                            summary = trial(args.driver, target, stats, rate, args.seconds, path,
                                            rust_pid if label == "rust" else None)
                            row = {"path": label, "offered_rps": rate, "trial": repeat + 1, **summary}
                            results.write(json.dumps(row) + "\n")
                            results.flush()
                            print(json.dumps(row), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("out", type=Path)
    parser.add_argument("--rates", type=int, nargs="+", required=True)
    parser.add_argument("--seconds", type=int, default=2)
    parser.add_argument("--trials", type=int, default=3)
    parser.add_argument("--driver", default="./bench/edge-bench")
    parser.add_argument("--proxy", default="./target/release/switchyard-edge")
    args = parser.parse_args()
    if not 1 <= args.seconds <= 60 or args.trials < 1:
        parser.error("seconds must be in 1..60 and trials must be positive")
    if len(set(args.rates)) != len(args.rates) or not all(1 <= rate <= 100000 for rate in args.rates):
        parser.error("rates must be distinct integers in 1..100000")
    capture(args)
