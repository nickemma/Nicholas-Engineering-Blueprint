// Command edge-bench serves an instrumented origin or generates a fixed arrival schedule.
package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"strconv"
	"sync"
	"sync/atomic"
	"time"
)

var payload = bytes.Repeat([]byte("switchyard-edge\n"), 256)

func main() {
	switch {
	case len(os.Args) == 2 && os.Args[1] == "origin":
		log.Fatal(origin())
	case len(os.Args) == 5 && os.Args[1] == "load":
		rate, err := strconv.Atoi(os.Args[3])
		if err != nil || rate < 1 || rate > 100000 {
			log.Fatal("rate must be an integer in 1..100000")
		}
		seconds, err := strconv.Atoi(os.Args[4])
		if err != nil || seconds < 1 || seconds > 60 {
			log.Fatal("duration must be an integer in 1..60 seconds")
		}
		log.SetFlags(0)
		if err := load(os.Args[2], rate, seconds); err != nil {
			log.Fatal(err)
		}
	default:
		log.Fatal("usage: edge-bench origin | load URL RATE SECONDS")
	}
}

type counters struct {
	Requests uint64 `json:"requests"`
	Sockets  uint64 `json:"sockets"`
}

func origin() error {
	var requests, sockets atomic.Uint64
	data, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		return err
	}
	defer data.Close()
	admin, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		return err
	}
	defer admin.Close()
	mux := http.NewServeMux()
	mux.HandleFunc("GET /a/obj/4096/1", func(w http.ResponseWriter, _ *http.Request) {
		requests.Add(1)
		w.Header().Set("Content-Type", "application/octet-stream")
		w.Header().Set("Content-Length", strconv.Itoa(len(payload)))
		_, _ = w.Write(payload)
	})
	server := &http.Server{
		Handler: mux, ReadHeaderTimeout: 2 * time.Second, IdleTimeout: 30 * time.Second,
		ConnState: func(_ net.Conn, state http.ConnState) {
			if state == http.StateNew {
				sockets.Add(1)
			}
		},
	}
	observer := http.NewServeMux()
	observer.HandleFunc("GET /stats", func(w http.ResponseWriter, _ *http.Request) {
		_ = json.NewEncoder(w).Encode(counters{requests.Load(), sockets.Load()})
	})
	adminServer := &http.Server{Handler: observer, ReadHeaderTimeout: 2 * time.Second}
	go func() { log.Print(adminServer.Serve(admin)) }()
	fmt.Printf("%s %s\n", data.Addr(), admin.Addr())
	return server.Serve(data)
}

type sample struct {
	ID          int    `json:"id"`
	ScheduledUS int64  `json:"scheduled_us"`
	StartedUS   int64  `json:"started_us"`
	FinishedUS  int64  `json:"finished_us"`
	Status      int    `json:"status"`
	Outcome     string `json:"outcome"`
}

func load(url string, rate, seconds int) error {
	transport := &http.Transport{
		MaxIdleConns: 64, MaxIdleConnsPerHost: 64, MaxConnsPerHost: 64,
		IdleConnTimeout: 30 * time.Second, DisableCompression: true,
	}
	defer transport.CloseIdleConnections()
	client := &http.Client{
		Transport: transport, Timeout: 2 * time.Second,
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse },
	}

	// Warm route and client before starting the schedule. Exit on any mismatch.
	for range 32 {
		if _, outcome := fetch(client, url); outcome != "ok" {
			return fmt.Errorf("warm-up failed: %s", outcome)
		}
	}

	samples := make([]sample, rate*seconds)
	slots := make(chan struct{}, 64)
	var active sync.WaitGroup
	start := time.Now()
	timer := time.NewTimer(0)
	defer timer.Stop()
	for id := range samples {
		offset := time.Duration(id) * time.Second / time.Duration(rate)
		timer.Reset(time.Until(start.Add(offset)))
		<-timer.C
		row := &samples[id]
		row.ID = id
		row.ScheduledUS = offset.Microseconds()
		select {
		case slots <- struct{}{}:
			active.Go(func() {
				row.StartedUS = time.Since(start).Microseconds()
				row.Status, row.Outcome = fetch(client, url)
				row.FinishedUS = time.Since(start).Microseconds()
				<-slots
			})
		default:
			row.StartedUS = time.Since(start).Microseconds()
			row.FinishedUS = row.StartedUS
			row.Outcome = "driver_full"
		}
	}
	active.Wait()
	// Leave the full offered window in the throughput denominator.
	time.Sleep(time.Until(start.Add(time.Duration(seconds) * time.Second)))
	return json.NewEncoder(os.Stdout).Encode(struct {
		Warmup    int      `json:"warmup"`
		ElapsedUS int64    `json:"elapsed_us"`
		Samples   []sample `json:"samples"`
	}{32, time.Since(start).Microseconds(), samples})
}

func fetch(client *http.Client, url string) (int, string) {
	response, err := client.Get(url)
	if err != nil {
		return 0, classify(err)
	}
	defer response.Body.Close()
	content, err := io.ReadAll(io.LimitReader(response.Body, int64(len(payload)+1)))
	if err != nil {
		return response.StatusCode, classify(err)
	}
	if response.StatusCode != http.StatusOK {
		return response.StatusCode, "http_error"
	}
	if response.Proto != "HTTP/1.1" || !bytes.Equal(content, payload) {
		return response.StatusCode, "mismatch"
	}
	return response.StatusCode, "ok"
}

func classify(err error) string {
	var networkError net.Error
	if errors.Is(err, context.DeadlineExceeded) || errors.As(err, &networkError) && networkError.Timeout() {
		return "timeout"
	}
	return "io_error"
}
