#!/usr/bin/env bash
set -euo pipefail

output="${1:?provide a fresh profile output directory}"
count=5000000
target="${EDGE_PROFILE_TARGET:-target/profile}"
mkdir "$output"
export RUSTFLAGS="${RUSTFLAGS:+$RUSTFLAGS }-C force-frame-pointers=yes"
cargo build --locked --release --features cpu-profile --target-dir "$target"
binary="$target/release/switchyard-edge"

{
    "$binary" profile-route format "$count" "$output/before.svg"
    "$binary" profile-route cached "$count" "$output/after.svg"
    for trial in 1 2 3 4 5; do
        if (( trial % 2 )); then
            variants=(format cached)
        else
            variants=(cached format)
        fi
        for variant in "${variants[@]}"; do
            "$binary" profile-route "$variant" "$count" -
        done
    done
} | tee "$output/profile.jsonl"

python3 - "$output/profile.jsonl" <<'PY'
import json
from pathlib import Path
import sys

rows = [json.loads(line) for line in Path(sys.argv[1]).read_text().splitlines()]
assert len(rows) == 12
assert len({(row["operations"], row["checksum"]) for row in rows}) == 1
assert all(row["samples"] > 0 for row in rows[:2])
assert all(row["samples"] == 0 for row in rows[2:])
PY
