module switchyard/edge

go 1.26
