use super::{AuthoritySource, Origin, origin_uri};
use std::fs::File;
use std::hint::black_box;
use std::time::Instant;

pub fn run(
    variant: &str,
    operations: &str,
    destination: &str,
) -> Result<(), Box<dyn std::error::Error>> {
    let use_cache = match variant {
        "format" => false,
        "cached" => true,
        _ => return Err("profile variant must be format or cached".into()),
    };
    let count: usize = operations.parse()?;
    if count == 0 {
        return Err("profile needs a positive operation count".into());
    }
    let addresses = ["127.0.0.1:8081".parse()?, "[::1]:8082".parse()?];
    let origins = addresses.map(Origin::new);
    let targets = ["/a/obj/4096/1?key=%2F", "/b/obj/4096/1?tag=one&tag=two"];
    for i in 0..2 {
        assert_eq!(
            origin_uri(AuthoritySource::Format(addresses[i]), targets[i]),
            origin_uri(AuthoritySource::Cached(&origins[i].authority), targets[i])
        );
    }

    let guard = if destination == "-" {
        None
    } else {
        Some(
            pprof::ProfilerGuardBuilder::default()
                .frequency(499)
                .blocklist(&["libc", "libgcc", "pthread", "vdso"])
                .build()?,
        )
    };
    let start = Instant::now();
    let mut checksum = 0;
    for index in 0..count {
        let slot = index % addresses.len();
        let source = if use_cache {
            AuthoritySource::Cached(&origins[slot].authority)
        } else {
            AuthoritySource::Format(addresses[slot])
        };
        let uri = black_box(origin_uri(black_box(source), black_box(targets[slot])));
        checksum += uri.authority().expect("absolute URI").as_str().len();
    }
    let elapsed = start.elapsed().as_nanos();
    let samples = if let Some(guard) = guard {
        let report = guard.report().build()?;
        let samples = report.data.values().sum::<isize>();
        if samples <= 0 {
            return Err("profile collected no CPU samples".into());
        }
        report.flamegraph(File::create(destination)?)?;
        samples
    } else {
        0
    };
    println!(
        "{{\"variant\":\"{variant}\",\"operations\":{count},\"checksum\":{checksum},\"elapsed_ns\":{elapsed},\"samples\":{samples}}}"
    );
    Ok(())
}
