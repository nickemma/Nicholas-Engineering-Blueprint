use std::io;
use std::path::Path;
use std::sync::{Arc, RwLock};
use std::time::Duration;

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use tokio::io::{AsyncBufReadExt, AsyncReadExt, AsyncWriteExt, BufReader};
use tokio::net::{UnixListener, UnixStream};
use tokio::time::timeout;

#[derive(Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Snapshot {
    generation: u64,
    order: [usize; 2],
    digest: String,
}

impl Snapshot {
    fn digest(order: [usize; 2]) -> String {
        format!("{:x}", Sha256::digest(format!("{},{}", order[0], order[1])))
    }
}

#[derive(Clone)]
pub struct Routes(Arc<RwLock<Snapshot>>);

impl Default for Routes {
    fn default() -> Self {
        Self(Arc::new(RwLock::new(Snapshot {
            generation: 0,
            order: [0, 1],
            digest: Snapshot::digest([0, 1]),
        })))
    }
}

impl Routes {
    pub(crate) fn origin_for(&self, route: usize) -> usize {
        self.0.read().expect("routes").order[route]
    }

    fn handle(&self, request: Command) -> Ack {
        let mut active = self.0.write().expect("routes");
        let result = match request {
            Command::Status => "current",
            Command::Apply { snapshot }
                if !matches!(snapshot.order, [0, 1] | [1, 0])
                    || snapshot.digest != Snapshot::digest(snapshot.order) =>
            {
                "invalid"
            }
            Command::Apply { snapshot } if snapshot.generation < active.generation => "stale",
            Command::Apply { snapshot } if snapshot.generation == active.generation => {
                if snapshot.digest == active.digest {
                    "unchanged"
                } else {
                    "conflict"
                }
            }
            Command::Apply { snapshot } => {
                *active = snapshot;
                "applied"
            }
        };
        Ack {
            result,
            snapshot: active.clone(),
        }
    }
}

#[derive(Deserialize)]
#[serde(tag = "op", rename_all = "snake_case", deny_unknown_fields)]
enum Command {
    Status,
    Apply { snapshot: Snapshot },
}

#[derive(Serialize)]
struct Ack {
    result: &'static str,
    snapshot: Snapshot,
}

pub async fn serve(path: &Path, routes: Routes) -> io::Result<()> {
    use std::os::unix::fs::PermissionsExt;
    let parent = path
        .parent()
        .ok_or_else(|| io::Error::other("socket needs a directory"))?;
    if std::fs::metadata(parent)?.permissions().mode() & 0o077 != 0 {
        return Err(io::Error::other("socket directory must be private"));
    }
    let listener = UnixListener::bind(path)?;
    std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600))?;
    loop {
        let (stream, _) = listener.accept().await?;
        let _ = timeout(Duration::from_secs(1), exchange(stream, &routes)).await;
    }
}

async fn exchange(mut stream: UnixStream, routes: &Routes) -> io::Result<()> {
    let mut line = Vec::new();
    BufReader::new((&mut stream).take(2049))
        .read_until(b'\n', &mut line)
        .await?;
    if line.len() > 2048 || line.last() != Some(&b'\n') {
        return Err(io::Error::other("invalid admin frame"));
    }
    let command = serde_json::from_slice(&line)?;
    let mut response = serde_json::to_vec(&routes.handle(command))?;
    response.push(b'\n');
    stream.write_all(&response).await
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn generations_and_digest() {
        let routes = Routes::default();
        let apply = |generation, order| {
            routes
                .handle(Command::Apply {
                    snapshot: Snapshot {
                        generation,
                        order,
                        digest: Snapshot::digest(order),
                    },
                })
                .result
        };
        assert_eq!(apply(1, [1, 1]), "invalid");
        assert_eq!(apply(1, [1, 0]), "applied");
        assert_eq!(routes.origin_for(0), 1);
        assert_eq!(apply(1, [1, 0]), "unchanged");
        assert_eq!(apply(1, [0, 1]), "conflict");
        assert_eq!(apply(0, [0, 1]), "stale");
        assert_eq!(routes.origin_for(0), 1);
        assert_eq!(apply(2, [0, 1]), "applied");
    }
}
