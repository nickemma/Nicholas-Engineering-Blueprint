use std::sync::Mutex;
use std::time::{Duration, Instant};

enum Phase {
    Closed { failures: u32 },
    Open { until: Instant },
    Probe,
}

struct State {
    epoch: u64,
    phase: Phase,
}

pub(crate) struct Breaker {
    state: Mutex<State>,
    threshold: u32,
    cooldown: Duration,
}

impl Breaker {
    pub(crate) fn new(threshold: u32, cooldown: Duration) -> Self {
        Self {
            state: Mutex::new(State {
                epoch: 0,
                phase: Phase::Closed { failures: 0 },
            }),
            threshold,
            cooldown,
        }
    }

    pub(crate) fn admit(&self, now: Instant) -> Option<Attempt<'_>> {
        let mut state = self.state.lock().expect("breaker state");
        match state.phase {
            Phase::Closed { .. } => {}
            Phase::Open { until } if now >= until => state.phase = Phase::Probe,
            Phase::Open { .. } | Phase::Probe => return None,
        }
        Some(Attempt {
            breaker: self,
            epoch: state.epoch,
            finished: false,
        })
    }

    fn record(&self, epoch: u64, healthy: bool, now: Instant) {
        let mut state = self.state.lock().expect("breaker state");
        if state.epoch != epoch {
            return;
        }
        let next = match state.phase {
            Phase::Closed { .. } if healthy => Phase::Closed { failures: 0 },
            Phase::Closed { failures } if failures + 1 < self.threshold => Phase::Closed {
                failures: failures + 1,
            },
            Phase::Probe if healthy => Phase::Closed { failures: 0 },
            Phase::Closed { .. } | Phase::Probe => Phase::Open {
                until: now + self.cooldown,
            },
            Phase::Open { .. } => return,
        };
        if matches!(next, Phase::Open { .. }) || matches!(state.phase, Phase::Probe) {
            state.epoch += 1;
        }
        state.phase = next;
    }
}

pub(crate) struct Attempt<'a> {
    breaker: &'a Breaker,
    epoch: u64,
    finished: bool,
}

impl Attempt<'_> {
    pub(crate) fn finish(mut self, healthy: bool, now: Instant) {
        self.finished = true;
        self.breaker.record(self.epoch, healthy, now);
    }
}

impl Drop for Attempt<'_> {
    fn drop(&mut self) {
        if !self.finished {
            self.breaker.record(self.epoch, false, Instant::now());
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn admits_one_probe_reopens_and_recovers() {
        let cooldown = Duration::from_secs(1);
        let breaker = Breaker::new(2, cooldown);
        let now = Instant::now();
        let stale = breaker.admit(now).unwrap();
        for _ in 0..2 {
            breaker.admit(now).unwrap().finish(false, now);
        }

        assert!(breaker.admit(now).is_none());
        let after_cooldown = now + cooldown;
        let probe = breaker.admit(after_cooldown).unwrap();
        stale.finish(true, after_cooldown);
        assert!(breaker.admit(after_cooldown).is_none());
        probe.finish(false, after_cooldown);

        assert!(breaker.admit(after_cooldown).is_none());
        let recovered = after_cooldown + cooldown;
        breaker.admit(recovered).unwrap().finish(true, recovered);
        assert!(breaker.admit(recovered).is_some());
    }

    #[test]
    fn cancelled_probe_releases_recovery_after_cooldown() {
        let cooldown = Duration::from_secs(1);
        let breaker = Breaker::new(1, cooldown);
        let now = Instant::now();
        breaker.admit(now).unwrap().finish(false, now);
        drop(breaker.admit(now + cooldown).unwrap());
        assert!(breaker.admit(Instant::now()).is_none());
        assert!(breaker.admit(Instant::now() + cooldown).is_some());
    }

    #[test]
    fn a_healthy_response_resets_the_failure_count() {
        let breaker = Breaker::new(2, Duration::from_secs(1));
        let now = Instant::now();
        for healthy in [false, true, false] {
            breaker.admit(now).unwrap().finish(healthy, now);
        }
        assert!(breaker.admit(now).is_some());
    }
}
