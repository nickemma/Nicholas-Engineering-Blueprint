use std::convert::Infallible;
use std::io;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::{Duration, Instant};

use crate::admin::Routes;
use crate::breaker::Breaker;

use http_body_util::{BodyExt, Full, LengthLimitError, Limited};
use hyper::body::{Bytes, Incoming};
use hyper::header::{CONNECTION, HOST, HeaderMap, HeaderName, UPGRADE};
use hyper::http::uri::Authority;
use hyper::service::service_fn;
use hyper::{Method, Request, Response, StatusCode, Uri, server};
use hyper_util::client::legacy::{Client, connect::HttpConnector};
use hyper_util::rt::{TokioExecutor, TokioIo, TokioTimer};
use tokio::net::TcpListener;
use tokio::sync::Semaphore;
use tokio::time::timeout;

type Reply = Response<Full<Bytes>>;

const UPSTREAM_TIMEOUT: Duration = Duration::from_millis(750);
const IN_FLIGHT_PER_ORIGIN: usize = 32;

struct Origin {
    authority: Authority,
    slots: Semaphore,
    breaker: Breaker,
}

impl Origin {
    fn new(address: SocketAddr) -> Self {
        Self {
            authority: address.to_string().parse().expect("socket authority"),
            slots: Semaphore::new(IN_FLIGHT_PER_ORIGIN),
            breaker: Breaker::new(3, Duration::from_secs(2)),
        }
    }
}

struct Proxy {
    client: Client<HttpConnector, Full<Bytes>>,
    origins: [Origin; 2],
    routes: Routes,
}

pub async fn serve(listener: TcpListener, origins: [SocketAddr; 2]) -> io::Result<()> {
    serve_managed(listener, origins, Routes::default()).await
}

pub async fn serve_managed(
    listener: TcpListener,
    origins: [SocketAddr; 2],
    routes: Routes,
) -> io::Result<()> {
    if origins[0] == origins[1] {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "HTTP origins must use distinct socket addresses",
        ));
    }
    let mut connector = HttpConnector::new();
    connector.set_connect_timeout(Some(UPSTREAM_TIMEOUT));
    connector.set_nodelay(true);
    let client = Client::builder(TokioExecutor::new())
        .pool_max_idle_per_host(32)
        .pool_idle_timeout(Duration::from_secs(30))
        .pool_timer(TokioTimer::new())
        .retry_canceled_requests(false)
        .build(connector);
    let proxy = Arc::new(Proxy {
        client,
        origins: origins.map(Origin::new),
        routes,
    });
    let slots = Arc::new(Semaphore::new(256));
    loop {
        let (socket, _) = listener.accept().await?;
        let Ok(slot) = slots.clone().try_acquire_owned() else {
            continue;
        };
        if let Err(error) = socket.set_nodelay(true) {
            eprintln!("http socket: {error}");
            continue;
        }
        let proxy = proxy.clone();
        tokio::spawn(async move {
            let _slot = slot;
            let service = service_fn(move |request| {
                let proxy = proxy.clone();
                async move { Ok::<_, Infallible>(proxy.forward(request).await) }
            });
            let _ = server::conn::http1::Builder::new()
                .timer(TokioTimer::new())
                .header_read_timeout(Duration::from_secs(5))
                .serve_connection(TokioIo::new(socket), service)
                .await;
        });
    }
}

impl Proxy {
    async fn forward(&self, request: Request<Incoming>) -> Reply {
        let (mut parts, incoming) = request.into_parts();
        if parts.method == Method::CONNECT
            || parts.uri.scheme().is_some()
            || parts.uri.authority().is_some()
            || parts.headers.contains_key(UPGRADE)
        {
            return reply(StatusCode::BAD_REQUEST, "unsupported request target");
        }

        let origin = match parts.uri.path().split('/').nth(1) {
            Some("a") => &self.origins[self.routes.origin_for(0)],
            Some("b") => &self.origins[self.routes.origin_for(1)],
            _ => return reply(StatusCode::NOT_FOUND, "no route"),
        };
        let target = parts
            .uri
            .path_and_query()
            .expect("matched origin-form path");
        parts.uri = origin_uri(AuthoritySource::Cached(&origin.authority), target.as_str());
        if !strip_connection_headers(&mut parts.headers) {
            return reply(StatusCode::BAD_REQUEST, "invalid connection header");
        }
        for name in [
            HOST.as_str(),
            "forwarded",
            "x-forwarded-for",
            "x-forwarded-host",
            "x-forwarded-proto",
            "x-forwarded-port",
        ] {
            parts.headers.remove(name);
        }

        let body = match timeout(
            Duration::from_secs(2),
            Limited::new(incoming, 64 * 1024).collect(),
        )
        .await
        {
            Ok(Ok(body)) => body.to_bytes(),
            Ok(Err(error)) if error.is::<LengthLimitError>() => {
                return reply(StatusCode::PAYLOAD_TOO_LARGE, "request body too large");
            }
            Ok(Err(_)) => return reply(StatusCode::BAD_REQUEST, "incomplete request body"),
            Err(_) => return reply(StatusCode::REQUEST_TIMEOUT, "request body timed out"),
        };
        let request = Request::from_parts(parts, Full::new(body));

        let Ok(_slot) = origin.slots.try_acquire() else {
            return reply(StatusCode::SERVICE_UNAVAILABLE, "origin at capacity");
        };
        let Some(attempt) = origin.breaker.admit(Instant::now()) else {
            return reply(StatusCode::SERVICE_UNAVAILABLE, "origin circuit open");
        };
        let outcome = timeout(UPSTREAM_TIMEOUT, self.exchange(request)).await;
        let healthy = matches!(&outcome, Ok(Ok(response)) if !response.status().is_server_error());
        attempt.finish(healthy, Instant::now());
        match outcome {
            Ok(Ok(response)) => response,
            Ok(Err(status)) => reply(status, "upstream response failed"),
            Err(_) => reply(StatusCode::GATEWAY_TIMEOUT, "upstream timed out"),
        }
    }

    async fn exchange(&self, request: Request<Full<Bytes>>) -> Result<Reply, StatusCode> {
        let response = self
            .client
            .request(request)
            .await
            .map_err(|_| StatusCode::BAD_GATEWAY)?;
        let (mut parts, body) = response.into_parts();
        if !strip_connection_headers(&mut parts.headers) {
            return Err(StatusCode::BAD_GATEWAY);
        }
        let body = Limited::new(body, 256 * 1024)
            .collect()
            .await
            .map_err(|_| StatusCode::BAD_GATEWAY)?;
        Ok(Response::from_parts(parts, Full::new(body.to_bytes())))
    }
}

enum AuthoritySource<'a> {
    Cached(&'a Authority),
    #[cfg(feature = "cpu-profile")]
    Format(SocketAddr),
}

fn origin_uri(source: AuthoritySource<'_>, target: &str) -> Uri {
    let authority = match source {
        AuthoritySource::Cached(authority) => authority.clone(),
        #[cfg(feature = "cpu-profile")]
        AuthoritySource::Format(address) => address.to_string().parse().expect("socket authority"),
    };
    Uri::builder()
        .scheme("http")
        .authority(authority)
        .path_and_query(target)
        .build()
        .expect("configured socket address and parsed request target")
}

#[cfg(feature = "cpu-profile")]
pub mod profile;

fn strip_connection_headers(headers: &mut HeaderMap) -> bool {
    let mut named = Vec::new();
    for value in headers.get_all(CONNECTION) {
        let Ok(value) = value.to_str() else {
            return false;
        };
        for name in value
            .split(',')
            .map(str::trim)
            .filter(|name| !name.is_empty())
        {
            let Ok(name) = HeaderName::from_bytes(name.as_bytes()) else {
                return false;
            };
            named.push(name);
        }
    }
    for name in named {
        headers.remove(name);
    }
    for name in [
        "connection",
        "keep-alive",
        "proxy-authenticate",
        "proxy-authorization",
        "proxy-connection",
        "te",
        "trailer",
        "transfer-encoding",
        "upgrade",
    ] {
        headers.remove(name);
    }
    true
}

fn reply(status: StatusCode, body: &'static str) -> Reply {
    Response::builder()
        .status(status)
        .body(Full::new(Bytes::from_static(body.as_bytes())))
        .expect("fixed response")
}
