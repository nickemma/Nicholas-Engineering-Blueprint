use std::net::SocketAddr;
use std::path::Path;

use tokio::net::TcpListener;

#[tokio::main(worker_threads = 2)]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args().skip(1).collect();
    match args.as_slice() {
        [mode, listen, upstream] if mode == "tcp" => {
            let address: SocketAddr = upstream.parse()?;
            let listener = TcpListener::bind(listen).await?;
            println!("listening {}", listener.local_addr()?);
            switchyard_edge::tcp::serve(listener, address).await?;
        }
        [mode, listen, first, second] if mode == "http" => {
            let origins = [first.parse()?, second.parse()?];
            let listener = TcpListener::bind(listen).await?;
            println!("listening {}", listener.local_addr()?);
            switchyard_edge::http::serve(listener, origins).await?;
        }
        [mode, listen, first, second, socket] if mode == "managed" => {
            let listener = TcpListener::bind(listen).await?;
            let origins = [first.parse()?, second.parse()?];
            let routes = switchyard_edge::admin::Routes::default();
            println!("listening {}", listener.local_addr()?);
            tokio::try_join!(
                switchyard_edge::admin::serve(Path::new(socket), routes.clone()),
                switchyard_edge::http::serve_managed(listener, origins, routes)
            )?;
        }
        #[cfg(feature = "cpu-profile")]
        [mode, variant, operations, destination] if mode == "profile-route" => {
            switchyard_edge::http::profile::run(variant, operations, destination)?;
        }
        _ => {
            return Err(
                "usage: switchyard-edge tcp LISTEN UPSTREAM | http LISTEN ORIGIN_A ORIGIN_B | managed LISTEN ORIGIN_A ORIGIN_B SOCKET".into(),
            );
        }
    }
    Ok(())
}
