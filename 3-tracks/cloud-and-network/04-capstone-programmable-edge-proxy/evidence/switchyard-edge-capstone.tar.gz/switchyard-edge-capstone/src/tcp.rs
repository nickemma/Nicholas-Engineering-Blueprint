use std::io;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Duration;

use tokio::io::copy_bidirectional;
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::Semaphore;
use tokio::time::timeout;

pub async fn serve(listener: TcpListener, upstream: SocketAddr) -> io::Result<()> {
    let slots = Arc::new(Semaphore::new(128));
    loop {
        let (stream, _) = listener.accept().await?;
        if let Ok(slot) = slots.clone().try_acquire_owned() {
            tokio::spawn(async move {
                let _slot = slot;
                if let Err(error) = relay(stream, upstream).await {
                    eprintln!("tcp relay: {error}");
                }
            });
        }
    }
}

async fn relay(mut downstream: TcpStream, upstream: SocketAddr) -> io::Result<()> {
    let mut upstream = timeout(Duration::from_secs(2), TcpStream::connect(upstream)).await??;
    timeout(
        Duration::from_secs(30),
        copy_bidirectional(&mut downstream, &mut upstream),
    )
    .await??;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use tokio::io::{AsyncReadExt, AsyncWriteExt};

    #[tokio::test]
    async fn relays_bytes_after_client_half_close() -> io::Result<()> {
        let origin = TcpListener::bind("127.0.0.1:0").await?;
        let origin_address = origin.local_addr()?;
        let edge = TcpListener::bind("127.0.0.1:0").await?;
        let edge_address = edge.local_addr()?;
        let server = tokio::spawn(serve(edge, origin_address));
        timeout(Duration::from_secs(2), async {
            let mut client = TcpStream::connect(edge_address).await?;
            let (mut upstream, _) = origin.accept().await?;
            client.write_all(b"\x00request\xff").await?;
            client.shutdown().await?;
            let mut request = Vec::new();
            upstream.read_to_end(&mut request).await?;
            assert_eq!(request, b"\x00request\xff");

            upstream.write_all(b"\xffresponse\x00").await?;
            upstream.shutdown().await?;
            let mut response = Vec::new();
            client.read_to_end(&mut response).await?;
            assert_eq!(response, b"\xffresponse\x00");
            Ok::<(), io::Error>(())
        })
        .await??;
        server.abort();
        Ok(())
    }
}
