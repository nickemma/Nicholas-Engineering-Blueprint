#!/usr/bin/env bash
set -euo pipefail

source_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
cache=${1:?provide a dependency cache directory}
classes=${2:?provide a Java class output directory}
mkdir -p "$cache" "$classes"
while read -r digest artifact; do
    jar="$cache/${artifact##*/}"
    if [[ ! -f "$jar" ]]; then
        pending=$(mktemp "$cache/.download-XXXXXX")
        trap 'rm -f "$pending"' EXIT
        curl -fsSL --max-time 60 "https://repo.maven.apache.org/maven2/$artifact" -o "$pending"
        echo "$digest  $pending" | sha256sum --check --status
        mv "$pending" "$jar"
        trap - EXIT
    fi
    echo "$digest  $jar" | sha256sum --check --status
done < "$source_dir/dependencies.tsv"
classpath="$cache/core-0.17.0.jar:$cache/htrace-core4-4.1.0-incubating.jar:$cache/jackson-core-asl-1.9.4.jar:$cache/jackson-mapper-asl-1.9.4.jar:$cache/HdrHistogram-2.1.4.jar"
javac -cp "$classpath" -d "$classes" "$source_dir/SwitchyardDB.java"
echo "$classes:$classpath"
