import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Vector;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;

import site.ycsb.ByteIterator;
import site.ycsb.DB;
import site.ycsb.DBException;
import site.ycsb.Status;
import site.ycsb.StringByteIterator;

public final class SwitchyardDB extends DB {
  private final ObjectMapper json = new ObjectMapper();
  private final String client = UUID.randomUUID().toString();
  private String[] servers;
  private String token;
  private long sequence;
  private int preferred;

  @Override
  public void init() throws DBException {
    String endpoints = getProperties().getProperty("switchyard.endpoints", "");
    token = getProperties().getProperty("switchyard.token", "");
    servers = endpoints.split(",");
    if (servers.length != 3 || token.isEmpty()) {
      throw new DBException("provide three peer URLs and a fixture token");
    }
  }

  private static final class Reply {
    final Status status;
    final String value;

    Reply(Status status, String value) {
      this.status = status;
      this.value = value;
    }
  }

  private Reply send(String operation, String key, String value) {
    Map<String, Object> request = new HashMap<>();
    request.put("op", operation);
    request.put("key", key);
    if (!operation.equals("get")) {
      request.put("client", client);
      request.put("sequence", ++sequence);
      if (value != null) {
        request.put("value", value);
      }
    }
    for (int attempt = 0; attempt < 6; ++attempt) {
      HttpURLConnection connection = null;
      int next = (preferred + 1) % servers.length;
      try {
        connection = (HttpURLConnection) URI.create(servers[preferred] + "/kv").toURL().openConnection();
        connection.setConnectTimeout(800);
        connection.setReadTimeout(1800);
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Authorization", "Bearer " + token);
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setDoOutput(true);
        byte[] encoded = json.writeValueAsBytes(request);
        connection.setFixedLengthStreamingMode(encoded.length);
        try (var output = connection.getOutputStream()) {
          output.write(encoded);
        }
        int code = connection.getResponseCode();
        try (var input = code < 400 ? connection.getInputStream() : connection.getErrorStream()) {
          byte[] body = input == null ? new byte[0] : input.readNBytes(8193);
          if (body.length > 8192) {
            return new Reply(Status.ERROR, null);
          }
          if (code == 200) {
            JsonNode response = json.readTree(body);
            if (response.has("error") || !response.has("found")) {
              return new Reply(Status.ERROR, null);
            }
            if (!response.get("found").asBoolean()) {
              return new Reply(Status.NOT_FOUND, null);
            }
            return new Reply(Status.OK, response.has("value") ? response.get("value").asText() : "");
          }
          if (code == 409 && body.length != 0) {
            JsonNode leader = json.readTree(body).get("leader");
            if (leader != null && leader.asInt() >= 1 && leader.asInt() <= servers.length) {
              next = leader.asInt() - 1;
            }
          } else if (code != 503 && code != 504) {
            return new Reply(Status.ERROR, null);
          }
        }
      } catch (IOException failure) {
        // An interrupted response can be retried with the original sequence.
      } finally {
        if (connection != null) {
          connection.disconnect();
        }
      }
      preferred = next;
    }
    return new Reply(Status.ERROR, null);
  }

  @Override
  public Status read(String table, String key, Set<String> fields, Map<String, ByteIterator> result) {
    if (fields != null && !fields.equals(Set.of("field0"))) {
      return Status.NOT_IMPLEMENTED;
    }
    Reply response = send("get", table + ":" + key, null);
    if (response.status.isOk() && result != null) {
      result.put("field0", new StringByteIterator(response.value));
    }
    return response.status;
  }

  @Override
  public Status update(String table, String key, Map<String, ByteIterator> values) {
    ByteIterator value = values.get("field0");
    if (values.size() != 1 || value == null) {
      return Status.NOT_IMPLEMENTED;
    }
    return send("put", table + ":" + key, new String(value.toArray(), StandardCharsets.UTF_8)).status;
  }

  @Override
  public Status insert(String table, String key, Map<String, ByteIterator> values) {
    return update(table, key, values);
  }

  @Override
  public Status delete(String table, String key) {
    return send("delete", table + ":" + key, null).status;
  }

  @Override
  public Status scan(String table, String key, int count, Set<String> fields,
      Vector<HashMap<String, ByteIterator>> result) {
    return Status.NOT_IMPLEMENTED;
  }
}
