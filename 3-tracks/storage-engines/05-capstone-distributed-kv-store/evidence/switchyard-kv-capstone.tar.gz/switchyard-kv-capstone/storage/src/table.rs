use std::fs::File;
use std::io::{self, Write};
use std::os::unix::fs::FileExt;
use std::path::Path;

use crate::ProbeStats;
use crate::bloom::Bloom;
use crate::codec::{Cursor, MAX_KEY, invalid, u32_to, u64_to};
use crate::disk::{read_frame, write_frame};
use crate::entry::Entry;

const MAGIC: &[u8] = b"LST2";
const BLOCK_ENTRIES: usize = 16;
const FOOTER_SIZE: u64 = (klog::record::HEADER_LEN + 8) as u64;

struct Block {
    first: Vec<u8>,
    last: Vec<u8>,
    start: u64,
    end: u64,
}

impl Block {
    fn encode(&self) -> Vec<u8> {
        let mut data = Vec::new();
        u64_to(&mut data, self.start);
        u64_to(&mut data, self.end);
        for key in [&self.first, &self.last] {
            u32_to(&mut data, key.len() as u32);
            data.extend(key);
        }
        data
    }

    fn decode(data: &[u8]) -> io::Result<Self> {
        let mut cursor = Cursor::new(data);
        let start = cursor.u64()?;
        let end = cursor.u64()?;
        let first = key(&mut cursor)?;
        let last = key(&mut cursor)?;
        cursor.done()?;
        if first > last || start >= end {
            return Err(invalid("invalid block bounds"));
        }
        Ok(Self {
            first,
            last,
            start,
            end,
        })
    }
}

fn key(cursor: &mut Cursor<'_>) -> io::Result<Vec<u8>> {
    let len = cursor.u32()? as usize;
    if len > MAX_KEY {
        return Err(invalid("oversized index key"));
    }
    Ok(cursor.take(len)?.to_vec())
}

pub struct Table {
    file: File,
    blocks: Vec<Block>,
    filter: Option<Bloom>,
}

impl Table {
    pub fn create(path: &Path, entries: &[Entry]) -> io::Result<Self> {
        if entries.is_empty() || !entries.windows(2).all(|pair| ordered(&pair[0], &pair[1])) {
            return Err(invalid("tables require sorted nonempty input"));
        }
        let mut file = File::create_new(path)?;
        file.write_all(MAGIC)?;
        let mut at = MAGIC.len() as u64;
        let mut blocks = Vec::new();
        for chunk in entries.chunks(BLOCK_ENTRIES) {
            let mut data = Vec::new();
            u32_to(&mut data, chunk.len() as u32);
            for entry in chunk {
                entry.encode(&mut data);
            }
            let end = at + write_frame(&mut file, &data)?;
            blocks.push(Block {
                first: chunk[0].key.clone(),
                last: chunk.last().unwrap().key.clone(),
                start: at,
                end,
            });
            at = end;
        }
        let mut filter = Bloom::new(entries.len());
        for entry in entries {
            filter.insert(&entry.key);
        }
        write_frame(&mut file, filter.raw())?;
        for block in blocks {
            write_frame(&mut file, &block.encode())?;
        }
        write_frame(&mut file, &at.to_le_bytes())?;
        file.sync_all()?;
        Self::open(path)
    }

    pub fn open(path: &Path) -> io::Result<Self> {
        let file = File::open(path)?;
        let end = file.metadata()?.len();
        let footer = end
            .checked_sub(FOOTER_SIZE)
            .ok_or_else(|| invalid("missing table footer"))?;
        let mut magic = [0; 4];
        file.read_exact_at(&mut magic, 0)?;
        if magic != MAGIC && &magic != b"LST1" {
            return Err(invalid("unknown table format"));
        }
        let (data, next) = read_frame(&file, footer, end)?;
        let mut cursor = Cursor::new(&data);
        let index = cursor.u64()?;
        cursor.done()?;
        if next != end || index <= MAGIC.len() as u64 || index >= footer {
            return Err(invalid("invalid table index offset"));
        }
        let (mut at, filter) = if magic == MAGIC {
            let (data, first) = read_frame(&file, index, footer)?;
            let filter =
                Bloom::decode(data).ok_or_else(|| invalid("invalid Bloom filter length"))?;
            (first, Some(filter))
        } else {
            (index, None)
        };
        let mut expected = MAGIC.len() as u64;
        let mut blocks: Vec<Block> = Vec::new();
        while at < footer {
            let (data, next) = read_frame(&file, at, footer)?;
            let block = Block::decode(&data)?;
            if block.start != expected
                || block.end > index
                || blocks
                    .last()
                    .is_some_and(|previous| previous.last > block.first)
            {
                return Err(invalid("invalid table block layout"));
            }
            expected = block.end;
            blocks.push(block);
            at = next;
        }
        if blocks.is_empty() || expected != index {
            return Err(invalid("index does not cover table data"));
        }
        Ok(Self {
            file,
            blocks,
            filter,
        })
    }

    fn read(&self, block: &Block) -> io::Result<Vec<Entry>> {
        let (data, next) = read_frame(&self.file, block.start, block.end)?;
        let mut cursor = Cursor::new(&data);
        let count = cursor.u32()? as usize;
        if count == 0 || count > BLOCK_ENTRIES || block.end != next {
            return Err(invalid("invalid block entry count or length"));
        }
        let entries = (0..count)
            .map(|_| Entry::decode(&mut cursor))
            .collect::<io::Result<Vec<_>>>()?;
        cursor.done()?;
        if entries[0].key != block.first
            || entries[count - 1].key != block.last
            || !entries.windows(2).all(|pair| ordered(&pair[0], &pair[1]))
        {
            return Err(invalid("block entries disagree with index"));
        }
        Ok(entries)
    }

    pub fn point(
        &self,
        key: &[u8],
        use_filter: bool,
        stats: &mut ProbeStats,
    ) -> io::Result<Vec<Entry>> {
        let filter = self.filter.as_ref().filter(|_| use_filter);
        if filter.is_some_and(|filter| !filter.may_contain(key)) {
            stats.filter_negatives += 1;
            return Ok(Vec::new());
        }
        let index = self
            .blocks
            .partition_point(|block| block.last.as_slice() < key);
        let mut matches = Vec::new();
        for block in &self.blocks[index..] {
            if block.first.as_slice() > key {
                break;
            }
            stats.block_reads += 1;
            matches.extend(
                self.read(block)?
                    .into_iter()
                    .filter(|entry| entry.key == key),
            );
        }
        if filter.is_some() && matches.is_empty() {
            stats.false_positives += 1;
        }
        Ok(matches)
    }

    pub fn bytes(&self) -> io::Result<u64> {
        Ok(self.file.metadata()?.len())
    }

    pub fn all(&self) -> impl Iterator<Item = io::Result<Entry>> + '_ {
        TableScan::new(self, 0, None)
    }

    pub fn range<'a>(
        &'a self,
        start: &'a [u8],
        end: &'a [u8],
    ) -> impl Iterator<Item = io::Result<Entry>> + 'a {
        let index = self
            .blocks
            .partition_point(|block| block.last.as_slice() < start);
        TableScan::new(self, index, Some((start, end)))
    }
}

struct TableScan<'a> {
    table: &'a Table,
    blocks: std::slice::Iter<'a, Block>,
    entries: std::vec::IntoIter<Entry>,
    bounds: Option<(&'a [u8], &'a [u8])>,
}

impl<'a> TableScan<'a> {
    fn new(table: &'a Table, from: usize, bounds: Option<(&'a [u8], &'a [u8])>) -> Self {
        Self {
            table,
            blocks: table.blocks[from..].iter(),
            entries: Vec::new().into_iter(),
            bounds,
        }
    }
}

impl Iterator for TableScan<'_> {
    type Item = io::Result<Entry>;

    fn next(&mut self) -> Option<Self::Item> {
        loop {
            for entry in self.entries.by_ref() {
                if self.bounds.is_none_or(|(start, end)| {
                    start <= entry.key.as_slice() && entry.key.as_slice() < end
                }) {
                    return Some(Ok(entry));
                }
            }
            let block = self.blocks.next()?;
            if self
                .bounds
                .is_some_and(|(_, end)| block.first.as_slice() >= end)
            {
                self.blocks = [].iter();
                return None;
            }
            match self.table.read(block) {
                Ok(entries) => self.entries = entries.into_iter(),
                Err(error) => {
                    self.blocks = [].iter();
                    return Some(Err(error));
                }
            }
        }
    }
}

fn ordered(a: &Entry, b: &Entry) -> bool {
    a.key < b.key || (a.key == b.key && a.version.seq > b.version.seq)
}
