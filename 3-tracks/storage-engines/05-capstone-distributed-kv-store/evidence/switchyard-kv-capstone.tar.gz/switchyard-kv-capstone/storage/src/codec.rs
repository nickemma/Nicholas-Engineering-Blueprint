use std::io;

pub const MAX_KEY: usize = 1024;
pub const MAX_VALUE: usize = 32 * 1024;

pub fn invalid(message: impl Into<String>) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, message.into())
}

pub fn u32_to(out: &mut Vec<u8>, number: u32) {
    out.extend(number.to_le_bytes());
}

pub fn u64_to(out: &mut Vec<u8>, number: u64) {
    out.extend(number.to_le_bytes());
}

pub struct Cursor<'a>(&'a [u8]);

impl<'a> Cursor<'a> {
    pub fn new(input: &'a [u8]) -> Self {
        Self(input)
    }

    pub fn take(&mut self, len: usize) -> io::Result<&'a [u8]> {
        let (value, rest) = self
            .0
            .split_at_checked(len)
            .ok_or_else(|| invalid("short payload"))?;
        self.0 = rest;
        Ok(value)
    }

    pub fn u32(&mut self) -> io::Result<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }

    pub fn u64(&mut self) -> io::Result<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }

    pub fn done(self) -> io::Result<()> {
        if self.0.is_empty() {
            Ok(())
        } else {
            Err(invalid("unexpected trailing bytes"))
        }
    }
}
