use std::collections::BTreeMap;
use std::sync::{Arc, Mutex};

#[derive(Default)]
pub struct Pins(Arc<Mutex<BTreeMap<u64, usize>>>);

pub struct Snapshot {
    owner: Arc<Mutex<BTreeMap<u64, usize>>>,
    sequence: u64,
}

impl Snapshot {
    pub fn sequence(&self) -> u64 {
        self.sequence
    }
}

impl Pins {
    pub fn pin(&self, sequence: u64) -> Snapshot {
        *self.0.lock().unwrap().entry(sequence).or_default() += 1;
        Snapshot {
            owner: self.0.clone(),
            sequence,
        }
    }

    pub fn oldest(&self) -> Option<u64> {
        self.0
            .lock()
            .unwrap()
            .first_key_value()
            .map(|(&sequence, _)| sequence)
    }

    pub fn owns(&self, snapshot: &Snapshot) -> bool {
        Arc::ptr_eq(&self.0, &snapshot.owner)
    }
}

impl Drop for Snapshot {
    fn drop(&mut self) {
        let mut pins = self.owner.lock().unwrap();
        let count = pins.get_mut(&self.sequence).unwrap();
        *count -= 1;
        if *count == 0 {
            pins.remove(&self.sequence);
        }
    }
}
