use std::fmt::Write as _;
use std::io;
use std::path::Path;
use std::process::ExitCode;

use lsm::Store;

fn usage() -> io::Error {
    io::Error::new(
        io::ErrorKind::InvalidInput,
        "usage: lsm DIR {put KEY VALUE|delete KEY|get KEY|scan START END|flush|compact|state}; keys and values are hex",
    )
}

fn hex(input: &str) -> io::Result<Vec<u8>> {
    let invalid = || {
        io::Error::new(
            io::ErrorKind::InvalidInput,
            "expected pairs of hexadecimal digits",
        )
    };
    if !input.len().is_multiple_of(2) || !input.bytes().all(|byte| byte.is_ascii_hexdigit()) {
        return Err(invalid());
    }
    input
        .as_bytes()
        .chunks_exact(2)
        .map(|pair| {
            let text = std::str::from_utf8(pair).map_err(|_| invalid())?;
            u8::from_str_radix(text, 16).map_err(|_| invalid())
        })
        .collect()
}

fn display(bytes: &[u8]) -> String {
    let mut out = String::with_capacity(bytes.len() * 2);
    for byte in bytes {
        write!(out, "{byte:02x}").unwrap();
    }
    out
}

fn run(dir: &Path, operation: &str, args: &[String]) -> io::Result<()> {
    let mut db = Store::open(dir)?;
    match (operation, args) {
        ("put", [key, value]) => println!("ok {}", db.put(&hex(key)?, &hex(value)?)?),
        ("delete", [key]) => println!("ok {}", db.delete(&hex(key)?)?),
        ("get", [key]) => match db.get(&hex(key)?)? {
            Some(value) => println!("value {}", display(&value)),
            None => println!("absent"),
        },
        ("scan", [start, end]) => {
            for (key, value) in db.scan(&hex(start)?, &hex(end)?)? {
                println!("{}={}", display(&key), display(&value));
            }
        }
        ("flush", []) => {
            db.flush()?;
            println!("flushed {}", db.state().covered);
        }
        ("compact", []) => {
            let stats = db.compact()?;
            println!(
                "compacted {} runs, {} -> {} versions, {} -> {} bytes",
                stats.input_runs,
                stats.input_versions,
                stats.retained_versions,
                stats.input_bytes,
                stats.output_bytes
            );
        }
        ("state", []) => {
            let state = db.state();
            let runs = state
                .runs
                .iter()
                .map(u64::to_string)
                .collect::<Vec<_>>()
                .join(",");
            println!(
                "sequence={} covered={} generation={} wal={} runs={} trimmed={}",
                state.sequence,
                state.covered,
                state.generation,
                state.wal,
                runs,
                db.recovered_bytes()
            );
        }
        _ => return Err(usage()),
    }
    Ok(())
}

fn main() -> ExitCode {
    let mut args = std::env::args_os().skip(1);
    let result = (|| {
        let dir = args.next().ok_or_else(usage)?;
        let op = args
            .next()
            .and_then(|arg| arg.into_string().ok())
            .ok_or_else(usage)?;
        let args = args
            .map(|arg| arg.into_string().map_err(|_| usage()))
            .collect::<io::Result<Vec<_>>>()?;
        run(Path::new(&dir), &op, &args)
    })();
    if let Err(error) = result {
        eprintln!("{error}");
        ExitCode::FAILURE
    } else {
        ExitCode::SUCCESS
    }
}
