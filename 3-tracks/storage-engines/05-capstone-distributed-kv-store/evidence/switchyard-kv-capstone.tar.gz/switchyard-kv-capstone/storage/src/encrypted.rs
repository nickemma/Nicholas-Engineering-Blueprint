use std::{
    collections::BTreeMap,
    fs::File,
    io::{self, Read},
    path::Path,
};

use aes_gcm::{
    Aes256Gcm, KeyInit,
    aead::{Aead, Payload},
};

use crate::{Namespace, Row, TenantSnapshot};

const VERSION: u8 = 1;
const HEADER: usize = 5;
const NONCE: usize = 12;
const TAG: usize = 16;

pub struct Keyring {
    active: u32,
    keys: BTreeMap<u32, Aes256Gcm>,
}

impl Keyring {
    /// Read an operator-supplied file of numeric-id:hex-key lines.
    /// The caller keeps this file outside the database directory.
    pub fn load(path: &Path, active: u32) -> io::Result<Self> {
        let mut text = String::new();
        File::open(path)?.take(4097).read_to_string(&mut text)?;
        if text.len() > 4096 {
            return Err(invalid("keyring exceeds size limit"));
        }
        let mut keys = BTreeMap::new();
        for line in text.lines() {
            let (id, raw) = line
                .split_once(':')
                .ok_or_else(|| invalid("invalid keyring row"))?;
            let id: u32 = id.parse().map_err(|_| invalid("invalid key ID"))?;
            if id == 0 || raw.len() != 64 || !raw.as_bytes().iter().all(u8::is_ascii_hexdigit) {
                return Err(invalid("invalid key ID or AES-256 key length"));
            }
            let mut key = [0_u8; 32];
            for (dest, pair) in key.iter_mut().zip(raw.as_bytes().chunks_exact(2)) {
                *dest = u8::from_str_radix(std::str::from_utf8(pair).unwrap(), 16).unwrap();
            }
            if keys.insert(id, Aes256Gcm::new(&key.into())).is_some() {
                return Err(invalid("duplicate key ID"));
            }
        }
        if !keys.contains_key(&active) {
            return Err(invalid("active key ID unavailable"));
        }
        Ok(Self { active, keys })
    }

    pub fn seal(&self, physical: &[u8], value: &[u8]) -> io::Result<Vec<u8>> {
        if value.len() > 32 * 1024 - HEADER - NONCE - TAG {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "value exceeds encrypted storage limit",
            ));
        }
        let mut out = vec![VERSION];
        out.extend(self.active.to_be_bytes());
        let aad = associated_data(&out, physical);
        let mut nonce = [0; NONCE];
        getrandom::fill(&mut nonce).map_err(|_| io::Error::other("entropy unavailable"))?;
        let cipher = self
            .keys
            .get(&self.active)
            .ok_or_else(|| invalid("active key ID unavailable"))?;
        let encrypted = cipher
            .encrypt(
                &nonce.into(),
                Payload {
                    msg: value,
                    aad: &aad,
                },
            )
            .map_err(|_| invalid("value encryption failed"))?;
        out.extend(nonce);
        out.extend(encrypted);
        Ok(out)
    }

    pub fn open(&self, physical: &[u8], encrypted: &[u8]) -> io::Result<Vec<u8>> {
        if encrypted.len() < HEADER + NONCE + TAG || encrypted[0] != VERSION {
            return Err(invalid("unsupported or truncated value envelope"));
        }
        let id = u32::from_be_bytes(encrypted[1..HEADER].try_into().unwrap());
        let cipher = self
            .keys
            .get(&id)
            .ok_or_else(|| invalid("value key ID unavailable"))?;
        let nonce: [u8; NONCE] = encrypted[HEADER..HEADER + NONCE].try_into().unwrap();
        let aad = associated_data(&encrypted[..HEADER], physical);
        cipher
            .decrypt(
                &nonce.into(),
                Payload {
                    msg: &encrypted[HEADER + NONCE..],
                    aad: &aad,
                },
            )
            .map_err(|_| invalid("value authentication failed"))
    }
}

fn invalid(message: &str) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, message)
}

fn associated_data(header: &[u8], physical: &[u8]) -> Vec<u8> {
    [b"switchyard/lsm/value\0".as_slice(), header, physical].concat()
}

pub struct EncryptedNamespace<'a> {
    inner: Namespace<'a>,
    keys: &'a Keyring,
}

impl<'a> EncryptedNamespace<'a> {
    pub fn new(inner: Namespace<'a>, keys: &'a Keyring) -> Self {
        Self { inner, keys }
    }

    pub fn put(&mut self, key: &[u8], value: &[u8]) -> io::Result<u64> {
        let encrypted = self.keys.seal(&self.inner.tenant.physical(key)?, value)?;
        self.inner.put(key, &encrypted)
    }

    pub fn delete(&mut self, key: &[u8]) -> io::Result<u64> {
        self.inner.delete(key)
    }

    pub fn get(&self, key: &[u8]) -> io::Result<Option<Vec<u8>>> {
        self.decrypt(key, self.inner.get(key)?)
    }

    pub fn get_at(&self, key: &[u8], pin: &TenantSnapshot) -> io::Result<Option<Vec<u8>>> {
        self.decrypt(key, self.inner.get_at(key, pin)?)
    }

    pub fn snapshot(&self) -> TenantSnapshot {
        self.inner.snapshot()
    }

    pub fn scan(
        &self,
        start: Option<&[u8]>,
        end: Option<&[u8]>,
        pin: Option<&TenantSnapshot>,
    ) -> io::Result<Vec<Row>> {
        self.inner
            .scan(start, end, pin)?
            .into_iter()
            .map(|(key, envelope)| {
                let value = self
                    .keys
                    .open(&self.inner.tenant.physical(&key)?, &envelope)?;
                Ok((key, value))
            })
            .collect()
    }

    fn decrypt(&self, key: &[u8], value: Option<Vec<u8>>) -> io::Result<Option<Vec<u8>>> {
        value
            .map(|envelope| self.keys.open(&self.inner.tenant.physical(key)?, &envelope))
            .transpose()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::namespace::tests::Temp;
    use crate::{Store, Tenant};
    use std::fs::{self, OpenOptions};
    use std::io::Write;

    #[test]
    fn encrypted_values_survive_rotation_and_refuse_invalid_contexts() -> io::Result<()> {
        let directory = Temp::new("encryption")?;
        let data = directory.0.join("data");
        let path = directory.0.join("external-keys");
        let mut file = OpenOptions::new()
            .write(true)
            .create_new(true)
            .mode(0o600)
            .open(&path)?;
        writeln!(file, "1:{}", "12".repeat(32))?;
        writeln!(file, "2:{}", "34".repeat(32))?;
        drop(file);
        let first = Keyring::load(&path, 1)?;
        let rotated = Keyring::load(&path, 2)?;

        let a = Tenant::from_authorized(b"acme")?;
        let b = Tenant::from_authorized(b"beta")?;
        let mut db = Store::open(&data)?;
        let old = b"canary-private-revision-one";
        let new = b"canary-private-revision-two";
        let mut scoped = EncryptedNamespace::new(a.handle(&mut db), &first);
        scoped.put(b"job", old)?;
        let pin = scoped.snapshot();
        assert_canaries_absent(&data, &[old, new])?;
        db.flush()?;
        let mut scoped = EncryptedNamespace::new(a.handle(&mut db), &rotated);
        scoped.put(b"job", new)?;
        scoped.put(b"empty", b"")?;
        assert_eq!(scoped.get_at(b"job", &pin)?, Some(old.to_vec()));
        assert_eq!(
            scoped.scan(None, None, Some(&pin))?,
            vec![(b"job".to_vec(), old.to_vec())]
        );
        assert_canaries_absent(&data, &[old, new])?;
        db.flush()?;
        db.compact()?;
        assert_eq!(
            EncryptedNamespace::new(a.handle(&mut db), &rotated).get_at(b"job", &pin)?,
            Some(old.to_vec())
        );
        assert_canaries_absent(&data, &[old, new])?;
        drop(pin);
        drop(db);

        let mut db = Store::open(&data)?;
        assert_eq!(
            EncryptedNamespace::new(a.handle(&mut db), &rotated).scan(None, None, None)?,
            vec![(b"empty".to_vec(), vec![]), (b"job".to_vec(), new.to_vec())]
        );
        let ciphertext = a.handle(&mut db).get(b"job")?.unwrap();
        assert_eq!(&ciphertext[1..5], &2_u32.to_be_bytes());
        b.handle(&mut db).put(b"job", &ciphertext)?;
        a.handle(&mut db).put(b"other", &ciphertext)?;
        for (tenant, key) in [(&b, b"job".as_slice()), (&a, b"other")] {
            let err = EncryptedNamespace::new(tenant.handle(&mut db), &rotated)
                .get(key)
                .unwrap_err();
            assert_eq!(err.to_string(), "value authentication failed");
        }
        let mut changed = ciphertext.clone();
        *changed.last_mut().unwrap() ^= 1;
        a.handle(&mut db).put(b"job", &changed)?;
        let err = EncryptedNamespace::new(a.handle(&mut db), &rotated)
            .get(b"job")
            .unwrap_err();
        assert_eq!(err.to_string(), "value authentication failed");
        a.handle(&mut db).put(b"job", &ciphertext)?;
        let mut changed = ciphertext;
        changed[1..5].copy_from_slice(&3_u32.to_be_bytes());
        a.handle(&mut db).put(b"job", &changed)?;
        let err = EncryptedNamespace::new(a.handle(&mut db), &rotated)
            .get(b"job")
            .unwrap_err();
        assert_eq!(err.to_string(), "value key ID unavailable");
        println!(
            "rotated values and historical reads verified; ciphertext changes, relocation, and unknown key IDs refused"
        );
        Ok(())
    }

    use std::os::unix::fs::OpenOptionsExt;

    fn assert_canaries_absent(data: &Path, canaries: &[&[u8]]) -> io::Result<()> {
        for file in fs::read_dir(data)? {
            let file = file?;
            let name = file.file_name();
            if name
                .to_str()
                .is_some_and(|n| n.starts_with("wal-") || n.starts_with("run-"))
            {
                let bytes = fs::read(file.path())?;
                for canary in canaries {
                    assert!(
                        !bytes.windows(canary.len()).any(|bytes| bytes == *canary),
                        "plaintext canary in {name:?}"
                    );
                }
            }
        }
        Ok(())
    }
}
