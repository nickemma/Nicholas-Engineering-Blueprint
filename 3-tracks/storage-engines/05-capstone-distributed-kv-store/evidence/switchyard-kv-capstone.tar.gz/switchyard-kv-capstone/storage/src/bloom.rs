// Six probes, generated from two stable 64-bit hashes of the byte key.
const PROBES: u64 = 6;
const MAX_BYTES: usize = 512 * 1024;

pub struct Bloom(Vec<u8>);

impl Bloom {
    pub fn new(entries: usize) -> Self {
        let bytes = entries.saturating_mul(10).div_ceil(8).clamp(8, MAX_BYTES);
        Self(vec![0; bytes])
    }

    pub fn decode(bytes: Vec<u8>) -> Option<Self> {
        (8..=MAX_BYTES)
            .contains(&bytes.len())
            .then_some(Self(bytes))
    }

    pub fn raw(&self) -> &[u8] {
        &self.0
    }

    pub fn insert(&mut self, key: &[u8]) {
        for bit in probes(key, self.0.len()) {
            self.0[bit / 8] |= 1 << (bit % 8);
        }
    }

    pub fn may_contain(&self, key: &[u8]) -> bool {
        probes(key, self.0.len()).all(|bit| self.0[bit / 8] & (1 << (bit % 8)) != 0)
    }
}

fn probes(key: &[u8], bytes: usize) -> impl Iterator<Item = usize> {
    let first = key.iter().fold(0xcbf29ce484222325_u64, |hash, byte| {
        (hash ^ u64::from(*byte)).wrapping_mul(0x100000001b3)
    });
    let mix = (first ^ (first >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
    let second = ((mix ^ (mix >> 27)).wrapping_mul(0x94d049bb133111eb) ^ (mix >> 31)) | 1;
    (0..PROBES)
        .map(move |i| (first.wrapping_add(i.wrapping_mul(second)) % (bytes * 8) as u64) as usize)
}
