use std::fs::File;
use std::io::{self, Write};
use std::os::unix::fs::FileExt;
use std::path::Path;

use klog::record::{HEADER_LEN, MAX_PAYLOAD, decode, encode_header};

use crate::codec::invalid;

pub fn sync_dir(dir: &Path) -> io::Result<()> {
    File::open(dir)?.sync_all()
}

pub fn write_frame(file: &mut File, data: &[u8]) -> io::Result<u64> {
    let header = encode_header(data).map_err(io::Error::other)?;
    file.write_all(&header)?;
    file.write_all(data)?;
    Ok((header.len() + data.len()) as u64)
}

pub fn read_frame(file: &File, at: u64, limit: u64) -> io::Result<(Vec<u8>, u64)> {
    let remaining = limit
        .checked_sub(at)
        .ok_or_else(|| invalid("invalid frame offset"))?;
    if remaining < HEADER_LEN as u64 {
        return Err(invalid("incomplete data frame"));
    }
    let mut header = [0; HEADER_LEN];
    file.read_exact_at(&mut header, at)?;
    let len = u32::from_le_bytes(header[..4].try_into().unwrap()) as usize;
    let size = HEADER_LEN + len;
    if len > MAX_PAYLOAD || size as u64 > remaining {
        return Err(invalid("invalid data frame length"));
    }
    let mut complete = header.to_vec();
    complete.resize(size, 0);
    file.read_exact_at(&mut complete[HEADER_LEN..], at + HEADER_LEN as u64)?;
    let (payload, used) = decode(&complete).map_err(io::Error::other)?;
    Ok((payload.to_vec(), at + used as u64))
}
