use std::io;

use crate::codec::{Cursor, MAX_KEY, MAX_VALUE, invalid, u32_to, u64_to};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Version {
    pub seq: u64,
    pub value: Option<Vec<u8>>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Entry {
    pub key: Vec<u8>,
    pub version: Version,
}

impl Entry {
    pub fn new(key: &[u8], seq: u64, value: Option<&[u8]>) -> io::Result<Self> {
        if key.len() > MAX_KEY || value.is_some_and(|value| value.len() > MAX_VALUE) {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "key or value exceeds size limit",
            ));
        }
        Ok(Self {
            key: key.to_vec(),
            version: Version {
                seq,
                value: value.map(<[u8]>::to_vec),
            },
        })
    }

    pub fn encode(&self, out: &mut Vec<u8>) {
        u64_to(out, self.version.seq);
        u32_to(out, self.key.len() as u32);
        u32_to(
            out,
            self.version
                .value
                .as_ref()
                .map_or(u32::MAX, |v| v.len() as u32),
        );
        out.extend(&self.key);
        if let Some(value) = &self.version.value {
            out.extend(value);
        }
    }

    pub fn decode(cursor: &mut Cursor<'_>) -> io::Result<Self> {
        let seq = cursor.u64()?;
        let key_len = cursor.u32()? as usize;
        let value_len = cursor.u32()?;
        if seq == 0
            || key_len > MAX_KEY
            || (value_len != u32::MAX && value_len as usize > MAX_VALUE)
        {
            return Err(invalid("invalid entry sequence or size"));
        }
        let key = cursor.take(key_len)?.to_vec();
        let value = if value_len == u32::MAX {
            None
        } else {
            Some(cursor.take(value_len as usize)?.to_vec())
        };
        Ok(Self {
            key,
            version: Version { seq, value },
        })
    }
}
