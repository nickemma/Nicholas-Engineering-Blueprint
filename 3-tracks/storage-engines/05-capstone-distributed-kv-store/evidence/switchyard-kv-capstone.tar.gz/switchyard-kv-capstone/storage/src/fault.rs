// The normal build never pauses storage calls.
#[cfg(not(feature = "fault-injection"))]
pub fn pause(_point: &str) {}

#[cfg(feature = "fault-injection")]
pub fn pause(point: &str) {
    use std::io::{self, Write};

    if std::env::var("LSM_PAUSE_AT").as_deref() == Ok(point) {
        println!("paused {point}");
        io::stdout().flush().expect("flush fault barrier");
        loop {
            std::thread::park();
        }
    }
}
