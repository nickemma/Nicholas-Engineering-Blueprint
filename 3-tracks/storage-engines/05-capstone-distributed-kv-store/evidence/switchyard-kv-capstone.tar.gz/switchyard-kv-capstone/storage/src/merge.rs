use std::cmp::Ordering;
use std::collections::BinaryHeap;
use std::io;

use crate::entry::Entry;

pub type Source<'a> = Box<dyn Iterator<Item = io::Result<Entry>> + 'a>;

struct Head {
    entry: Entry,
    source: usize,
}

impl Ord for Head {
    fn cmp(&self, other: &Self) -> Ordering {
        // Smallest key first. For a shared key, greatest sequence first.
        other
            .entry
            .key
            .cmp(&self.entry.key)
            .then(self.entry.version.seq.cmp(&other.entry.version.seq))
            .then(self.source.cmp(&other.source))
    }
}

impl PartialOrd for Head {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl PartialEq for Head {
    fn eq(&self, other: &Self) -> bool {
        self.cmp(other).is_eq()
    }
}

impl Eq for Head {}

pub struct Merge<'a> {
    sources: Vec<Source<'a>>,
    heads: BinaryHeap<Head>,
    error: Option<io::Error>,
}

impl<'a> Merge<'a> {
    pub fn new(sources: Vec<Source<'a>>) -> io::Result<Self> {
        let mut merge = Self {
            sources,
            heads: BinaryHeap::new(),
            error: None,
        };
        for source in 0..merge.sources.len() {
            merge.advance(source)?;
        }
        Ok(merge)
    }

    fn advance(&mut self, source: usize) -> io::Result<()> {
        if let Some(entry) = self.sources[source].next() {
            self.heads.push(Head {
                entry: entry?,
                source,
            });
        }
        Ok(())
    }
}

impl Iterator for Merge<'_> {
    type Item = io::Result<Entry>;

    fn next(&mut self) -> Option<Self::Item> {
        if let Some(error) = self.error.take() {
            self.heads.clear();
            return Some(Err(error));
        }
        let Head { entry, source } = self.heads.pop()?;
        self.error = self.advance(source).err();
        Some(Ok(entry))
    }
}
