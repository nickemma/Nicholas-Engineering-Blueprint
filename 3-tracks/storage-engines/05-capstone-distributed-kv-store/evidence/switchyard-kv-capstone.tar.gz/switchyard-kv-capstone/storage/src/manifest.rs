use std::fs::{self, File};
use std::io;
use std::path::{Path, PathBuf};

use crate::codec::{Cursor, invalid, u32_to, u64_to};
use crate::disk::{read_frame, sync_dir, write_frame};
use crate::fault;

pub fn wal_path(dir: &Path, id: u64) -> PathBuf {
    dir.join(format!("wal-{id:020}"))
}

pub fn table_path(dir: &Path, id: u64) -> PathBuf {
    dir.join(format!("run-{id:020}"))
}

#[derive(Clone, Default, Debug)]
pub struct Manifest {
    pub generation: u64,
    pub covered: u64,
    pub wal: u64,
    pub tables: Vec<u64>,
}

impl Manifest {
    pub fn load(dir: &Path) -> io::Result<Option<Self>> {
        let file = match File::open(dir.join("MANIFEST")) {
            Ok(file) => file,
            Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(None),
            Err(error) => return Err(error),
        };
        let end = file.metadata()?.len();
        let (data, next) = read_frame(&file, 0, end)?;
        let mut cursor = Cursor::new(&data);
        if next != end || cursor.take(4)? != b"LSM1" {
            return Err(invalid("invalid manifest format"));
        }
        let generation = cursor.u64()?;
        let covered = cursor.u64()?;
        let wal = cursor.u64()?;
        let count = cursor.u32()?;
        if count as usize > (data.len() - 32) / 8 {
            return Err(invalid("table count exceeds manifest length"));
        }
        let tables = (0..count)
            .map(|_| cursor.u64())
            .collect::<io::Result<Vec<_>>>()?;
        cursor.done()?;
        if wal > generation
            || tables.iter().any(|&id| id == 0 || id > generation)
            || tables.windows(2).any(|pair| pair[0] >= pair[1])
        {
            return Err(invalid("invalid manifest generation or table list"));
        }
        Ok(Some(Self {
            generation,
            covered,
            wal,
            tables,
        }))
    }

    pub fn publish(&self, dir: &Path) -> io::Result<()> {
        let mut data = b"LSM1".to_vec();
        for field in [self.generation, self.covered, self.wal] {
            u64_to(&mut data, field);
        }
        let count = u32::try_from(self.tables.len()).map_err(|_| invalid("too many tables"))?;
        u32_to(&mut data, count);
        for id in &self.tables {
            u64_to(&mut data, *id);
        }
        let pending = dir.join("MANIFEST.next");
        let mut file = File::create_new(&pending)?;
        write_frame(&mut file, &data)?;
        file.sync_all()?;
        fault::pause("before-manifest");
        fs::rename(pending, dir.join("MANIFEST"))?;
        sync_dir(dir)?;
        fault::pause("manifest-published");
        Ok(())
    }

    pub fn initialize(dir: &Path) -> io::Result<Self> {
        let initial = wal_path(dir, 0);
        for file in fs::read_dir(dir)? {
            let path = file?.path();
            let name = path
                .file_name()
                .and_then(|name| name.to_str())
                .unwrap_or("");
            if (path == initial && path.metadata()?.len() == 0) || name == "MANIFEST.next" {
                fs::remove_file(path)?;
            } else if name.starts_with("wal-") || name.starts_with("run-") {
                return Err(invalid(
                    "storage files exist without an authoritative manifest",
                ));
            }
        }
        create_wal(dir, 0)?;
        let manifest = Self::default();
        manifest.publish(dir)?;
        Ok(manifest)
    }

    pub fn cleanup(&self, dir: &Path) -> io::Result<()> {
        for file in fs::read_dir(dir)? {
            let file = file?;
            let name = file.file_name();
            let name = name.to_str().unwrap_or("");
            let obsolete = if let Some(id) = numeric_suffix(name, "wal-") {
                id != self.wal
            } else if let Some(id) = numeric_suffix(name, "run-") {
                self.tables.binary_search(&id).is_err()
            } else {
                name == "MANIFEST.next"
            };
            if obsolete {
                fs::remove_file(file.path())?;
            }
        }
        sync_dir(dir)
    }

    pub fn next(&self) -> io::Result<u64> {
        self.generation
            .checked_add(1)
            .ok_or_else(|| invalid("generation exhausted"))
    }
}

fn numeric_suffix(name: &str, prefix: &str) -> Option<u64> {
    let digits = name.strip_prefix(prefix)?;
    if digits.len() == 20 && digits.bytes().all(|byte| byte.is_ascii_digit()) {
        digits.parse().ok()
    } else {
        None
    }
}

pub fn create_wal(dir: &Path, id: u64) -> io::Result<PathBuf> {
    let path = wal_path(dir, id);
    File::create_new(&path)?.sync_all()?;
    sync_dir(dir)?;
    Ok(path)
}
