mod bloom;
mod codec;
mod compact;
mod disk;
mod encrypted;
mod entry;
mod fault;
mod manifest;
mod merge;
mod namespace;
mod snapshot;
mod table;

use std::collections::BTreeMap;
use std::fs::{self, File, OpenOptions};
use std::io;
use std::path::{Path, PathBuf};

use klog::log::Log;

use codec::{Cursor, invalid};
use disk::sync_dir;
use entry::{Entry, Version};
use manifest::{Manifest, create_wal, table_path, wal_path};
use merge::{Merge, Source};
use snapshot::Pins;
use table::Table;

pub use compact::Compaction;
pub use encrypted::{EncryptedNamespace, Keyring};
pub use namespace::{Namespace, Tenant, TenantSnapshot};
pub use snapshot::Snapshot;

#[derive(Debug, Default, Eq, PartialEq)]
pub struct ProbeStats {
    pub block_reads: u64,
    pub filter_negatives: u64,
    pub false_positives: u64,
}

pub type Row = (Vec<u8>, Vec<u8>);

#[derive(Debug, Eq, PartialEq)]
pub struct State {
    pub sequence: u64,
    pub covered: u64,
    pub generation: u64,
    pub wal: u64,
    pub runs: Vec<u64>,
}

pub struct Store {
    dir: PathBuf,
    seq: u64,
    mem: BTreeMap<Vec<u8>, Vec<Version>>,
    wal: Log,
    manifest: Manifest,
    tables: Vec<Table>,
    failed: bool,
    pins: Pins,
    _lock: File,
}

impl Store {
    pub fn open(dir: &Path) -> io::Result<Self> {
        fs::create_dir_all(dir)?;
        let lock = OpenOptions::new()
            .read(true)
            .write(true)
            .create(true)
            .truncate(false)
            .open(dir.join("LOCK"))?;
        lock.try_lock().map_err(io::Error::from)?;
        let manifest = match Manifest::load(dir)? {
            Some(manifest) => manifest,
            None => Manifest::initialize(dir)?,
        };
        let tables = manifest
            .tables
            .iter()
            .map(|id| Table::open(&table_path(dir, *id)))
            .collect::<io::Result<Vec<_>>>()?;
        let mut wal = Log::open_existing(&wal_path(dir, manifest.wal)).map_err(io::Error::other)?;
        let mut seq = manifest.covered;
        let mut mem: BTreeMap<Vec<u8>, Vec<Version>> = BTreeMap::new();
        wal.visit(|record| {
            let mut cursor = Cursor::new(record);
            if cursor.take(4)? != b"LSW1" {
                return Err(invalid("unexpected WAL version"));
            }
            let entry = Entry::decode(&mut cursor)?;
            cursor.done()?;
            if Some(entry.version.seq) != seq.checked_add(1) {
                return Err(invalid("nonconsecutive WAL sequence"));
            }
            seq = entry.version.seq;
            mem.entry(entry.key).or_default().push(entry.version);
            Ok(())
        })
        .map_err(io::Error::other)?;
        manifest.cleanup(dir)?;
        Ok(Self {
            dir: dir.to_path_buf(),
            _lock: lock,
            pins: Pins::default(),
            seq,
            mem,
            wal,
            manifest,
            tables,
            failed: false,
        })
    }

    pub fn sequence(&self) -> u64 {
        self.seq
    }

    pub fn state(&self) -> State {
        State {
            sequence: self.seq,
            covered: self.manifest.covered,
            generation: self.manifest.generation,
            wal: self.manifest.wal,
            runs: self.manifest.tables.clone(),
        }
    }

    pub fn recovered_bytes(&self) -> u64 {
        self.wal.recovered_bytes()
    }

    pub fn put(&mut self, key: &[u8], value: &[u8]) -> io::Result<u64> {
        self.change(key, Some(value))
    }

    pub fn delete(&mut self, key: &[u8]) -> io::Result<u64> {
        self.change(key, None)
    }

    fn ensure_live(&self) -> io::Result<()> {
        if self.failed {
            return Err(io::Error::other("storage I/O failed; reopen the engine"));
        }
        Ok(())
    }

    fn change(&mut self, key: &[u8], value: Option<&[u8]>) -> io::Result<u64> {
        self.ensure_live()?;
        let next = self
            .seq
            .checked_add(1)
            .ok_or_else(|| invalid("sequence exhausted"))?;
        let entry = Entry::new(key, next, value)?;
        let mut bytes = b"LSW1".to_vec();
        entry.encode(&mut bytes);
        self.failed = true;
        fault::pause("before-wal");
        self.wal.append(&bytes).map_err(io::Error::other)?;
        fault::pause("after-wal-sync");
        self.seq = next;
        self.mem.entry(entry.key).or_default().push(entry.version);
        self.failed = false;
        Ok(next)
    }

    pub fn flush(&mut self) -> io::Result<()> {
        self.ensure_live()?;
        if self.mem.is_empty() {
            return Ok(());
        }
        let id = self.manifest.next()?;
        let entries: Vec<_> = self
            .mem
            .iter()
            .flat_map(|(key, versions)| {
                versions.iter().rev().map(|version| Entry {
                    key: key.clone(),
                    version: version.clone(),
                })
            })
            .collect();
        self.failed = true;
        let table = Table::create(&table_path(&self.dir, id), &entries)?;
        let next_wal = create_wal(&self.dir, id)?;
        let wal = Log::open_existing(&next_wal).map_err(io::Error::other)?;
        sync_dir(&self.dir)?;
        fault::pause("outputs-synced");
        let mut next = self.manifest.clone();
        next.generation = id;
        next.covered = self.seq;
        next.wal = id;
        next.tables.push(id);
        next.publish(&self.dir)?;
        self.wal = wal;
        self.tables.push(table);
        self.mem.clear();
        self.manifest = next;
        self.manifest.cleanup(&self.dir)?;
        fault::pause("after-cleanup");
        self.failed = false;
        Ok(())
    }

    pub fn snapshot(&self) -> Snapshot {
        self.pins.pin(self.seq)
    }

    fn pinned(&self, snapshot: &Snapshot) -> io::Result<u64> {
        if !self.pins.owns(snapshot) {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "snapshot belongs to another open store",
            ));
        }
        Ok(snapshot.sequence())
    }

    pub fn get(&self, key: &[u8]) -> io::Result<Option<Vec<u8>>> {
        self.get_with_stats(key, true).map(|(value, _)| value)
    }

    pub fn get_at(&self, key: &[u8], snapshot: &Snapshot) -> io::Result<Option<Vec<u8>>> {
        self.get_visible(key, self.pinned(snapshot)?, true)
            .map(|(value, _)| value)
    }

    pub fn get_with_stats(
        &self,
        key: &[u8],
        use_filter: bool,
    ) -> io::Result<(Option<Vec<u8>>, ProbeStats)> {
        self.get_visible(key, self.seq, use_filter)
    }

    fn get_visible(
        &self,
        key: &[u8],
        at: u64,
        use_filter: bool,
    ) -> io::Result<(Option<Vec<u8>>, ProbeStats)> {
        self.ensure_live()?;
        let mut stats = ProbeStats::default();
        let mut best = self
            .mem
            .get(key)
            .and_then(|versions| visible(versions, at))
            .cloned();
        for table in &self.tables {
            for entry in table.point(key, use_filter, &mut stats)? {
                if entry.version.seq <= at
                    && best
                        .as_ref()
                        .is_none_or(|version| version.seq < entry.version.seq)
                {
                    best = Some(entry.version);
                }
            }
        }
        Ok((best.and_then(|version| version.value), stats))
    }

    pub fn scan(&self, start: &[u8], end: &[u8]) -> io::Result<Vec<Row>> {
        self.scan_visible(start, end, self.seq)
    }

    pub fn scan_at(&self, start: &[u8], end: &[u8], snapshot: &Snapshot) -> io::Result<Vec<Row>> {
        self.scan_visible(start, end, self.pinned(snapshot)?)
    }

    fn scan_visible(&self, start: &[u8], end: &[u8], at: u64) -> io::Result<Vec<Row>> {
        self.ensure_live()?;
        if start >= end {
            return Ok(Vec::new());
        }
        let mem = self
            .mem
            .range::<[u8], _>((
                std::ops::Bound::Included(start),
                std::ops::Bound::Excluded(end),
            ))
            .filter_map(|(key, versions)| {
                Some(Ok(Entry {
                    key: key.clone(),
                    version: visible(versions, at)?.clone(),
                }))
            });
        let mut sources: Vec<Source<'_>> = vec![Box::new(mem)];
        for table in &self.tables {
            sources.push(Box::new(table.range(start, end)));
        }
        let mut rows = Vec::new();
        let mut decided = None;
        for entry in Merge::new(sources)? {
            let entry = entry?;
            if entry.version.seq <= at && decided.as_ref() != Some(&entry.key) {
                // Even if this version is a tombstone, older entries must stay hidden.
                decided = Some(entry.key.clone());
                if let Some(value) = entry.version.value {
                    rows.push((entry.key, value));
                }
            }
        }
        Ok(rows)
    }
}

fn visible(versions: &[Version], at: u64) -> Option<&Version> {
    let past = versions.partition_point(|version| version.seq <= at);
    versions[..past].last()
}
