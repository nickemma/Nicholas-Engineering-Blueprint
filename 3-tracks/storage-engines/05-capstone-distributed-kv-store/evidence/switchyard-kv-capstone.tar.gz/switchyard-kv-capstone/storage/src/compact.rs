use std::io;

use crate::Store;
use crate::disk::sync_dir;
use crate::fault;
use crate::manifest::table_path;
use crate::merge::{Merge, Source};
use crate::table::Table;

#[derive(Debug, Default, Eq, PartialEq)]
pub struct Compaction {
    pub input_runs: usize,
    pub input_versions: u64,
    pub input_bytes: u64,
    pub retained_versions: usize,
    pub output_bytes: u64,
}

impl Store {
    pub fn compact(&mut self) -> io::Result<Compaction> {
        self.ensure_live()?;
        if self.tables.is_empty() {
            return Ok(Compaction::default());
        }
        let horizon = self.pins.oldest().unwrap_or(self.seq);
        let id = self.manifest.next()?;
        let mut stats = Compaction {
            input_runs: self.tables.len(),
            ..Compaction::default()
        };
        let mut sources: Vec<Source<'_>> = Vec::new();
        for table in &self.tables {
            stats.input_bytes += table.bytes()?;
            sources.push(Box::new(table.all()));
        }

        let mut retained = Vec::new();
        let mut anchored = None;
        for entry in Merge::new(sources)? {
            let entry = entry?;
            stats.input_versions += 1;
            if entry.version.seq > horizon {
                retained.push(entry);
            } else if anchored.as_ref() != Some(&entry.key) {
                // Every published run is an input, and the active WAL is
                // newer. A tombstone at or below the horizon can go with
                // the older versions it hides.
                anchored = Some(entry.key.clone());
                if entry.version.value.is_some() {
                    retained.push(entry);
                }
            }
        }
        stats.retained_versions = retained.len();

        self.failed = true;
        let mut next = self.manifest.clone();
        next.generation = id;
        next.tables.clear();
        let mut tables = Vec::new();
        if !retained.is_empty() {
            let table = Table::create(&table_path(&self.dir, id), &retained)?;
            stats.output_bytes = table.bytes()?;
            tables.push(table);
            next.tables.push(id);
        }
        sync_dir(&self.dir)?;
        fault::pause("outputs-synced");
        next.publish(&self.dir)?;
        self.tables = tables;
        self.manifest = next;
        self.manifest.cleanup(&self.dir)?;
        fault::pause("after-cleanup");
        self.failed = false;
        Ok(stats)
    }
}
