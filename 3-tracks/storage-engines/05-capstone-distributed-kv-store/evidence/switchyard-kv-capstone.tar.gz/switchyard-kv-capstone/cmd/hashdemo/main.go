package main

import (
	"fmt"

	"switchyard/metad/internal/ring"
)

func main() {
	before, after := []string{"A", "B", "C"}, []string{"A", "B", "C", "D"}
	old, next := ring.New(before, 128), ring.New(after, 128)
	single := ring.New(after, 1)
	onePoint, manyPoints := map[string]int{}, map[string]int{}
	modMoved, ringMoved := 0, 0
	for i := range 10_000 {
		key := fmt.Sprintf("job/%d", i)
		oldMod, _ := ring.Modulo(before, key)
		newMod, _ := ring.Modulo(after, key)
		if oldMod != newMod {
			modMoved++
		}
		previous, _ := old.Owner(key)
		current, _ := next.Owner(key)
		if previous != current {
			ringMoved++
		}
		one, _ := single.Owner(key)
		onePoint[one]++
		manyPoints[current]++
	}
	fmt.Printf("add D: modulo moves %d/10000; ring moves %d/10000\n", modMoved, ringMoved)
	for _, node := range after {
		fmt.Printf("node %s holds %d keys with 1 point; %d with 128 points\n", node, onePoint[node], manyPoints[node])
	}
	hot := "job/42"
	requests := map[string]int{}
	for node, count := range manyPoints {
		requests[node] = count // One request per distinct key.
	}
	for range 6_000 {
		owner, _ := next.Owner(hot)
		requests[owner]++
	}
	owner, _ := next.Owner(hot)
	fmt.Printf("node %s owns hot key %s and gets %d/16000 requests\n", owner, hot, requests[owner])
}
