package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"slices"
	"strings"
	"syscall"
	"time"

	"switchyard/metad/internal/metad"
	"switchyard/metad/internal/wal"
)

func run() error {
	id := flag.Int("id", 0, "peer ID from 1 to 3")
	listen := flag.String("listen", "", "local Unix socket path")
	routes := flag.String("peers", "", "comma-separated Unix socket paths in ID order")
	path := flag.String("wal", "", "path to this peer's klog")
	writer := flag.String("writer", "", "path to the metad-wal executable")
	clientAddr := flag.String("client", "", "loopback TCP address for the KV API")
	engine := flag.String("engine", "", "Rust projection executable")
	directory := flag.String("projection-root", "", "private projection directory")
	keys := flag.String("keyring", "", "external encryption keys")
	active := flag.String("active-key", "1", "active encryption key ID")
	tokens := flag.String("tenant-tokens", "", "local fixture credentials file")
	readPath := flag.String("read-path", "point", "point or range")
	rangeLab := flag.Bool("range-lab", false, "enable the local range-movement exercise")
	flag.Parse()

	peers := strings.Split(*routes, ",")
	if len(peers) != 3 || slices.Contains(peers, "") || *id < 1 || *id > len(peers) ||
		*listen == "" || *path == "" || *writer == "" {
		return errors.New("supply -id, -listen, -peers (three paths), -wal, and -writer")
	}
	if peers[0] == peers[1] || peers[0] == peers[2] || peers[1] == peers[2] {
		return errors.New("peer routes must be distinct")
	}
	disk, stable, recovered, err := wal.Open(*writer, *path, len(peers))
	if err != nil {
		return err
	}
	defer disk.Close()
	log.Printf("recovered peer=%d bytes=%d", *id, recovered)
	listener, err := net.Listen("unix", *listen)
	if err != nil {
		return err
	}
	defer listener.Close()

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	node := metad.New(*id, len(peers), time.Now().UnixNano(), stable, disk)
	if *clientAddr != "" {
		host, _, err := net.SplitHostPort(*clientAddr)
		if err != nil || !net.ParseIP(host).IsLoopback() || *engine == "" ||
			*directory == "" || *keys == "" || *tokens == "" || *rangeLab {
			return errors.New("KV mode requires localhost, a projection, credentials, and keys")
		}
		project, err := metad.OpenProjection(*engine, *directory, *keys, *active, *readPath)
		if err != nil {
			return err
		}
		defer project.Close()
		if err := node.EnableKV(project, *tokens); err != nil {
			return err
		}
		clientListener, err := net.Listen("tcp", *clientAddr)
		if err != nil {
			return err
		}
		defer clientListener.Close()
		client := &http.Server{
			Handler: node.ClientHandler(), ReadTimeout: time.Second, WriteTimeout: 2 * time.Second,
		}
		defer client.Close()
		go func() { client.Serve(clientListener); stop() }()
		log.Printf("kv client=%s", clientListener.Addr())
	} else if *rangeLab {
		node.EnableRangeLab()
	}
	server := &http.Server{
		Handler: node.Handler(), ReadTimeout: time.Second, WriteTimeout: 2 * time.Second,
		IdleTimeout: 3 * time.Second,
	}
	defer server.Close()
	serve := make(chan error, 1)
	go func() {
		serve <- server.Serve(listener)
		stop()
	}()
	log.Printf("listening peer=%d", *id)
	if err := node.Run(ctx, peers); err != nil {
		return err
	}
	select {
	case err := <-serve:
		if !errors.Is(err, http.ErrServerClosed) {
			return fmt.Errorf("serve: %w", err)
		}
	default:
	}
	return nil
}

func main() {
	log.SetFlags(0)
	if err := run(); err != nil {
		log.Fatal(err)
	}
}
