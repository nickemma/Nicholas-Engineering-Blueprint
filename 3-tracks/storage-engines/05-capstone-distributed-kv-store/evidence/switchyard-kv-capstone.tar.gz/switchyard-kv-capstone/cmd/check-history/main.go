package main

import (
	"encoding/json"
	"fmt"
	"os"
	"time"

	"github.com/anishathalye/porcupine"
)

type input struct {
	Op, Key, Value, Expect string
}

type value struct {
	Found bool
	Value string
}

type result struct {
	value
	Swapped bool
}

type observation struct {
	Input  input
	Call   int64
	Return *int64
	Result *result
	Client int
}

func register() porcupine.Model {
	spec := porcupine.NondeterministicModel{
		Init: func() []any { return []any{value{}} },
		Step: func(state, argument, output any) []any {
			before := state.(value)
			request := argument.(input)
			after := before
			expected := result{value: before}
			switch request.Op {
			case "get":
			case "delete":
				after = value{}
				expected.value = after
			case "put":
				after = value{Found: true, Value: request.Value}
				expected.value = after
			case "cas":
				if before.Found && before.Value == request.Expect {
					after = value{Found: true, Value: request.Value}
					expected = result{value: after, Swapped: true}
				}
			}
			if output.(*result) == nil {
				return []any{before, after}
			}
			if *output.(*result) == expected {
				return []any{after}
			}
			return nil
		},
	}
	return spec.ToModel()
}

func operations(rows []observation) ([]porcupine.Operation, error) {
	if len(rows) == 0 {
		return nil, fmt.Errorf("empty history")
	}
	var end int64
	for _, row := range rows {
		if row.Input.Key == "" || row.Input.Key != rows[0].Input.Key {
			return nil, fmt.Errorf("use one populated key per history")
		}
		switch row.Input.Op {
		case "get", "put", "cas", "delete":
		default:
			return nil, fmt.Errorf("unknown operation %q", row.Input.Op)
		}
		end = max(end, row.Call)
		if (row.Return == nil) != (row.Result == nil) || row.Call < 0 {
			return nil, fmt.Errorf("invalid observation for client %d", row.Client)
		}
		if row.Return != nil {
			if *row.Return < row.Call {
				return nil, fmt.Errorf("return precedes call")
			}
			end = max(end, *row.Return)
		}
	}
	if end == 1<<63-1 {
		return nil, fmt.Errorf("history timestamp overflow")
	}
	history := make([]porcupine.Operation, 0, len(rows))
	for _, row := range rows {
		finish := end + 1 // A missing result may take effect at any later point.
		if row.Return != nil {
			finish = *row.Return
		}
		history = append(history, porcupine.Operation{
			ClientId: row.Client, Input: row.Input, Call: row.Call,
			Output: row.Result, Return: finish,
		})
	}
	return history, nil
}

func run(path string) (int, error) {
	body, err := os.ReadFile(path)
	if err != nil {
		return 2, err
	}
	var rows []observation
	if err := json.Unmarshal(body, &rows); err != nil {
		return 2, err
	}
	history, err := operations(rows)
	if err != nil {
		return 2, err
	}
	switch porcupine.CheckOperationsTimeout(register(), history, 5*time.Second) {
	case porcupine.Ok:
		fmt.Printf("linearizable (%d observations)\n", len(history))
		return 0, nil
	case porcupine.Illegal:
		return 1, fmt.Errorf("no legal order for %d observations", len(history))
	default:
		return 2, fmt.Errorf("checker inconclusive")
	}
}

func main() {
	if len(os.Args) != 2 {
		fmt.Fprintln(os.Stderr, "usage: check-history HISTORY.json")
		os.Exit(2)
	}
	status, err := run(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
	}
	os.Exit(status)
}
