"""Start a disposable cluster until interrupted."""

import argparse
from contextlib import suppress
import json
from pathlib import Path
import tempfile
import time

from capstone import KVCluster


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("metad", type=lambda arg: Path(arg).resolve())
    parser.add_argument("writer", type=lambda arg: Path(arg).resolve())
    parser.add_argument("engine", type=lambda arg: Path(arg).resolve())
    parser.add_argument("mode", choices=("point", "range"))
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="kv-demo-", dir="/tmp") as directory:
        with KVCluster(Path(directory), args.metad, args.writer, args.engine, args.mode) as cluster:
            print(json.dumps({
                "peers": ["http://" + cluster.address(peer) for peer in cluster.ids],
                "leader": cluster.leader()["ID"],
                "token_file": str(cluster.token_path),
            }), flush=True)
            with suppress(KeyboardInterrupt):
                while True:
                    time.sleep(1)


if __name__ == "__main__":
    main()
