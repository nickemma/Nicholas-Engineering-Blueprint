"""Run the official YCSB client through the public loopback endpoint."""

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

from capstone import KVCluster, ok


def run_java(classpath, properties, phase, size, requests, threads):
    command = ["java", "-cp", classpath, "site.ycsb.Client", f"-{phase}", "-db", "SwitchyardDB",
               "-P", str(properties), "-threads", str(threads), "-p", f"recordcount={size}",
               "-p", f"operationcount={requests}", "-p", "maxexecutiontime=60"]
    done = subprocess.run(command, capture_output=True, text=True, timeout=80)
    if done.returncode:
        raise AssertionError(done.stdout + done.stderr)
    return done.stdout


def metrics(raw):
    found = {}
    for line in raw.splitlines():
        if line.startswith("["):
            name, field, number = line.split(", ", 2)
            found.setdefault(name.strip("[]"), {})[field] = float(number)
    return found


def count_success(data, operations, expected):
    completed = 0
    for name in operations:
        bucket = data.get(name, {})
        count = int(bucket.get("Operations", 0))
        success = int(bucket.get("Return=OK", 0))
        assert success == count, (name, bucket)
        rejected = {label: n for label, n in bucket.items() if label.startswith("Return=") and label != "Return=OK" and n}
        assert not rejected, rejected
        completed += count
    assert completed == expected, (completed, expected, operations)


def trial(paths, read_path, letter, output, number, size, requests, threads):
    peer, writer, engine, classpath = paths
    with tempfile.TemporaryDirectory(prefix="sy-ycsb-", dir="/tmp") as temporary:
        root = Path(temporary)
        with KVCluster(root, peer, writer, engine, read_path) as cluster:
            leader = cluster.leader()["ID"]
            ok(cluster, leader, "put", "fixture", "same", 1)
            assert ok(cluster, leader, "get", "fixture") == {"found": True, "value": "same"}
            assert ok(cluster, leader, "get", "fixture", tenant="b") == {"found": False}
            endpoints = ",".join("http://" + cluster.address(p) for p in cluster.ids)
            profile = (Path(__file__).resolve().parent.parent / "bench" / f"workload{letter}.properties").read_text()
            properties = root / "fixture.properties"
            # Secrets stay in a mode-0600 temporary property file and out of evidence.
            fd = os.open(properties, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            with os.fdopen(fd, "w") as stream:
                stream.write(profile + f"switchyard.endpoints={endpoints}\nswitchyard.token={cluster.tokens['a']}\n")
            loaded = run_java(classpath, properties, "load", size, requests, 1)
            count_success(metrics(loaded), ["INSERT"], size)
            measured = run_java(classpath, properties, "t", size, requests, threads)
            stats = metrics(measured)
            operations = ["READ", "UPDATE"] if letter == "a" else ["READ"]
            count_success(stats, operations, requests)
            observed = {operation: stats[operation]["Operations"] for operation in operations if operation in stats}
            assert all(value > 0 for value in observed.values()) and len(observed) == len(operations), observed
            prefix = f"{number}-{read_path}-{letter}"
            # The YCSB command banner is on stderr and includes the temporary properties path.
            (output / f"{prefix}-load.txt").write_text(loaded)
            (output / f"{prefix}.txt").write_text(measured)
            result = {
                "trial": number, "path": read_path, "workload": letter, "records": size,
                "requests": requests, "threads": threads, "errors": 0, "counts": observed,
                "throughput": stats["OVERALL"]["Throughput(ops/sec)"],
                "read_p95_us": stats["READ"]["95thPercentileLatency(us)"],
                "read_p99_us": stats["READ"]["99thPercentileLatency(us)"],
            }
            print(json.dumps(result), flush=True)
            return result


def main():
    peer, writer, engine, classpath, folder, mode = sys.argv[1:]
    output = Path(folder).resolve()
    output.mkdir(parents=True, exist_ok=True)
    paths = (Path(peer).resolve(), Path(writer).resolve(), Path(engine).resolve(), classpath)
    size, requests, threads, trials = (32, 32, 2, 1) if mode == "smoke" else (64, 400, 2, 2)
    rows = []
    for repetition in range(1, trials + 1):
        for letter in ("a", "c"):
            modes = ("range", "point") if repetition % 2 else ("point", "range")
            for path in modes:
                rows.append(trial(paths, path, letter, output, repetition, size, requests, threads))
    (output / "matrix.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
