#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.."
mode=${1:-point}
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
cargo build --quiet --locked --release --manifest-path klog/Cargo.toml --bin metad-wal
cargo build --quiet --locked --release --manifest-path storage/Cargo.toml --bin kv-project
target_dir() {
    cargo metadata --locked --no-deps --format-version 1 --manifest-path "$1" |
        python3 -c 'import json, sys; print(json.load(sys.stdin)["target_directory"])'
}
go build -buildvcs=false -o "$work/peer" ./cmd/metad
python3 -B lab/serve.py "$work/peer" "$(target_dir klog/Cargo.toml)/release/metad-wal" \
    "$(target_dir storage/Cargo.toml)/release/kv-project" "$mode"
