//! CRC-32C (Castagnoli), the checksum used by many storage systems to
//! detect damaged bytes. A checksum can't repair damage or stop someone
//! who rewrites both the data and its checksum; it only detects accidents.

/// The Castagnoli polynomial, bit-reversed, as the table algorithm needs.
const POLYNOMIAL: u32 = 0x82F6_3B78;

/// A table of 256 precomputed values, built once at compile time, so the
/// checksum processes a whole byte per step instead of one bit.
const TABLE: [u32; 256] = build_table();

const fn build_table() -> [u32; 256] {
    let mut table = [0u32; 256];
    let mut i = 0;
    while i < 256 {
        let mut crc = i as u32;
        let mut bit = 0;
        while bit < 8 {
            crc = if crc & 1 == 1 {
                (crc >> 1) ^ POLYNOMIAL
            } else {
                crc >> 1
            };
            bit += 1;
        }
        table[i] = crc;
        i += 1;
    }
    table
}

/// Returns the CRC-32C of data.
pub fn crc32c(data: &[u8]) -> u32 {
    let mut crc = !0u32;
    for &byte in data {
        crc = TABLE[((crc ^ byte as u32) & 0xFF) as usize] ^ (crc >> 8);
    }
    !crc
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn known_check_value() {
        // Every CRC-32C implementation must give this for "123456789".
        assert_eq!(crc32c(b"123456789"), 0xE306_9283);
    }

    #[test]
    fn empty_input() {
        assert_eq!(crc32c(b""), 0);
    }

    #[test]
    fn one_changed_bit_changes_the_checksum() {
        let mut data = b"job 7 completed".to_vec();
        let before = crc32c(&data);
        data[4] ^= 0b0000_0001;
        assert_ne!(crc32c(&data), before);
    }
}
