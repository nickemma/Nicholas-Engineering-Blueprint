pub fn first_word(text: &str) -> Option<&str> {
    text.split_whitespace().next()
}

pub fn add_separator(line: &mut String) {
    line.push_str(" | ");
}

pub fn into_bytes(line: String) -> Vec<u8> {
    line.into_bytes()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_borrow_points_into_the_original_text() {
        let input = String::from("resize cover");
        let word = first_word(&input).unwrap();
        assert_eq!(word, "resize");
        assert_eq!(word.as_ptr(), input.as_ptr());
    }

    #[test]
    fn mutation_then_transfer() {
        let mut input = String::from("job");
        add_separator(&mut input);
        let bytes = into_bytes(input);
        assert_eq!(bytes, b"job | ");
    }
}
