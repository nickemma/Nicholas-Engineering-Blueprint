use std::collections::BTreeMap;

pub trait Measurement {
    fn millis(&self) -> u64;
}

pub struct Sample {
    pub elapsed_ms: u64,
}

impl Measurement for Sample {
    fn millis(&self) -> u64 {
        self.elapsed_ms
    }
}

impl Measurement for u64 {
    fn millis(&self) -> u64 {
        *self
    }
}

pub fn slow<T: Measurement>(samples: &[T], cutoff: u64) -> Vec<u64> {
    samples
        .iter()
        .map(Measurement::millis)
        .filter(|&ms| ms > cutoff)
        .collect()
}

pub fn buckets<T: Measurement>(samples: &[T]) -> BTreeMap<u64, usize> {
    let mut counts = BTreeMap::new();
    for sample in samples {
        let bucket = sample.millis() / 10 * 10;
        *counts.entry(bucket).or_insert(0) += 1;
    }
    counts
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn two_types_can_use_the_same_summary() {
        let samples = [Sample { elapsed_ms: 12 }, Sample { elapsed_ms: 29 }];
        assert_eq!(slow(&samples, 20), slow(&[12, 29], 20));
    }

    #[test]
    fn bucket_order_is_stable() {
        let counts = buckets(&[24, 10, 21, 12, 9]);
        assert_eq!(
            counts.into_iter().collect::<Vec<_>>(),
            [(0, 1), (10, 2), (20, 2)]
        );
    }
}
