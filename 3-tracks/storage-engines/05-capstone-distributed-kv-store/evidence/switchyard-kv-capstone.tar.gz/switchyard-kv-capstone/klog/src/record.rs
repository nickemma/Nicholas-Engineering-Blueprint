use std::fmt;

use crate::crc::crc32c;

pub const HEADER_LEN: usize = 12;
pub const MAX_PAYLOAD: usize = 1024 * 1024;

#[derive(Debug, PartialEq, Eq)]
pub enum RecordError {
    Incomplete,
    TooLarge(usize),
    HeaderChecksum,
    PayloadChecksum,
}

impl fmt::Display for RecordError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Incomplete => write!(f, "incomplete frame"),
            Self::TooLarge(n) => write!(f, "payload length {n} exceeds {MAX_PAYLOAD}"),
            Self::HeaderChecksum => write!(f, "header checksum mismatch"),
            Self::PayloadChecksum => write!(f, "payload checksum mismatch"),
        }
    }
}

impl std::error::Error for RecordError {}

// The header is written separately from its payload so the writer
// can accept a borrowed payload without assembling a second copy.
pub fn encode_header(payload: &[u8]) -> Result<[u8; HEADER_LEN], RecordError> {
    if payload.len() > MAX_PAYLOAD {
        return Err(RecordError::TooLarge(payload.len()));
    }
    let mut bytes = [0; HEADER_LEN];
    bytes[..4].copy_from_slice(&(payload.len() as u32).to_le_bytes());
    bytes[4..8].copy_from_slice(&crc32c(payload).to_le_bytes());
    let guard = crc32c(&bytes[..8]);
    bytes[8..].copy_from_slice(&guard.to_le_bytes());
    Ok(bytes)
}

pub(crate) struct Header {
    pub len: usize,
    checksum: u32,
}

pub(crate) fn parse_header(bytes: &[u8; HEADER_LEN]) -> Result<Header, RecordError> {
    let guard = u32::from_le_bytes(bytes[8..].try_into().unwrap());
    if crc32c(&bytes[..8]) != guard {
        return Err(RecordError::HeaderChecksum);
    }
    let len = u32::from_le_bytes(bytes[..4].try_into().unwrap()) as usize;
    if len > MAX_PAYLOAD {
        return Err(RecordError::TooLarge(len));
    }
    let checksum = u32::from_le_bytes(bytes[4..8].try_into().unwrap());
    Ok(Header { len, checksum })
}

pub(crate) fn verify(header: &Header, payload: &[u8]) -> Result<(), RecordError> {
    if crc32c(payload) != header.checksum {
        return Err(RecordError::PayloadChecksum);
    }
    Ok(())
}

pub fn decode(input: &[u8]) -> Result<(&[u8], usize), RecordError> {
    let bytes = input.get(..HEADER_LEN).ok_or(RecordError::Incomplete)?;
    let header = parse_header(bytes.try_into().unwrap())?;
    let end = HEADER_LEN + header.len;
    let payload = input.get(HEADER_LEN..end).ok_or(RecordError::Incomplete)?;
    verify(&header, payload)?;
    Ok((payload, end))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn frame(payload: &[u8]) -> Vec<u8> {
        let mut out = encode_header(payload).unwrap().to_vec();
        out.extend_from_slice(payload);
        out
    }

    #[test]
    fn a_view_borrows_only_one_payload() {
        let mut bytes = frame(b"hello");
        bytes.extend_from_slice(&frame(b"world"));
        let (payload, next) = decode(&bytes).unwrap();
        assert_eq!(payload, b"hello");
        assert_eq!(payload.as_ptr(), bytes[HEADER_LEN..].as_ptr());
        assert_eq!(decode(&bytes[next..]).unwrap().0, b"world");
    }

    #[test]
    fn every_incomplete_cut_is_detected() {
        let bytes = frame(b"hello");
        for cut in 0..bytes.len() {
            assert_eq!(decode(&bytes[..cut]), Err(RecordError::Incomplete));
        }
    }

    #[test]
    fn damage_in_header_and_payload_is_detected() {
        let mut bytes = frame(b"hello");
        bytes[0] ^= 1;
        assert_eq!(decode(&bytes), Err(RecordError::HeaderChecksum));
        bytes[0] ^= 1;
        bytes[HEADER_LEN] ^= 1;
        assert_eq!(decode(&bytes), Err(RecordError::PayloadChecksum));
    }

    #[test]
    fn payload_cap_and_empty_records() {
        assert_eq!(decode(&frame(b"")).unwrap().0, b"");
        let oversized = vec![0; MAX_PAYLOAD + 1];
        assert_eq!(
            encode_header(&oversized),
            Err(RecordError::TooLarge(oversized.len()))
        );

        let mut header = [0; HEADER_LEN];
        header[..4].copy_from_slice(&((MAX_PAYLOAD + 1) as u32).to_le_bytes());
        let guard = crc32c(&header[..8]);
        header[8..].copy_from_slice(&guard.to_le_bytes());
        assert_eq!(decode(&header), Err(RecordError::TooLarge(oversized.len())));
    }
}
