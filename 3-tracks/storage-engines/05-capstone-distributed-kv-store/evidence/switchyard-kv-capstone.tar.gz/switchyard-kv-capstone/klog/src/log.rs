use std::fmt;
use std::fs::{File, OpenOptions};
use std::io::{self, Read, Seek, SeekFrom, Write};
use std::path::{Path, PathBuf};

use crate::record::{self, HEADER_LEN, RecordError};

#[derive(Debug)]
pub enum LogError {
    Io(io::Error),
    BadInput(RecordError),
    Corrupt { offset: u64, cause: RecordError },
    Torn { offset: u64, bytes: u64 },
    WriterFailed,
}

impl fmt::Display for LogError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Io(err) => write!(f, "{err}"),
            Self::BadInput(err) => write!(f, "{err}"),
            Self::Corrupt { offset, cause } => {
                write!(f, "corrupt record at byte {offset}: {cause}")
            }
            Self::Torn { offset, bytes } => {
                write!(f, "incomplete record at byte {offset} ({bytes} bytes)")
            }
            Self::WriterFailed => write!(f, "writer had an I/O failure; reopen the log"),
        }
    }
}

impl std::error::Error for LogError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::Io(err) => Some(err),
            Self::BadInput(err) => Some(err),
            Self::Corrupt { cause, .. } => Some(cause),
            Self::Torn { .. } | Self::WriterFailed => None,
        }
    }
}

impl From<io::Error> for LogError {
    fn from(err: io::Error) -> Self {
        Self::Io(err)
    }
}

// EOF can arrive partway through a frame. Read::read is also allowed to
// return a short count when more data is available.
fn read_until_full(reader: &mut File, buf: &mut [u8]) -> io::Result<usize> {
    let mut used = 0;
    while used < buf.len() {
        match reader.read(&mut buf[used..]) {
            Ok(0) => break,
            Ok(n) => used += n,
            Err(err) if err.kind() == io::ErrorKind::Interrupted => continue,
            Err(err) => return Err(err),
        }
    }
    Ok(used)
}

#[derive(Default)]
struct Scan {
    offset: u64,
    records: u64,
    torn_bytes: u64,
}

fn scan(file: &mut File, mut visit: impl FnMut(&[u8]) -> io::Result<()>) -> Result<Scan, LogError> {
    let mut progress = Scan::default();
    let mut bytes = [0; HEADER_LEN];
    let mut payload = Vec::new();
    loop {
        let n = read_until_full(file, &mut bytes)?;
        if n == 0 {
            return Ok(progress);
        }
        if n < HEADER_LEN {
            progress.torn_bytes = n as u64;
            return Ok(progress);
        }

        let at = |cause| LogError::Corrupt {
            offset: progress.offset,
            cause,
        };
        let header = record::parse_header(&bytes).map_err(at)?;
        payload.resize(header.len, 0);
        let n = read_until_full(file, &mut payload)?;
        if n < header.len {
            progress.torn_bytes = (HEADER_LEN + n) as u64;
            return Ok(progress);
        }
        record::verify(&header, &payload).map_err(at)?;
        visit(&payload)?;
        progress.offset += (HEADER_LEN + header.len) as u64;
        progress.records += 1;
    }
}

pub struct Log {
    file: File,
    parent: PathBuf,
    parent_synced: bool,
    end: u64,
    records: u64,
    recovered_bytes: u64,
    failed: bool,
}

impl Log {
    pub fn open(path: &Path) -> Result<Self, LogError> {
        Self::open_with(path, true)
    }

    pub fn open_existing(path: &Path) -> Result<Self, LogError> {
        Self::open_with(path, false)
    }

    fn open_with(path: &Path, create: bool) -> Result<Self, LogError> {
        let mut file = OpenOptions::new()
            .read(true)
            .append(true)
            .create(create)
            .open(path)?;
        file.try_lock().map_err(io::Error::from)?;
        let progress = scan(&mut file, |_| Ok(()))?;
        if progress.torn_bytes != 0 {
            file.set_len(progress.offset)?;
            file.sync_all()?;
        }
        let parent = path
            .parent()
            .filter(|parent| !parent.as_os_str().is_empty())
            .unwrap_or(Path::new("."));
        Ok(Self {
            file,
            parent: parent.to_path_buf(),
            parent_synced: false,
            end: progress.offset,
            records: progress.records,
            recovered_bytes: progress.torn_bytes,
            failed: false,
        })
    }

    pub fn records(&self) -> u64 {
        self.records
    }

    pub fn recovered_bytes(&self) -> u64 {
        self.recovered_bytes
    }

    /// Visit the verified records while keeping the exclusive writer lock.
    pub fn visit(&mut self, visit: impl FnMut(&[u8]) -> io::Result<()>) -> Result<(), LogError> {
        self.file.seek(SeekFrom::Start(0))?;
        let progress = scan(&mut self.file, visit)?;
        if progress.torn_bytes != 0 {
            return Err(LogError::Torn {
                offset: progress.offset,
                bytes: progress.torn_bytes,
            });
        }
        Ok(())
    }

    pub fn append(&mut self, payload: &[u8]) -> Result<u64, LogError> {
        self.append_inner(payload, || Ok(()))
    }

    #[cfg(feature = "fault-injection")]
    pub fn append_with_barrier(
        &mut self,
        payload: &[u8],
        after_header: impl FnOnce() -> io::Result<()>,
    ) -> Result<u64, LogError> {
        self.append_inner(payload, after_header)
    }

    fn append_inner(
        &mut self,
        payload: &[u8],
        after_header: impl FnOnce() -> io::Result<()>,
    ) -> Result<u64, LogError> {
        if self.failed {
            return Err(LogError::WriterFailed);
        }
        let header = record::encode_header(payload).map_err(LogError::BadInput)?;
        let start = self.end;
        // Once writing starts, an I/O failure leaves the tail uncertain.
        // Refuse further writes through this handle until it is reopened.
        self.failed = true;
        self.file.write_all(&header)?;
        after_header()?;
        self.file.write_all(payload)?;
        self.file.sync_all()?;
        if !self.parent_synced {
            File::open(&self.parent)?.sync_all()?;
            self.parent_synced = true;
        }
        self.end += (header.len() + payload.len()) as u64;
        self.records += 1;
        self.failed = false;
        Ok(start)
    }
}

pub fn visit_records(
    path: &Path,
    visit: impl FnMut(&[u8]) -> io::Result<()>,
) -> Result<(), LogError> {
    let mut file = File::open(path)?;
    file.try_lock_shared().map_err(io::Error::from)?;
    let progress = scan(&mut file, visit)?;
    if progress.torn_bytes != 0 {
        return Err(LogError::Torn {
            offset: progress.offset,
            bytes: progress.torn_bytes,
        });
    }
    Ok(())
}
