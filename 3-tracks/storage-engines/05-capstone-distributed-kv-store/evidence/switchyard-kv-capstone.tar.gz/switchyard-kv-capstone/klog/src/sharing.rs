use std::rc::Rc;

pub fn longer<'a>(first: &'a str, second: &'a str) -> &'a str {
    if first.len() >= second.len() {
        first
    } else {
        second
    }
}

pub fn shared_labels(label: String) -> (Rc<str>, Rc<str>) {
    let first: Rc<str> = Rc::from(label);
    let second = Rc::clone(&first);
    (first, second)
}

pub enum List {
    Empty,
    Node(u32, Box<List>),
}

impl List {
    pub fn prepend(self, value: u32) -> Self {
        Self::Node(value, Box::new(self))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn view_borrows_an_input() {
        let a = String::from("resize");
        let b = String::from("job");
        assert_eq!(longer(&a, &b), "resize");
    }

    #[test]
    fn cloning_rc_shares_one_allocation() {
        let (a, b) = shared_labels(String::from("thumbnail"));
        assert!(Rc::ptr_eq(&a, &b));
        assert_eq!(Rc::strong_count(&a), 2);
        drop(a);
        assert_eq!(b.as_ref(), "thumbnail");
        assert_eq!(Rc::strong_count(&b), 1);
    }

    #[test]
    fn a_box_makes_the_recursive_variant_fixed_size() {
        let list = List::Empty.prepend(3).prepend(7);
        let List::Node(head, tail) = list else {
            panic!("expected a node");
        };
        assert_eq!(head, 7);
        assert!(matches!(*tail, List::Node(3, _)));
    }
}
