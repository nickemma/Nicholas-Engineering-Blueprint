use std::fmt;
use std::time::Duration;

/// Everything that can be wrong with a duration's text.
#[derive(Debug, PartialEq, Eq)]
pub enum ParseError {
    Empty,
    MissingUnit(String),
    UnknownUnit(String),
    BadNumber(String),
}

impl fmt::Display for ParseError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ParseError::Empty => write!(f, "duration is empty"),
            ParseError::MissingUnit(text) => {
                write!(f, "duration {text:?} has no unit (use ms, s or m)")
            }
            ParseError::UnknownUnit(unit) => write!(f, "unknown unit {unit:?} (use ms, s or m)"),
            ParseError::BadNumber(number) => write!(f, "{number:?} is not a whole number in range"),
        }
    }
}

impl std::error::Error for ParseError {}

/// Parses a whole number followed by a unit: ms, s or m.
pub fn parse(text: &str) -> Result<Duration, ParseError> {
    let text = text.trim();
    if text.is_empty() {
        return Err(ParseError::Empty);
    }
    let split = text
        .find(|c: char| !c.is_ascii_digit())
        .ok_or_else(|| ParseError::MissingUnit(text.to_string()))?;
    let (number, unit) = text.split_at(split);
    let n: u64 = number
        .parse()
        .map_err(|_| ParseError::BadNumber(number.to_string()))?;
    match unit {
        "ms" => Ok(Duration::from_millis(n)),
        "s" => Ok(Duration::from_secs(n)),
        "m" => n
            .checked_mul(60)
            .map(Duration::from_secs)
            .ok_or_else(|| ParseError::BadNumber(number.to_string())),
        other => Err(ParseError::UnknownUnit(other.to_string())),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn valid_durations() {
        assert_eq!(parse("250ms"), Ok(Duration::from_millis(250)));
        assert_eq!(parse(" 2s "), Ok(Duration::from_secs(2)));
        assert_eq!(parse("3m"), Ok(Duration::from_secs(180)));
    }

    #[test]
    fn invalid_durations() {
        assert_eq!(parse(""), Err(ParseError::Empty));
        assert_eq!(parse("250"), Err(ParseError::MissingUnit("250".into())));
        assert_eq!(parse("2h"), Err(ParseError::UnknownUnit("h".into())));
        assert_eq!(parse("ms"), Err(ParseError::BadNumber("".into())));
        assert_eq!(parse("-5s"), Err(ParseError::BadNumber("".into())));
    }

    #[test]
    fn overflow_is_an_error_not_a_wrong_answer() {
        let huge = format!("{}m", u64::MAX);
        assert!(matches!(parse(&huge), Err(ParseError::BadNumber(_))));
    }

    #[test]
    fn errors_explain_themselves() {
        assert_eq!(
            parse("2h").unwrap_err().to_string(),
            "unknown unit \"h\" (use ms, s or m)"
        );
    }
}
