use std::error::Error;
use std::ffi::{OsStr, OsString};
use std::io::{self, Write};
use std::path::Path;
use std::process::ExitCode;

use klog::log::{Log, visit_records};

fn main() -> ExitCode {
    let args: Vec<OsString> = std::env::args_os().skip(1).collect();
    match run(&args) {
        Ok(()) => ExitCode::SUCCESS,
        Err(err) => {
            eprintln!("klog: {err}");
            ExitCode::FAILURE
        }
    }
}

fn run(args: &[OsString]) -> Result<(), Box<dyn Error>> {
    match args {
        [command, path, text] if command == OsStr::new("append") => {
            let payload = text.to_str().ok_or("append requires UTF-8 text")?;
            let mut log = Log::open(Path::new(path))?;
            report_recovery(&log);
            let offset = log.append(payload.as_bytes())?;
            println!("appended at byte {offset}");
        }
        [command, path] if command == OsStr::new("cat") => {
            let mut line = 0;
            let mut out = io::stdout().lock();
            visit_records(Path::new(path), |payload| {
                writeln!(out, "{line}: {}", String::from_utf8_lossy(payload))?;
                line += 1;
                Ok(())
            })?;
        }
        [command, path] if command == OsStr::new("check") => {
            let log = Log::open_existing(Path::new(path))?;
            report_recovery(&log);
            println!("{} records, all checksums valid", log.records());
        }
        _ => return Err("usage: klog append FILE TEXT | klog cat FILE | klog check FILE".into()),
    }
    Ok(())
}

fn report_recovery(log: &Log) {
    if log.recovered_bytes() != 0 {
        println!("recovered: removed {} torn bytes", log.recovered_bytes());
    }
}
