# Switchyard distributed key-value capstone

A local three-peer Go Raft service with Rust-backed tenant values. Build on Linux with Go 1.26.6+, Rust 1.89+, Python 3.11+, JDK 21, and curl. The first build fetches pinned dependencies. Peers use Unix sockets. The client API binds to loopback.

Run the complete recovery, benchmark, and profile gate.

~~~bash
export KV_EVIDENCE_DIR="$PWD/results"
bash gate/run.sh "$PWD"
~~~

Set `YCSB_CACHE_DIR` to a Java dependency cache if you have one. The gate verifies each jar with a pinned digest. Pass `recovery`, `benchmark`, or `profile` after the learner workspace to select one check. The benchmark records YCSB A and C for both read paths. The isolated profile uses the Rust lookup function on a fixed replay. [Design decisions](ADR.md)

For a disposable interactive cluster, run `bash lab/launch.sh point`. It prints the peer URLs, initial leader ID, and the path to a JSON file containing the per-tenant tokens. In a second terminal, set `PEER` to the leader's URL and `TOKEN_FILE` to the printed token path. The keys and cluster files are removed when the launcher stops.

~~~bash
token=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["a"])' "$TOKEN_FILE")
curl -fsS -H "Authorization: Bearer $token" -H 'Content-Type: application/json' \
  -d '{"op":"put","key":"job","value":"queued","client":"demo","sequence":1}' "$PEER/kv"
curl -fsS -H "Authorization: Bearer $token" -H 'Content-Type: application/json' \
  -d '{"op":"get","key":"job"}' "$PEER/kv"
~~~

Run `recovery` mode for the tested restart and partition schedules. The peer binary's flags expose its data paths for a persistent learner deployment.
