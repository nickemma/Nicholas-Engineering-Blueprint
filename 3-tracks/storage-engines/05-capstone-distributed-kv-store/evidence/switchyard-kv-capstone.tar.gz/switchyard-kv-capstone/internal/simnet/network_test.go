package simnet

import (
	"reflect"
	"testing"
)

func TestOneWayLink(t *testing.T) {
	n := New[string](7)
	n.Send(1, 2, "already in flight")
	n.Block(1, 2, true)
	n.Send(1, 2, "dropped")
	n.Send(2, 1, "still delivered")
	got := n.Advance()
	if len(got) != 1 || got[0].Value != "still delivered" {
		t.Fatalf("deliveries: %+v", got)
	}
}

func TestSeedReplays(t *testing.T) {
	run := func() []Delivery[int] {
		n := New[int](42)
		n.Loss, n.Delay = 20, 4
		for i := range 30 {
			n.Send(1, 2, i)
		}
		var result []Delivery[int]
		for range 4 {
			result = append(result, n.Advance()...)
		}
		return result
	}
	first := run()
	if len(first) == 0 || len(first) == 30 || !reflect.DeepEqual(first, run()) {
		t.Fatalf("unexpected replay: %+v", first)
	}
}

func TestSilenceLooksTheSame(t *testing.T) {
	type observation struct {
		arrivals, suspected []int
	}
	trace := func(crashed bool) observation {
		n := New[bool](7)
		var seen observation
		last := 0
		for tick := 1; tick <= 9; tick++ {
			// A paused sender wakes on tick 7. A crashed sender stays gone.
			if tick <= 2 || (!crashed && tick >= 7) {
				n.Send(1, 2, true)
			}
			if len(n.Advance()) != 0 {
				last = n.Now
				seen.arrivals = append(seen.arrivals, n.Now)
			}
			if n.Now-last >= 3 {
				seen.suspected = append(seen.suspected, n.Now)
			}
		}
		return seen
	}
	pause, crash := trace(false), trace(true)
	if !reflect.DeepEqual(pause.arrivals, []int{1, 2, 7, 8, 9}) ||
		!reflect.DeepEqual(crash.arrivals, []int{1, 2}) ||
		!reflect.DeepEqual(pause.suspected, []int{5, 6}) ||
		!reflect.DeepEqual(crash.suspected, []int{5, 6, 7, 8, 9}) {
		t.Fatal("unexpected heartbeat traces", pause, crash)
	}
	t.Logf("arrivals when paused: %v; when crashed: %v", pause.arrivals, crash.arrivals)
	t.Logf("suspected when paused: %v; when crashed: %v", pause.suspected, crash.suspected)
}
