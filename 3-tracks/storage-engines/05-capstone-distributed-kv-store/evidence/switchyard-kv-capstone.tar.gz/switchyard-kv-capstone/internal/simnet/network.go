// Package simnet delivers messages on a seeded, discrete clock.
package simnet

import (
	"math/rand"
	"slices"
)

type Link struct{ From, To int }

type Delivery[T any] struct {
	Link
	Value T
	at    int
}

type Network[T any] struct {
	Now     int
	Delay   int // maximum delay in ticks
	Loss    int // chance of loss, in percent
	rng     *rand.Rand
	blocked map[Link]bool
	pending []Delivery[T]
}

func New[T any](seed int64) *Network[T] {
	return &Network[T]{
		Delay:   1,
		rng:     rand.New(rand.NewSource(seed)),
		blocked: make(map[Link]bool),
	}
}

// Block changes a single directed link. Its in-flight messages are lost.
func (n *Network[T]) Block(from, to int, blocked bool) {
	link := Link{from, to}
	n.blocked[link] = blocked
	if blocked {
		n.pending = slices.DeleteFunc(n.pending, func(m Delivery[T]) bool {
			return m.Link == link
		})
	}
}

func (n *Network[T]) Send(from, to int, value T) {
	link := Link{from, to}
	if n.blocked[link] || n.rng.Intn(100) < n.Loss {
		return
	}
	n.pending = append(n.pending, Delivery[T]{
		Link: link, Value: value, at: n.Now + 1 + n.rng.Intn(n.Delay),
	})
}

// Advance visits simultaneous deliveries in send order.
func (n *Network[T]) Advance() []Delivery[T] {
	n.Now++
	var ready []Delivery[T]
	queued := n.pending[:0]
	for _, m := range n.pending {
		if m.at <= n.Now {
			ready = append(ready, m)
		} else {
			queued = append(queued, m)
		}
	}
	clear(n.pending[len(queued):])
	n.pending = queued
	return ready
}
