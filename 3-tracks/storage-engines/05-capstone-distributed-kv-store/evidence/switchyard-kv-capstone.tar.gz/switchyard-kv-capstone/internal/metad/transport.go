package metad

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net"
	"net/http"
	"sync"
	"time"

	"switchyard/metad/internal/raft"
)

// Each destination has its own bounded queue and sender. Raft retries
// lost messages through subsequent heartbeats and election rounds.
type transport struct {
	queues []chan raft.Message
	stop   context.CancelFunc
	group  sync.WaitGroup
}

func newTransport(ctx context.Context, id int, routes []string) *transport {
	ctx, cancel := context.WithCancel(ctx)
	t := &transport{queues: make([]chan raft.Message, len(routes)+1), stop: cancel}
	for offset, path := range routes {
		peer := offset + 1
		if peer == id {
			continue
		}
		queue := make(chan raft.Message, 16)
		t.queues[peer] = queue
		t.group.Go(func() { sendLoop(ctx, path, queue) })
	}
	return t
}

func (t *transport) send(message raft.Message) {
	select {
	case t.queues[message.To] <- message:
	default:
	}
}

func (t *transport) close() {
	t.stop()
	t.group.Wait()
}

func sendLoop(ctx context.Context, path string, queue <-chan raft.Message) {
	wire := &http.Transport{
		DialContext: func(ctx context.Context, _, _ string) (net.Conn, error) {
			return (&net.Dialer{}).DialContext(ctx, "unix", path)
		},
		MaxIdleConnsPerHost: 1,
	}
	defer wire.CloseIdleConnections()
	client := &http.Client{Transport: wire, Timeout: 200 * time.Millisecond}
	for ctx.Err() == nil {
		select {
		case <-ctx.Done():
			return
		case message := <-queue:
			payload, err := json.Marshal(message)
			if err != nil {
				continue
			}
			req, err := http.NewRequestWithContext(ctx, http.MethodPost, "http://peer/raft", bytes.NewReader(payload))
			if err != nil {
				continue
			}
			req.Header.Set("Content-Type", "application/json")
			response, err := client.Do(req)
			if err == nil {
				io.Copy(io.Discard, io.LimitReader(response.Body, 4096))
				response.Body.Close()
			}
		}
	}
}
