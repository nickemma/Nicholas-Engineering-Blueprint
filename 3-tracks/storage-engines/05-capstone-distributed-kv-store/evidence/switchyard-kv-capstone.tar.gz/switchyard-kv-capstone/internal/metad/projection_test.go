package metad

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestProjectionReadPathsAgree(t *testing.T) {
	engine := os.Getenv("KV_ENGINE")
	if engine == "" {
		t.Skip("build kv-project and set KV_ENGINE")
	}
	dir := t.TempDir()
	keyring := filepath.Join(dir, "keys")
	if err := os.WriteFile(keyring, []byte("1:"+strings.Repeat("34", 32)+"\n"), 0600); err != nil {
		t.Fatal(err)
	}
	key := encodeTenantKey("a", "job")
	neighbor := encodeTenantKey("a", "job\x00")
	for _, mode := range []string{"range", "point"} {
		t.Run(mode, func(t *testing.T) {
			p, err := OpenProjection(engine, dir, keyring, "1", mode)
			if err != nil {
				t.Fatal(err)
			}
			defer p.Close()
			for key, value := range map[string]string{key: "", neighbor: "next"} {
				cipher, err := p.seal(key, value)
				if err != nil {
					t.Fatal(err)
				}
				if err := p.ack("put", key, cipher); err != nil {
					t.Fatal(err)
				}
			}
			if got, err := p.get(key); err != nil || !got.Found || got.Value != "" {
				t.Fatalf("exact lookup returned %+v: %v", got, err)
			}
			if err := p.ack("delete", key); err != nil {
				t.Fatal(err)
			}
			if got, err := p.get(key); err != nil || got.Found {
				t.Fatalf("neighbor appeared in exact lookup: %+v: %v", got, err)
			}
			if err := p.ack("reset"); err != nil {
				t.Fatal(err)
			}
			if got, err := p.get(neighbor); err != nil || got.Found {
				t.Fatalf("old generation was still visible: %+v: %v", got, err)
			}
		})
	}
	t.Log("both modes distinguished a present empty value, its next key, and a fresh projection")
}
