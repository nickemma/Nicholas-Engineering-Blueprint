package metad

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"switchyard/metad/internal/raft"
)

func leaseEntry(index int, op, owner string, at, ttl int64, token int) raft.Applied {
	return raft.Applied{Index: index, Entry: raft.Entry{Command: raft.Command{
		Op: op, Key: "job", Owner: owner, At: at, TTL: ttl, Token: token,
	}}}
}

func TestPausedWorkerIsFenced(t *testing.T) {
	entries := []raft.Applied{
		leaseEntry(2, "acquire", "worker A", 100, 20, 0),
		leaseEntry(4, "acquire", "worker B", 120, 20, 0),
	}
	state := newState()
	resource := NewResource()
	a := state.apply(entries[0])
	if !a.Granted || !resource.Write("job", a.Token, "A started") {
		t.Fatal("worker A could not start")
	}
	resume := make(chan struct{})
	done := make(chan bool, 1)
	go func() {
		<-resume
		done <- resource.Write("job", a.Token, "late A")
	}()

	b := state.apply(entries[1])
	bAccepted := resource.Write("job", b.Token, "B finished")
	close(resume)
	aAccepted := <-done
	if !b.Granted || b.Token <= a.Token || !bAccepted || aAccepted || resource.Value("job") != "B finished" {
		t.Fatalf("A=%+v B=%+v A-late=%t B-accepted=%t", a, b, aAccepted, bAccepted)
	}
	restarted := newState()
	for _, entry := range entries {
		restarted.apply(entry)
	}
	c := restarted.apply(leaseEntry(6, "acquire", "worker C", 140, 20, 0))
	if !c.Granted || c.Token <= b.Token {
		t.Fatal("replay allowed a token to go backward", c)
	}
	t.Logf("grants %d, %d, %d; resource refused resumed worker A after B wrote", a.Token, b.Token, c.Token)
}

func TestRenewAndClockSkew(t *testing.T) {
	state := newState()
	a := state.apply(leaseEntry(2, "acquire", "A", 100, 20, 0))
	renew := state.apply(leaseEntry(3, "renew", "A", 110, 20, a.Token))
	if !renew.Granted || renew.Token != a.Token || renew.Expires != 130 {
		t.Fatal("wrong renewal", renew)
	}
	backward := state.apply(leaseEntry(4, "renew", "A", 20, 30, a.Token))
	if backward.Expires != 140 {
		t.Fatal("backward clock moved the replicated time", backward)
	}
	wrong := state.apply(leaseEntry(5, "renew", "B", 130, 20, a.Token))
	late := state.apply(leaseEntry(6, "renew", "A", 140, 20, a.Token))
	if wrong.Granted || late.Granted {
		t.Fatal("accepted an invalid renewal")
	}
	t.Log("renewal kept the same token; wrong owner and deadline-equal renewal were refused")
}

func TestClientCannotSupplyLeaseTime(t *testing.T) {
	r := New(1, 3, 7, raft.Stable{}, nil)
	w := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/command", strings.NewReader(
		`{"Op":"acquire","Key":"job","Owner":"A","TTL":10,"At":123}`,
	))
	r.Handler().ServeHTTP(w, req)
	if w.Code != http.StatusBadRequest {
		t.Fatalf("client could set the leader's clock: %d", w.Code)
	}
}
