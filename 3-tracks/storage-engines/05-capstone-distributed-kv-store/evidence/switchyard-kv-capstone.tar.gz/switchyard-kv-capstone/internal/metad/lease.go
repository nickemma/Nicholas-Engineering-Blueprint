package metad

import (
	"math"
	"sync"

	"switchyard/metad/internal/raft"
)

type lease struct {
	owner   string
	token   int
	expires int64
}

const maxTTL = 60_000

func leaseOperation(op string) bool { return op == "acquire" || op == "renew" }

func validCommand(c raft.Command) bool {
	if c.Key == "" || len(c.Key) > 128 || len(c.Value) > 512 || c.At != 0 {
		return false
	}
	if len(c.Client) > 128 || len(c.Expect) > 512 || (c.Client == "") != (c.Sequence == 0) {
		return false
	}
	if c.Op == "cas" {
		return c.Client != "" && c.Owner == "" && c.Token == 0 && c.TTL == 0
	}
	if c.Expect != "" || (c.Client != "" && c.Op != "put") {
		return false
	}
	if leaseOperation(c.Op) {
		return c.Value == "" && c.Owner != "" && len(c.Owner) <= 128 &&
			c.TTL > 0 && c.TTL <= maxTTL &&
			((c.Op == "acquire" && c.Token == 0) || (c.Op == "renew" && c.Token > 0))
	}
	return (c.Op == "get" || c.Op == "put") && c.Owner == "" && c.Token == 0 && c.TTL == 0
}

func (s *state) applyLease(entry raft.Applied) Result {
	c := entry.Command
	s.now = max(s.now, c.At) // A later leader's clock can be behind.
	old := s.leases[c.Key]
	active := old.token != 0 && s.now < old.expires
	if c.TTL <= 0 || c.TTL > maxTTL || s.now > math.MaxInt64-c.TTL {
		return Result{}
	}
	if c.Op == "renew" {
		if !active || c.Owner != old.owner || c.Token != old.token {
			return Result{}
		}
	} else {
		if active {
			return Result{}
		}
		old = lease{owner: c.Owner, token: entry.Index}
	}
	expires := s.now + c.TTL
	old.expires = max(old.expires, expires)
	s.leases[c.Key] = old
	return Result{Granted: true, Token: old.token, Expires: old.expires}
}

// Resource demonstrates the check and effect under one lock. An external
// durable resource would store the highest token alongside the value.
type Resource struct {
	mu    sync.Mutex
	items map[string]fencedValue
}

type fencedValue struct {
	token int
	value string
}

func NewResource() *Resource { return &Resource{items: make(map[string]fencedValue)} }

func (r *Resource) Write(key string, token int, value string) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if token <= 0 || token < r.items[key].token {
		return false
	}
	r.items[key] = fencedValue{token: token, value: value}
	return true
}

func (r *Resource) Value(key string) string {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.items[key].value
}
