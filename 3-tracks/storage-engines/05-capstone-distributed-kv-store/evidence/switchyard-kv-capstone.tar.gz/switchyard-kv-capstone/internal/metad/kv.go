package metad

import "switchyard/metad/internal/raft"

type receipt struct {
	Command raft.Command
	Result  Result
}

func (s *state) mutate(command raft.Command) Result {
	// Epoch belongs to routing, so a retry after a move keeps its identity.
	command.Epoch = 0
	clients := s.retries[command.Key]
	if previous, exists := clients[command.Client]; exists {
		switch {
		case command == previous.Command:
			return previous.Result
		case command.Sequence <= previous.Command.Sequence:
			return Result{Error: "sequence already used"}
		}
	}

	old, found := s.values[command.Key]
	result := Result{Found: found, Value: old}
	if command.Op == "put" || (found && old == command.Expect) {
		s.values[command.Key] = command.Value
		result = Result{Found: true, Value: command.Value, Swapped: command.Op == "cas"}
	}

	if command.Client != "" {
		if clients == nil {
			clients = make(map[string]receipt)
			s.retries[command.Key] = clients
		}
		clients[command.Client] = receipt{Command: command, Result: result}
	}
	return result
}
