package metad

import "switchyard/metad/internal/raft"

type Result struct {
	Swapped bool   `json:"swapped,omitempty"`
	Error   string `json:"error,omitempty"`
	Found   bool   `json:"found"`
	Value   string `json:"value,omitempty"`
	Granted bool   `json:"granted,omitempty"`
	Token   int    `json:"token,omitempty"`
	Expires int64  `json:"expires,omitempty"`
}

type state struct {
	kvValues   map[string]string
	kvReceipts map[string]map[string]kvReceipt
	values     map[string]string
	retries    map[string]map[string]receipt
	leases     map[string]lease
	now        int64
	span       rangeState
}

func newState() *state {
	return &state{kvValues: make(map[string]string), kvReceipts: make(map[string]map[string]kvReceipt), values: make(map[string]string), leases: make(map[string]lease), retries: make(map[string]map[string]receipt)}
}

func (s *state) apply(entry raft.Applied) Result {
	command := entry.Command
	if movement(command.Op) {
		return s.move(command)
	}
	if command.Op != "" && inRange(command.Key) && s.span.Phase != "" {
		if s.span.Phase != "active" || command.Epoch != s.span.Epoch ||
			(leaseOperation(command.Op)) {
			return Result{Error: "range unavailable at this epoch"}
		}
	}
	switch command.Op {
	case "put", "cas":
		return s.mutate(command)
	case "get":
		value, found := s.values[command.Key]
		return Result{Found: found, Value: value}
	case "acquire", "renew":
		return s.applyLease(entry)
	default:
		return Result{} // The election no-op changes no metadata.
	}
}
