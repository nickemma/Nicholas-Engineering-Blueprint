package metad

import (
	"encoding/base64"
	"encoding/json"
	"errors"
)

const compactEvery = 8

type leaseRecord struct {
	Owner   string
	Token   int
	Expires int64
}

type snapshotState struct {
	KVValues   map[string]string               `json:",omitempty"`
	KVReceipts map[string]map[string]kvReceipt `json:",omitempty"`
	Version    int
	Values     map[string]string
	Retries    map[string]map[string]receipt
	Leases     map[string]leaseRecord
	Now        int64
	Range      rangeState
}

func (s *state) encode() (string, error) {
	snapshot := snapshotState{
		KVValues: s.kvValues, KVReceipts: s.kvReceipts,
		Version: 1, Values: s.values, Retries: s.retries, Now: s.now, Range: s.span,
		Leases: make(map[string]leaseRecord, len(s.leases)),
	}
	for key, l := range s.leases {
		snapshot.Leases[key] = leaseRecord{Owner: l.owner, Token: l.token, Expires: l.expires}
	}
	data, err := json.Marshal(snapshot)
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(data), nil
}

func decodeState(encoded string) (*state, error) {
	data, err := base64.StdEncoding.DecodeString(encoded)
	if err != nil {
		return nil, err
	}
	var snapshot snapshotState
	if err := json.Unmarshal(data, &snapshot); err != nil {
		return nil, err
	}
	if snapshot.Version != 1 || snapshot.Values == nil || snapshot.Retries == nil || snapshot.Leases == nil {
		return nil, errors.New("invalid snapshot version or missing state")
	}
	s := newState()
	if snapshot.KVValues != nil {
		s.kvValues = snapshot.KVValues
	}
	if snapshot.KVReceipts != nil {
		s.kvReceipts = snapshot.KVReceipts
	}
	s.values, s.retries, s.now, s.span = snapshot.Values, snapshot.Retries, snapshot.Now, snapshot.Range
	for key, l := range snapshot.Leases {
		s.leases[key] = lease{owner: l.Owner, token: l.Token, expires: l.Expires}
	}
	return s, nil
}
