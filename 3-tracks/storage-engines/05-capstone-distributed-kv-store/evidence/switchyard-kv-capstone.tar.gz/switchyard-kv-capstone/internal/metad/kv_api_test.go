package metad

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestCapstoneProposalSealsBeforeRaft(t *testing.T) {
	api := &kvAPI{seal: func(key, value string) (string, error) {
		if key != "0001616a6f62" || value != "private" {
			t.Fatalf("sealer received %q and %q", key, value)
		}
		return "fixture-ciphertext", nil
	}}
	command, status := api.proposal("a", ClientCommand{
		Op: "put", Key: "job", Value: "private", Client: "client", Sequence: 1,
	})
	if status != http.StatusOK || command.Value != "fixture-ciphertext" || command.Sequence != 1 {
		t.Fatalf("unexpected proposal %+v, %d", command, status)
	}
	if encodeTenantKey("a", "bc") == encodeTenantKey("ab", "c") {
		t.Fatal("tenant encoding collided")
	}
	runtime := &Runtime{kv: api}
	response := httptest.NewRecorder()
	runtime.ClientHandler().ServeHTTP(response, httptest.NewRequest("POST", "/kv", nil))
	if response.Code != http.StatusUnauthorized {
		t.Fatalf("unauthenticated request got %d", response.Code)
	}
	t.Log("authenticated put carries ciphertext and a tenant-scoped key")
}
