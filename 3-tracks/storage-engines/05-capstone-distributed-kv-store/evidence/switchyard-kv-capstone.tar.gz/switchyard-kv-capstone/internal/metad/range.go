package metad

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"

	"switchyard/metad/internal/raft"
)

const maxImage = 12 << 10

type rangeState struct {
	Phase  string
	Epoch  uint64
	Digest [32]byte
}

type rangeImage struct {
	Values  map[string]string
	Retries map[string]map[string]receipt
}

func inRange(key string) bool { return key >= "m" && key < "n" }

func movement(op string) bool {
	switch op {
	case "range_init", "range_freeze", "range_import", "range_activate":
		return true
	default:
		return false
	}
}

func validMove(c raft.Command) bool {
	switch c.Op {
	case "range_init":
		return c == (raft.Command{Op: c.Op, Epoch: 1, Value: "source"}) ||
			c == (raft.Command{Op: c.Op, Epoch: 1, Value: "destination"})
	case "range_import":
		return c == (raft.Command{Op: c.Op, Epoch: 2, Value: c.Value}) &&
			len(c.Value) > 0 && len(c.Value) <= maxImage
	default:
		return c == (raft.Command{Op: c.Op, Epoch: 2})
	}
}

func (s *state) move(c raft.Command) Result {
	switch c.Op {
	case "range_init":
		if s.span.Phase == "" {
			phase := "empty"
			if c.Value == "source" {
				for key := range s.leases {
					if inRange(key) {
						return Result{Error: "range contains a lease"}
					}
				}
				phase = "active"
			} else {
				for key := range s.values {
					if inRange(key) {
						return Result{Error: "destination range is populated"}
					}
				}
				for key := range s.retries {
					if inRange(key) {
						return Result{Error: "destination range has retry receipts"}
					}
				}
			}
			s.span = rangeState{Phase: phase, Epoch: c.Epoch}
			return Result{Found: true}
		}
	case "range_freeze":
		if s.span.Phase == "active" && s.span.Epoch == c.Epoch-1 {
			image := s.exportRange()
			if image.Error == "" {
				s.span = rangeState{Phase: "frozen", Epoch: c.Epoch}
			}
			return image
		}
		if s.span.Phase == "frozen" && s.span.Epoch == c.Epoch {
			return s.exportRange()
		}
	case "range_import":
		digest := sha256.Sum256([]byte(c.Value))
		if s.span.Phase == "empty" && s.span.Epoch == c.Epoch-1 {
			if s.importRange(c.Value) {
				s.span = rangeState{Phase: "loaded", Epoch: c.Epoch, Digest: digest}
				return Result{Found: true}
			}
		}
		if (s.span.Phase == "loaded" || s.span.Phase == "active") &&
			s.span.Epoch == c.Epoch && s.span.Digest == digest {
			return Result{Found: true}
		}
	case "range_activate":
		if s.span.Epoch == c.Epoch && (s.span.Phase == "loaded" || s.span.Phase == "active") {
			s.span.Phase = "active"
			return Result{Found: true}
		}
	}
	return Result{Error: "range transition refused"}
}

func (s *state) exportRange() Result {
	image := rangeImage{
		Values: make(map[string]string), Retries: make(map[string]map[string]receipt),
	}
	for key, value := range s.values {
		if inRange(key) {
			image.Values[key] = value
		}
	}
	for key, clients := range s.retries {
		if inRange(key) {
			image.Retries[key] = clients
		}
	}
	body, err := json.Marshal(image)
	if err != nil || base64.StdEncoding.EncodedLen(len(body)) > maxImage {
		return Result{Error: "range image exceeds lab limit"}
	}
	return Result{Found: true, Value: base64.StdEncoding.EncodeToString(body)}
}

func (s *state) importRange(encoded string) bool {
	body, err := base64.StdEncoding.DecodeString(encoded)
	if err != nil {
		return false
	}
	var image rangeImage
	if json.Unmarshal(body, &image) != nil || image.Values == nil || image.Retries == nil {
		return false
	}
	for key := range image.Values {
		if !inRange(key) {
			return false
		}
	}
	for key, clients := range image.Retries {
		if !inRange(key) {
			return false
		}
		for client, retry := range clients {
			c := retry.Command
			if client == "" || c.Client != client || c.Key != key || c.Sequence == 0 ||
				(c.Op != "put" && c.Op != "cas") || !validCommand(c) || c.Epoch != 0 {
				return false
			}
		}
	}
	for key, value := range image.Values {
		s.values[key] = value
	}
	for key, clients := range image.Retries {
		s.retries[key] = clients
	}
	return true
}
