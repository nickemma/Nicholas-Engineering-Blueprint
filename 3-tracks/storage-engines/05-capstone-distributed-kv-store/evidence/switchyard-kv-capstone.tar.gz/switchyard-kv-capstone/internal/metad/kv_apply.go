package metad

import (
	"errors"
	"maps"
	"slices"

	"switchyard/metad/internal/raft"
)

type kvReceipt struct {
	Sequence uint64
	Op       string
}

func (r *Runtime) EnableKV(projection *Projection, tokensPath string) error {
	if projection == nil {
		return errors.New("projection is required")
	}
	tokens, err := loadClientTokens(tokensPath)
	if err != nil {
		return err
	}
	r.kv, r.project = &kvAPI{tenants: tokens, seal: projection.seal}, projection
	return nil
}

func (r *Runtime) rebuild(s *state) error {
	if r.project == nil {
		if len(s.kvValues) != 0 || len(s.kvReceipts) != 0 {
			return errors.New("snapshot requires a Rust projection")
		}
		return nil
	}
	if err := r.project.ack("reset"); err != nil {
		return err
	}
	for _, key := range slices.Sorted(maps.Keys(s.kvValues)) {
		if err := r.project.ack("put", key, s.kvValues[key]); err != nil {
			return err
		}
	}
	return nil
}

func (r *Runtime) apply(s *state, entry raft.Applied) (Result, error) {
	command := entry.Command
	switch command.Op {
	case "kv_get", "kv_put", "kv_delete":
		if r.project == nil {
			return Result{}, errors.New("entry requires a Rust projection")
		}
	default:
		return s.apply(entry), nil
	}
	if command.Op == "kv_get" {
		return r.project.get(command.Key)
	}
	receipts := s.kvReceipts[command.Key]
	old := receipts[command.Client]
	if old.Sequence == command.Sequence && old.Op == command.Op {
		return Result{Found: true}, nil
	}
	if old.Sequence >= command.Sequence {
		return Result{Error: "stale or reused operation sequence"}, nil
	}

	if command.Op == "kv_put" {
		if err := r.project.ack("put", command.Key, command.Value); err != nil {
			return Result{}, err
		}
		s.kvValues[command.Key] = command.Value
	} else {
		if err := r.project.ack("delete", command.Key); err != nil {
			return Result{}, err
		}
		delete(s.kvValues, command.Key)
	}
	if receipts == nil {
		receipts = make(map[string]kvReceipt)
		s.kvReceipts[command.Key] = receipts
	}
	receipts[command.Client] = kvReceipt{Sequence: command.Sequence, Op: command.Op}
	return Result{Found: true}, nil
}
