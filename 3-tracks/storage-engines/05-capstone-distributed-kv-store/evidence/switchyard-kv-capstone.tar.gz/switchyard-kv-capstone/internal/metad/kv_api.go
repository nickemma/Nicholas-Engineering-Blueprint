package metad

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"os"
	"regexp"
	"strings"

	"switchyard/metad/internal/raft"
)

var identifier = regexp.MustCompile(`^[A-Za-z0-9_.-]{1,64}$`)

type kvAPI struct {
	tenants map[[32]byte]string
	seal    func(string, string) (string, error)
}

type ClientCommand struct {
	Op       string `json:"op"`
	Key      string `json:"key"`
	Value    string `json:"value,omitempty"`
	Client   string `json:"client,omitempty"`
	Sequence uint64 `json:"sequence,omitempty"`
}

func loadClientTokens(path string) (map[[32]byte]string, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	var input map[string]string
	decoder := json.NewDecoder(io.LimitReader(file, 16<<10))
	if err := decoder.Decode(&input); err != nil || decoder.Decode(new(any)) != io.EOF || len(input) == 0 {
		return nil, errors.New("invalid tenant token file")
	}
	tokens := make(map[[32]byte]string, len(input))
	for tenant, token := range input {
		digest := sha256.Sum256([]byte(token))
		if !identifier.MatchString(tenant) || len(token) < 16 || len(token) > 256 ||
			strings.ContainsAny(token, " \t\r\n") || tokens[digest] != "" {
			return nil, errors.New("invalid or duplicate tenant credentials")
		}
		tokens[digest] = tenant
	}
	return tokens, nil
}

func encodeTenantKey(tenant, key string) string {
	bytes := []byte{0, byte(len(tenant))}
	bytes = append(bytes, tenant...)
	return hex.EncodeToString(append(bytes, key...))
}

func (api *kvAPI) proposal(tenant string, req ClientCommand) (raft.Command, int) {
	if len(req.Key) > 192 || len(req.Value) > 512 {
		return raft.Command{}, http.StatusBadRequest
	}
	command := raft.Command{Key: encodeTenantKey(tenant, req.Key)}
	switch {
	case req.Op == "get" && req.Client == "" && req.Sequence == 0 && req.Value == "":
		command.Op = "kv_get"
	case (req.Op == "put" || req.Op == "delete") && identifier.MatchString(req.Client) && req.Sequence > 0:
		command.Op, command.Client, command.Sequence = "kv_"+req.Op, req.Client, req.Sequence
		if req.Op == "delete" {
			if req.Value != "" {
				return raft.Command{}, http.StatusBadRequest
			}
		} else {
			sealed, err := api.seal(command.Key, req.Value)
			if err != nil {
				return raft.Command{}, http.StatusServiceUnavailable
			}
			command.Value = sealed
		}
	default:
		return raft.Command{}, http.StatusBadRequest
	}
	return command, http.StatusOK
}

func (r *Runtime) ClientHandler() http.Handler {
	mux := http.NewServeMux()
	if r.kv != nil {
		mux.HandleFunc("POST /kv", r.clientCommand)
		mux.HandleFunc("GET /status", r.getStatus)
	}
	return mux
}

func (r *Runtime) clientCommand(w http.ResponseWriter, req *http.Request) {
	token, ok := strings.CutPrefix(req.Header.Get("Authorization"), "Bearer ")
	tenant := r.kv.tenants[sha256.Sum256([]byte(token))]
	if !ok || tenant == "" {
		http.Error(w, "invalid credentials", http.StatusUnauthorized)
		return
	}
	var input ClientCommand
	if !decode(w, req, 4<<10, &input) {
		http.Error(w, "invalid command", http.StatusBadRequest)
		return
	}
	command, status := r.kv.proposal(tenant, input)
	if status != http.StatusOK {
		w.WriteHeader(status)
		return
	}
	r.submit(w, req.Context(), command)
}
