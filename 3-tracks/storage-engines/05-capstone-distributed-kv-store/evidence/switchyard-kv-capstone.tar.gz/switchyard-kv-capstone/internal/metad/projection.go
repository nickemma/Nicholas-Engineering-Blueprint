package metad

import (
	"bufio"
	"encoding/hex"
	"errors"
	"io"
	"os"
	"os/exec"
	"strings"
	"sync"
	"time"
)

type Projection struct {
	mu      sync.Mutex
	child   *exec.Cmd
	in, out *os.File
	lines   *bufio.Reader
	dir     string
	failed  bool
}

func OpenProjection(binary, root, keys, active, read string) (*Projection, error) {
	if err := os.MkdirAll(root, 0700); err != nil {
		return nil, err
	}
	dir, err := os.MkdirTemp(root, "view-")
	if err != nil {
		return nil, err
	}
	p, err := startProjection(binary, dir, keys, active, read)
	if err != nil {
		os.RemoveAll(dir)
		return nil, err
	}
	if line, err := p.read(); err != nil || line != "ready" {
		p.Close()
		return nil, errors.New("Rust projection failed to start")
	}
	return p, nil
}

func startProjection(binary, dir, keys, active, read string) (*Projection, error) {
	stdin, in, err := os.Pipe()
	if err != nil {
		return nil, err
	}
	defer stdin.Close()
	out, stdout, err := os.Pipe()
	if err != nil {
		in.Close()
		return nil, err
	}
	defer stdout.Close()
	child := exec.Command(binary, dir, keys, active, read)
	child.Stdin, child.Stdout, child.Stderr = stdin, stdout, os.Stderr
	if err := child.Start(); err != nil {
		in.Close()
		out.Close()
		return nil, err
	}
	return &Projection{child: child, in: in, out: out, lines: bufio.NewReaderSize(out, 8192), dir: dir}, nil
}

func (p *Projection) read() (string, error) {
	if err := p.out.SetReadDeadline(time.Now().Add(2 * time.Second)); err != nil {
		return "", err
	}
	line, err := p.lines.ReadSlice('\n')
	if err != nil {
		return "", err
	}
	return string(line[:len(line)-1]), nil
}

func (p *Projection) call(fields ...string) (string, error) {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.failed {
		return "", errors.New("projection must be reopened")
	}
	p.failed = true
	if err := p.in.SetWriteDeadline(time.Now().Add(2 * time.Second)); err != nil {
		return "", err
	}
	if _, err := io.WriteString(p.in, strings.Join(fields, "\t")+"\n"); err != nil {
		return "", err
	}
	response, err := p.read()
	p.failed = err != nil
	return response, err
}

func (p *Projection) ack(fields ...string) error {
	if result, err := p.call(fields...); err != nil {
		return err
	} else if result != "ok" {
		return errors.New("invalid projection acknowledgment")
	}
	return nil
}

func (p *Projection) seal(key, value string) (string, error) {
	return p.call("seal", key, hex.EncodeToString([]byte(value)))
}

func (p *Projection) get(key string) (Result, error) {
	response, err := p.call("get", key)
	if err != nil || response == "missing" {
		return Result{}, err
	}
	value, ok := strings.CutPrefix(response, "value ")
	if !ok {
		return Result{}, errors.New("invalid projection read response")
	}
	decoded, err := hex.DecodeString(value)
	return Result{Found: true, Value: string(decoded)}, err
}

func (p *Projection) Close() {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.failed = true
	p.in.Close()
	p.out.Close()
	p.child.Process.Kill()
	p.child.Wait()
	os.RemoveAll(p.dir)
}
