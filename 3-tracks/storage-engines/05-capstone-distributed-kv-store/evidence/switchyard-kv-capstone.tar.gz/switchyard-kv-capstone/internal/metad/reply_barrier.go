//go:build !capstonegate

package metad

func beforeKVReply(string) {}
