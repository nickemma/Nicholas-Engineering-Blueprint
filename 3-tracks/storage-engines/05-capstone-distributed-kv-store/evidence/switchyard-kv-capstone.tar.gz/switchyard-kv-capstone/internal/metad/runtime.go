// Package metad joins the Raft core to a writer, peers, and the client API.
package metad

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"log"
	"time"

	"switchyard/metad/internal/raft"
)

type Status struct {
	ID, Leader, Applied, Snapshot, Vote int
	Term                                uint64
	Role                                raft.Role
}

type outcome struct {
	result Result
	leader int
	code   int
}

type proposal struct {
	ctx     context.Context
	command raft.Command
	reply   chan outcome
}

type waiting struct {
	proposal
	term uint64
}

type Runtime struct {
	rangeLab bool
	kv       *kvAPI
	project  *Projection
	id       int
	members  int
	node     *raft.Node
	disk     interface{ Save(raft.Batch) error }
	messages chan raft.Message
	propose  chan proposal
	status   chan chan Status
}

func New(id, members int, seed int64, stable raft.Stable, disk interface{ Save(raft.Batch) error }) *Runtime {
	node := raft.Restore(id, members, seed, stable)
	node.EnableElectionSafeguards()
	return &Runtime{
		id: id, members: members, node: node, disk: disk,
		messages: make(chan raft.Message, 128), propose: make(chan proposal, 128),
		status: make(chan chan Status),
	}
}

// EnableRangeLab configures a disposable peer before it starts serving.
func (r *Runtime) EnableRangeLab() { r.rangeLab = true }

func (r *Runtime) Run(ctx context.Context, routes []string) error {
	wire := newTransport(ctx, r.id, routes)
	defer wire.close()
	tick := time.NewTicker(25 * time.Millisecond)
	defer tick.Stop()
	pending := make(map[int]waiting)
	store := newState()
	snapshot := r.node.Snapshot()
	if snapshot.Index != 0 {
		var err error
		store, err = decodeState(snapshot.Data)
		if err != nil {
			return fmt.Errorf("restore state at index %d: %w", snapshot.Index, err)
		}
	}
	if err := r.rebuild(store); err != nil {
		return fmt.Errorf("rebuild projection: %w", err)
	}
	status := Status{
		ID: r.id, Applied: snapshot.Index, Snapshot: snapshot.Index,
		Vote: r.node.Vote(), Term: r.node.Term(), Role: r.node.Role(),
	}
	nextSnapshot := snapshot.Index + compactEvery

	for {
		select {
		case <-ctx.Done():
			return nil
		case <-tick.C:
			r.node.Tick()
		case message := <-r.messages:
			r.node.Step(message)
		case answer := <-r.status:
			answer <- status
		case p := <-r.propose:
			switch {
			case p.ctx.Err() != nil:
			case len(pending) >= 128:
				p.reply <- outcome{code: 503}
			default:
				if leaseOperation(p.command.Op) {
					p.command.At = time.Now().UnixMilli()
				}
				index, term, ok := r.node.Propose(p.command)
				if ok {
					pending[index] = waiting{proposal: p, term: term}
				} else {
					p.reply <- outcome{code: 409, leader: r.node.Leader()}
				}
			}
		}

		ready := r.node.Take()
		var installed *state
		if incoming := ready.Save.Snapshot; incoming != nil {
			var err error
			installed, err = decodeState(incoming.Data)
			if err != nil {
				return fmt.Errorf("install state at index %d: %w", incoming.Index, err)
			}
		}
		if err := r.disk.Save(ready.Save); err != nil {
			return fmt.Errorf("persist before sending: %w", err)
		}
		if installed != nil {
			if err := r.rebuild(installed); err != nil {
				return fmt.Errorf("install projection: %w", err)
			}
			store = installed
			status.Applied = ready.Save.Snapshot.Index
			status.Snapshot = status.Applied
			nextSnapshot = status.Applied + compactEvery
			log.Printf("installed peer=%d index=%d", r.id, status.Applied)
		}
		role, term := r.node.Role(), r.node.Term()
		if role == raft.Leader && (role != status.Role || term != status.Term) {
			log.Printf("elected peer=%d term=%d", r.id, term)
		}
		status.Role, status.Term, status.Leader, status.Vote = role, term, r.node.Leader(), r.node.Vote()
		for _, message := range ready.Messages {
			wire.send(message)
		}
		for _, entry := range ready.Applied {
			value, err := r.apply(store, entry)
			if err != nil {
				return fmt.Errorf("apply at index %d: %w", entry.Index, err)
			}
			status.Applied = entry.Index
			payload, _ := json.Marshal(entry.Entry) // Entry has only JSON scalar fields.
			log.Printf("applied peer=%d index=%d term=%d digest=%x", r.id, entry.Index, entry.Term, sha256.Sum256(payload))
			if p, exists := pending[entry.Index]; exists && p.term == entry.Term {
				beforeKVReply(entry.Command.Op)
				p.reply <- outcome{result: value, code: 200}
				delete(pending, entry.Index)
			}
		}
		if status.Applied >= nextSnapshot {
			nextSnapshot = status.Applied + compactEvery
			data, err := store.encode()
			if err != nil {
				return err
			}
			if len(data) <= raft.MaxSnapshotBytes {
				if err := r.node.Compact(status.Applied, data); err != nil {
					return err
				}
				if err := r.disk.Save(r.node.Take().Save); err != nil {
					return fmt.Errorf("persist local snapshot: %w", err)
				}
				status.Snapshot = status.Applied
				log.Printf("compacted peer=%d index=%d", r.id, status.Snapshot)
			}
		}
		for index, p := range pending {
			switch {
			case p.ctx.Err() != nil:
				delete(pending, index)
			case role != raft.Leader || p.term != term:
				p.reply <- outcome{code: 409, leader: status.Leader}
				delete(pending, index)
			}
		}
	}
}
