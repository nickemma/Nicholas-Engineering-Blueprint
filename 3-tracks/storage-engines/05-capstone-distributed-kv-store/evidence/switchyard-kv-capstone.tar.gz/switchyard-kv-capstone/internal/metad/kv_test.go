package metad

import (
	"testing"

	"switchyard/metad/internal/raft"
)

func TestRetryAfterLostReply(t *testing.T) {
	s := newState()
	s.mutate(raft.Command{Op: "put", Key: "job", Value: "queued"})
	swap := raft.Command{Op: "cas", Key: "job", Expect: "queued", Value: "running", Client: "worker", Sequence: 1}
	original := s.mutate(swap)
	if !original.Swapped {
		t.Fatalf("first compare-and-swap: %+v", original)
	}
	s.mutate(raft.Command{Op: "put", Key: "job", Value: "done"})
	if retry := s.mutate(swap); retry != original || s.values["job"] != "done" {
		t.Fatalf("retry %+v changed the result or state", retry)
	}
	swap.Value = "different"
	if result := s.mutate(swap); result.Error == "" {
		t.Fatal("reused sequence with different input was accepted")
	}
	t.Log("lost-reply retry returned running; stored state stayed done")
}
