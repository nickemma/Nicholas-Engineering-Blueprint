package metad

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"time"

	"switchyard/metad/internal/raft"
)

func (r *Runtime) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /raft", r.receive)
	if r.kv == nil {
		mux.HandleFunc("POST /command", r.command)
	}
	mux.HandleFunc("GET /status", r.getStatus)
	return mux
}

func decode(w http.ResponseWriter, req *http.Request, limit int64, target any) bool {
	d := json.NewDecoder(http.MaxBytesReader(w, req.Body, limit))
	d.DisallowUnknownFields()
	return d.Decode(target) == nil && d.Decode(&struct{}{}) == io.EOF
}

func reply(w http.ResponseWriter, code int, value any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(value)
}

func (r *Runtime) receive(w http.ResponseWriter, req *http.Request) {
	var message raft.Message
	if !decode(w, req, 256<<10, &message) || message.To != r.id ||
		message.From < 1 || message.From > r.members || message.From == r.id ||
		(message.Term == 0 && message.Kind != raft.PreVote && message.Kind != raft.PreVoteReply) ||
		len(message.Entries) > 16 {
		http.Error(w, "invalid peer message", http.StatusBadRequest)
		return
	}
	switch message.Kind {
	case raft.RequestVote, raft.VoteReply, raft.Append, raft.AppendReply, raft.Install, raft.PreVote, raft.PreVoteReply:
	default:
		http.Error(w, "unknown message", http.StatusBadRequest)
		return
	}
	select {
	case r.messages <- message:
		w.WriteHeader(http.StatusNoContent)
	default:
		w.WriteHeader(http.StatusServiceUnavailable)
	}
}

func (r *Runtime) command(w http.ResponseWriter, req *http.Request) {
	var command raft.Command
	if !decode(w, req, 16<<10, &command) {
		http.Error(w, "invalid command", http.StatusBadRequest)
		return
	}
	valid := validCommand(command) && (command.Epoch == 0 || r.rangeLab)
	if movement(command.Op) {
		valid = r.rangeLab && validMove(command)
	}
	if !valid {
		http.Error(w, "invalid command", http.StatusBadRequest)
		return
	}
	r.submit(w, req.Context(), command)
}

func (r *Runtime) submit(w http.ResponseWriter, request context.Context, command raft.Command) {
	ctx, cancel := context.WithTimeout(request, 900*time.Millisecond)
	defer cancel()
	p := proposal{ctx: ctx, command: command, reply: make(chan outcome, 1)}
	select {
	case r.propose <- p:
	case <-ctx.Done():
		w.WriteHeader(http.StatusGatewayTimeout)
		return
	}
	select {
	case result := <-p.reply:
		if result.code == http.StatusOK {
			reply(w, result.code, result.result)
		} else {
			reply(w, result.code, map[string]int{"leader": result.leader})
		}
	case <-ctx.Done():
		w.WriteHeader(http.StatusGatewayTimeout)
	}
}

func (r *Runtime) getStatus(w http.ResponseWriter, req *http.Request) {
	ctx, cancel := context.WithTimeout(req.Context(), 250*time.Millisecond)
	defer cancel()
	answer := make(chan Status, 1)
	select {
	case r.status <- answer:
	case <-ctx.Done():
		w.WriteHeader(http.StatusServiceUnavailable)
		return
	}
	select {
	case status := <-answer:
		reply(w, http.StatusOK, status)
	case <-ctx.Done():
		w.WriteHeader(http.StatusServiceUnavailable)
	}
}
