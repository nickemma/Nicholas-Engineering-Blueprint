//go:build capstonegate

package metad

import (
	"log"
	"os"
	"time"
)

func beforeKVReply(op string) {
	file := os.Getenv("METAD_GATE_ARM")
	if op != "kv_put" || file == "" || os.Remove(file) != nil {
		return
	}
	log.Print("capstone: committed and applied; reply paused")
	for {
		time.Sleep(time.Second)
	}
}
