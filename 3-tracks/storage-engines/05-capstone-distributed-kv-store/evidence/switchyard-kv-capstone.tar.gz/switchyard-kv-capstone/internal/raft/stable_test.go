package raft

import (
	"slices"
	"testing"
)

func TestCrashAroundVote(t *testing.T) {
	run := func(save bool) (afterSave, afterSend bool) {
		vote := func(n *Node, from int) Ready {
			n.Step(Message{Kind: RequestVote, From: from, To: 2, Term: 7})
			return n.Take()
		}
		var disk Stable
		first := vote(Restore(2, 3, 1, disk), 1)
		if len(first.Messages) != 1 || !first.Messages[0].OK {
			t.Fatal("first vote was refused")
		}
		// A crash before save is safe only while the reply stays private.
		beforeSave := vote(Restore(2, 3, 2, disk), 3)
		if !beforeSave.Messages[0].OK {
			t.Fatal("an unsaved vote survived")
		}
		if save {
			if err := disk.Apply(first.Save, 3); err != nil {
				t.Fatal(err)
			}
		}
		afterSave = vote(Restore(2, 3, 2, disk), 3).Messages[0].OK
		// With the same disk, sending the first reply changes outsiders'
		// knowledge. It leaves the restarted voter's answer unchanged.
		afterSend = vote(Restore(2, 3, 3, disk), 3).Messages[0].OK
		return
	}
	a, b := run(true)
	if a || b {
		t.Fatal("double vote after a durable save")
	}
	_, second := run(false)
	if !second {
		t.Fatal("negative control should vote twice in term 7")
	}
	t.Log("save before send: restarted voter refuses the second candidate")
	t.Log("send without save: both candidates can count peer 2 in term 7")
}

func TestStableReplacementIsAtomic(t *testing.T) {
	var disk Stable
	if err := disk.Apply(Batch{
		Hard: &HardState{Term: 2, Vote: 1}, From: 1,
		Entries: []Entry{{Term: 1}, {Term: 2}},
	}, 3); err != nil {
		t.Fatal(err)
	}
	old := slices.Clone(disk.Entries)
	if err := disk.Apply(Batch{
		Hard: &HardState{Term: 3}, From: 2,
		Entries: []Entry{{Term: 3}, {Term: 4}},
	}, 3); err == nil {
		t.Fatal("accepted entry from a future term")
	}
	if disk.Hard.Term != 2 || !slices.Equal(disk.Entries, old) {
		t.Fatal("invalid batch partially changed stable state")
	}
	if err := disk.Apply(Batch{Hard: &HardState{Term: 3}, From: 2, Entries: []Entry{{Term: 3}}}, 3); err != nil {
		t.Fatal(err)
	}
	if got := Restore(1, 3, 7, disk).Entries(); !slices.Equal(got, []Entry{{Term: 1}, {Term: 3}}) {
		t.Fatal("wrong replay", got)
	}
}

func TestRestartRebuildsApplicationAfterAck(t *testing.T) {
	var disk Stable
	n := Restore(2, 3, 7, disk)
	appendAndCommit := Message{Kind: Append, From: 1, To: 2, Term: 1, Commit: 1,
		Entries: []Entry{{Term: 1, Command: Command{Op: "put", Key: "route", Value: "kept"}}}}
	n.Step(appendAndCommit)
	ready := n.Take()
	if err := disk.Apply(ready.Save, 3); err != nil {
		t.Fatal(err)
	}
	if len(ready.Messages) != 1 || !ready.Messages[0].OK || len(ready.Applied) != 1 {
		t.Fatal("expected a reply and an application after saving", ready)
	}
	// The reply can escape now. Crash before delivering Applied to the store.
	n = Restore(2, 3, 8, disk)
	n.Step(Message{Kind: Append, From: 1, To: 2, Term: 1, Prev: 1, PrevTerm: 1, Commit: 1})
	replayed := n.Take()
	if !replayed.Save.Empty() || !slices.Equal(replayed.Applied, ready.Applied) || !replayed.Messages[0].OK {
		t.Fatal("restart lost a durable command or reapplied without a commit", replayed)
	}
	t.Log("a follower that crashed after acknowledgment rebuilt application from the durable entry")
}
