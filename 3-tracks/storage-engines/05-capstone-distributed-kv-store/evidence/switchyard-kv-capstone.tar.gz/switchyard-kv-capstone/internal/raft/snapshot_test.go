package raft

import (
	"slices"
	"testing"
)

func TestReplayOldLogBesideNewSnapshot(t *testing.T) {
	hard := HardState{Term: 3, Vote: 2}
	a, b, c := Entry{Term: 1}, Entry{Term: 2}, Entry{Term: 3}
	original := Batch{Hard: &hard, From: 1, Entries: []Entry{a, b, c}}
	for _, test := range []struct {
		name string
		term uint64
		want []Entry
	}{
		{"matching boundary", 2, []Entry{c}},
		{"different boundary", 3, nil},
	} {
		t.Run(test.name, func(t *testing.T) {
			var disk Stable
			if err := disk.Apply(original, 3); err != nil {
				t.Fatal(err)
			}
			diskBeforePublish := Restore(1, 3, 1, disk)
			if diskBeforePublish.Snapshot().Index != 0 || len(diskBeforePublish.Entries()) != 3 {
				t.Fatal("original complete log did not survive")
			}
			marker := Snapshot{Index: 2, Term: test.term, Data: "job=queued"}
			if err := disk.Apply(Batch{Snapshot: &marker}, 3); err != nil {
				t.Fatal(err)
			}
			node := Restore(1, 3, 1, disk)
			if node.Snapshot() != marker || node.Vote() != 2 || node.Term() != 3 ||
				node.commit != 2 || !slices.Equal(node.Entries(), test.want) {
				t.Fatalf("restored the wrong boundary, hard state or suffix: %+v", disk)
			}
			t.Logf("snapshot index=%d term=%d; vote=%d; remaining entries=%d",
				marker.Index, marker.Term, node.Vote(), len(node.Entries()))
		})
	}
}
