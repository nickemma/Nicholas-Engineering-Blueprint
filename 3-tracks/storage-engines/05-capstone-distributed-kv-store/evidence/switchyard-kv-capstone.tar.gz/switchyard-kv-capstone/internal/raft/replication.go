package raft

import "slices"

type Command struct {
	Op, Key, Value string
	Client         string `json:",omitempty"`
	Epoch          uint64 `json:",omitempty"`
	Sequence       uint64 `json:",omitempty"`
	Expect         string `json:",omitempty"`
	Owner          string `json:",omitempty"`
	At             int64  `json:",omitempty"` // leader's time, in milliseconds
	TTL            int64  `json:",omitempty"`
	Token          int    `json:",omitempty"`
}

type Entry struct {
	Term    uint64
	Command Command
}

type progress struct {
	next, match int
}

func (n *Node) Entries() []Entry { return slices.Clone(n.log[1:]) }

func (n *Node) upToDate(m Message) bool {
	last := n.lastIndex()
	term := n.at(last).Term
	return m.PrevTerm > term || (m.PrevTerm == term && m.Prev >= last)
}

func (n *Node) startReplication() {
	n.progress = make([]progress, n.members+1)
	for peer := 1; peer <= n.members; peer++ {
		n.progress[peer].next = n.lastIndex() + 1
	}
}

func (n *Node) Propose(command Command) (index int, term uint64, ok bool) {
	if n.role != Leader {
		return 0, 0, false
	}
	n.appendLocal(command)
	n.tryCommit()
	n.broadcast()
	return n.lastIndex(), n.term, true
}

func (n *Node) broadcast() {
	for peer := 1; peer <= n.members; peer++ {
		if peer != n.id {
			n.replicate(peer)
		}
	}
}

func (n *Node) replicate(peer int) {
	next := n.progress[peer].next
	if next <= n.snapshot.Index {
		n.send(peer, Message{Kind: Install, Snapshot: &Snapshot{
			Index: n.snapshot.Index, Term: n.snapshot.Term, Data: n.snapshot.Data,
		}})
		return
	}
	end := min(next+16, n.lastIndex()+1)
	base := n.snapshot.Index
	n.send(peer, Message{
		Kind: Append, Prev: next - 1, PrevTerm: n.at(next - 1).Term,
		Entries: slices.Clone(n.log[next-base : end-base]), Commit: n.commit,
	})
}

func (n *Node) acceptAppend(m Message) {
	if m.Prev < n.snapshot.Index {
		n.send(m.From, Message{Kind: AppendReply, Prev: m.Prev, Match: n.snapshot.Index, PrevTerm: n.snapshot.Term})
		return
	}
	if !n.matches(m.Prev, m.PrevTerm) {
		n.rejectAppend(m)
		return
	}
	for i, entry := range m.Entries {
		index := m.Prev + 1 + i
		if !n.matches(index, entry.Term) {
			n.replaceSuffix(index, m.Entries[i:])
			break
		}
	}
	last := m.Prev + len(m.Entries)
	n.commitThrough(min(m.Commit, last))
	n.send(m.From, Message{Kind: AppendReply, OK: true, Prev: m.Prev, Match: last})
}

func (n *Node) rejectAppend(m Message) {
	n.send(m.From, Message{Kind: AppendReply, Prev: m.Prev})
}

func (n *Node) appendReply(m Message) {
	p := &n.progress[m.From]
	if !m.OK {
		// Ignore a rejection for a probe that has already been superseded.
		if m.Prev != p.next-1 {
			return
		}
		if m.Match >= p.next && n.matches(m.Match, m.PrevTerm) {
			p.next = m.Match + 1
		} else if p.next > p.match+1 {
			p.next--
		} else {
			return
		}
		n.replicate(m.From)
		return
	}
	if m.Match <= p.match || m.Match > n.lastIndex() {
		return
	}
	p.match, p.next = m.Match, m.Match+1
	if n.tryCommit() {
		n.broadcast()
		return
	}
	if p.next <= n.lastIndex() {
		n.replicate(m.From)
	}
}
