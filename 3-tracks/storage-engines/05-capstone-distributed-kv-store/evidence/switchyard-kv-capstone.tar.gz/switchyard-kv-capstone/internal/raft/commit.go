package raft

import "slices"

type Applied struct {
	Index int
	Entry
}

func (n *Node) appendLocal(command Command) {
	n.replaceSuffix(n.lastIndex()+1, []Entry{{Term: n.term, Command: command}})
}

// tryCommit runs only on the leader. The median-like order statistic
// is the largest index held by a strict majority, including the leader.
func (n *Node) tryCommit() bool {
	matches := make([]int, n.members)
	for peer := 1; peer <= n.members; peer++ {
		matches[peer-1] = n.progress[peer].match
	}
	matches[n.id-1] = n.lastIndex()
	slices.Sort(matches)
	index := matches[(len(matches)-1)/2]
	if index <= n.commit || n.at(index).Term != n.term {
		return false
	}
	n.commitThrough(index)
	return true
}

func (n *Node) commitThrough(index int) {
	for n.commit < index {
		n.commit++
		n.ready.Applied = append(n.ready.Applied, Applied{Index: n.commit, Entry: n.at(n.commit)})
	}
}
