package raft

import "testing"

func TestFigureEight(t *testing.T) {
	// The Figure 8(c) leader holds the old term-2 entry on three out
	// of five peers. Three matches at index 2 are insufficient.
	n := New(1, 5, 7)
	n.term, n.role, n.commit = 4, Leader, 1
	n.log = []Entry{
		{}, {Term: 1}, {Term: 2, Command: Command{Op: "put", Key: "route", Value: "old"}},
	}
	n.startReplication()
	n.appendLocal(Command{}) // Index 3 is in term 4.
	reply := func(from, match int) {
		n.Step(Message{Kind: AppendReply, From: from, To: 1, Term: 4, OK: true, Match: match})
	}
	reply(2, 2)
	reply(3, 2)
	if ready := n.Take(); len(ready.Applied) != 0 {
		t.Fatalf("old term-2 entry applied before a current-term majority: %+v", ready.Applied)
	}
	t.Log("three copies of index 2 from term 2 leave commit at index 1")
	reply(2, 3)
	reply(3, 3)
	ready := n.Take()
	if len(ready.Applied) != 2 || ready.Applied[0].Index != 2 || ready.Applied[1].Index != 3 {
		t.Fatalf("missing ordered prefix: %+v", ready.Applied)
	}
	t.Log("three copies of index 3 from term 4 commit indexes 2 and 3 in order")
}

func TestVoteChecksLastTermBeforeLength(t *testing.T) {
	n := New(1, 3, 7)
	n.term = 4
	n.log = []Entry{{}, {Term: 3}}
	n.Step(Message{Kind: RequestVote, From: 2, To: 1, Term: 4, Prev: 8, PrevTerm: 2})
	if ready := n.Take(); len(ready.Messages) != 1 || ready.Messages[0].OK {
		t.Fatalf("granted a vote to a longer but older log: %+v", ready)
	}
}

func TestStaleRejectionKeepsFollowerProgress(t *testing.T) {
	n := New(1, 3, 7)
	n.term, n.role = 2, Leader
	n.log = []Entry{{}, {Term: 1}, {Term: 2}}
	n.startReplication()
	n.Step(Message{Kind: AppendReply, From: 2, To: 1, Term: 2, OK: true, Match: 2})
	n.Step(Message{Kind: AppendReply, From: 2, To: 1, Term: 2, Prev: 2})
	if p := n.progress[2]; p.match != 2 || p.next != 3 {
		t.Fatalf("stale rejection regressed progress: %+v", p)
	}
}
