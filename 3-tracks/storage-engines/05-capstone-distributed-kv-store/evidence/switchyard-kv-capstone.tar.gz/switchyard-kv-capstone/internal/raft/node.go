// Package raft holds a node's state transitions. Its driver supplies time and I/O.
package raft

import "math/rand"

type Role string

const (
	Follower     Role = "follower"
	Candidate    Role = "candidate"
	PreCandidate Role = "pre_candidate"
	Leader       Role = "leader"
)

type Kind string

const (
	RequestVote  Kind = "vote"
	VoteReply    Kind = "vote_reply"
	Append       Kind = "append"
	AppendReply  Kind = "append_reply"
	Install      Kind = "install_snapshot"
	PreVote      Kind = "pre_vote"
	PreVoteReply Kind = "pre_vote_reply"
)

type Message struct {
	Kind                Kind
	From, To            int
	Term                uint64
	OK                  bool
	Prev, Match, Commit int
	PrevTerm            uint64
	Entries             []Entry
	Snapshot            *Snapshot `json:",omitempty"`
	ProbeTerm, Round    uint64
}

type Ready struct {
	Save     Batch
	Messages []Message
	Applied  []Applied
}

type Node struct {
	id            int
	members       int // IDs are contiguous, starting at 1.
	role          Role
	term          uint64
	vote          int
	leader        int
	votes         map[int]bool
	elapsed       int
	deadline      int
	rng           *rand.Rand
	ready         Ready
	log           []Entry
	progress      []progress
	commit        int
	snapshot      Snapshot
	safeguards    bool
	round         uint64
	contacts      map[int]bool
	quorumElapsed int
}

func New(id, members int, seed int64) *Node {
	n := &Node{id: id, members: members, role: Follower, rng: rand.New(rand.NewSource(seed))}
	n.log = []Entry{{}} // Index zero is the sentinel.
	n.resetTimer()
	return n
}

func (n *Node) Role() Role   { return n.role }
func (n *Node) Term() uint64 { return n.term }
func (n *Node) Leader() int  { return n.leader }

func (n *Node) Take() Ready {
	ready := n.ready
	n.ready = Ready{}
	return ready
}

func (n *Node) send(to int, message Message) {
	message.From, message.To, message.Term = n.id, to, n.term
	n.ready.Messages = append(n.ready.Messages, message)
}

func (n *Node) resetTimer() {
	n.elapsed = 0
	n.deadline = quorumTicks + n.rng.Intn(quorumTicks)
}

func (n *Node) Tick() {
	n.elapsed++
	if n.role == Leader {
		if n.safeguards && !n.checkQuorum() {
			return
		}
		if n.elapsed >= 3 {
			n.elapsed = 0
			n.broadcast()
		}
		return
	}
	if n.elapsed >= n.deadline {
		if n.safeguards {
			n.probe()
		} else {
			n.campaign()
		}
	}
}

func (n *Node) campaign() {
	n.role, n.leader = Candidate, 0
	n.setHard(n.term+1, n.id)
	n.votes = map[int]bool{n.id: true}
	n.resetTimer()
	if n.win() {
		return
	}
	for peer := 1; peer <= n.members; peer++ {
		if peer != n.id {
			n.send(peer, Message{Kind: RequestVote, Prev: n.lastIndex(), PrevTerm: n.at(n.lastIndex()).Term})
		}
	}
}

func (n *Node) win() bool {
	if len(n.votes) <= n.members/2 {
		return false
	}
	n.role, n.leader, n.elapsed = Leader, n.id, 0
	n.contacts, n.quorumElapsed = make(map[int]bool), 0
	n.startReplication()
	n.appendLocal(Command{}) // Commit prior entries with a new-term no-op.
	n.tryCommit()
	n.broadcast()
	return true
}

func (n *Node) Step(m Message) {
	if m.To != n.id || m.From < 1 || m.From > n.members || m.From == n.id {
		return
	}
	if m.Kind == PreVote || m.Kind == PreVoteReply {
		if n.safeguards {
			n.stepProbe(m)
		}
		return
	}
	if m.Term == 0 {
		return
	}
	if m.Term > n.term {
		n.role, n.leader = Follower, 0
		n.setHard(m.Term, 0)
	}
	if m.Term < n.term {
		switch m.Kind {
		case RequestVote:
			n.send(m.From, Message{Kind: VoteReply})
		case Append:
			n.rejectAppend(m)
		}
		return
	}
	switch m.Kind {
	case RequestVote:
		grant := (n.vote == 0 || n.vote == m.From) && n.upToDate(m)
		if grant {
			n.setHard(n.term, m.From)
			n.resetTimer()
		}
		n.send(m.From, Message{Kind: VoteReply, OK: grant})
	case VoteReply:
		if n.role == Candidate && m.OK {
			n.votes[m.From] = true
			n.win()
		}
	case Append, Install:
		n.role, n.leader = Follower, m.From
		n.resetTimer()
		if m.Kind == Install {
			n.acceptSnapshot(m)
		} else {
			n.acceptAppend(m)
		}
	case AppendReply:
		if n.role == Leader {
			if n.safeguards {
				n.contacts[m.From] = true
			}
			n.appendReply(m)
		}
	}
}
