package raft

const quorumTicks = 12

func (n *Node) EnableElectionSafeguards() { n.safeguards = true }

func (n *Node) probe() {
	n.role, n.leader = PreCandidate, 0
	n.round = n.rng.Uint64()
	n.votes = map[int]bool{n.id: true}
	n.resetTimer()
	if n.members == 1 {
		n.campaign()
		return
	}
	last := n.lastIndex()
	for peer := 1; peer <= n.members; peer++ {
		if peer != n.id {
			n.send(peer, Message{
				Kind: PreVote, ProbeTerm: n.term + 1, Round: n.round,
				Prev: last, PrevTerm: n.at(last).Term,
			})
		}
	}
}

func (n *Node) stepProbe(m Message) {
	if m.Kind == PreVote {
		heardLeader := n.role == Leader || (n.leader != 0 && n.elapsed < n.deadline)
		grant := !heardLeader && m.ProbeTerm > n.term && n.upToDate(m)
		n.send(m.From, Message{Kind: PreVoteReply, ProbeTerm: m.ProbeTerm, Round: m.Round, OK: grant})
		return
	}
	if n.role == PreCandidate && m.OK && m.ProbeTerm == n.term+1 && m.Round == n.round {
		n.votes[m.From] = true
		if len(n.votes) > n.members/2 {
			n.campaign()
		}
	}
}

func (n *Node) checkQuorum() bool {
	n.quorumElapsed++
	if n.quorumElapsed < quorumTicks {
		return true
	}
	quorum := 1+len(n.contacts) > n.members/2 // The leader counts itself.
	n.quorumElapsed = 0
	clear(n.contacts)
	if !quorum {
		n.role, n.leader = Follower, 0
		n.resetTimer()
	}
	return quorum
}
