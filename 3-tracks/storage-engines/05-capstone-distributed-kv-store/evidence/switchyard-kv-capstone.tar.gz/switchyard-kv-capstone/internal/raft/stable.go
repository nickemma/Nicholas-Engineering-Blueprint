package raft

import (
	"fmt"
	"slices"
)

type HardState struct {
	Term uint64
	Vote int
}

// Batch is one atomic change. From is the 1-based start of a new suffix,
// or zero for a change that leaves the log alone.
type Batch struct {
	Snapshot *Snapshot  `json:",omitempty"`
	Hard     *HardState `json:",omitempty"`
	From     int        `json:",omitempty"`
	Entries  []Entry    `json:",omitempty"`
}

func (b Batch) Empty() bool {
	return b.Snapshot == nil && b.Hard == nil && b.From == 0 && len(b.Entries) == 0
}

type Stable struct {
	Snapshot Snapshot
	Hard     HardState
	Entries  []Entry // Index Snapshot.Index + 1 is stored at offset 0.
}

func (s *Stable) Apply(batch Batch, members int) error {
	hard := s.Hard
	if batch.Hard != nil {
		hard = *batch.Hard
		if hard.Term == 0 || hard.Term < s.Hard.Term || hard.Vote < 0 || hard.Vote > members ||
			(hard.Term == s.Hard.Term && s.Hard.Vote != 0 && hard.Vote != s.Hard.Vote) {
			return fmt.Errorf("invalid persisted term or vote: %+v", hard)
		}
	}
	snap := s.Snapshot
	entries := s.Entries
	if incoming := batch.Snapshot; incoming != nil {
		if !incoming.valid(hard.Term) || incoming.Index <= snap.Index {
			return fmt.Errorf("invalid persisted snapshot at index %d", incoming.Index)
		}
		offset := incoming.Index - snap.Index
		if offset <= len(entries) && entries[offset-1].Term == incoming.Term {
			entries = slices.Clone(entries[offset:])
		} else {
			entries = nil
		}
		snap = *incoming
	}
	from := batch.From - snap.Index - 1
	if (batch.From == 0) != (len(batch.Entries) == 0) ||
		(batch.From != 0 && (from < 0 || from > len(entries))) {
		return fmt.Errorf("invalid persisted suffix at index %d", batch.From)
	}
	if batch.From != 0 {
		previous := snap.Term
		if from > 0 {
			previous = entries[from-1].Term
		}
		for _, entry := range batch.Entries {
			if entry.Term == 0 || entry.Term < previous || entry.Term > hard.Term {
				return fmt.Errorf("invalid persisted entry term %d", entry.Term)
			}
			previous = entry.Term
		}
		entries = append(entries[:from], batch.Entries...)
	}
	s.Hard, s.Snapshot, s.Entries = hard, snap, entries
	return nil
}

func Restore(id, members int, seed int64, stable Stable) *Node {
	n := New(id, members, seed)
	n.term, n.vote = stable.Hard.Term, stable.Hard.Vote
	n.snapshot, n.commit = stable.Snapshot, stable.Snapshot.Index
	n.log[0].Term = stable.Snapshot.Term
	n.log = append(n.log, stable.Entries...)
	return n
}

func (n *Node) setHard(term uint64, vote int) {
	if n.term == term && n.vote == vote {
		return
	}
	n.term, n.vote = term, vote
	n.ready.Save.Hard = &HardState{Term: term, Vote: vote}
}

func (n *Node) replaceSuffix(index int, entries []Entry) {
	n.log = append(n.log[:index-n.snapshot.Index], entries...)
	n.ready.Save.From = index
	n.ready.Save.Entries = slices.Clone(entries)
}
