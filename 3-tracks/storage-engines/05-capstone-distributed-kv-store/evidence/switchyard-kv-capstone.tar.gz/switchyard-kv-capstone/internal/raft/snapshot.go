package raft

import (
	"fmt"
	"slices"
)

// A snapshot represents the state after applying Index. Data is an opaque
// immutable string so sending a snapshot cannot share a mutable buffer.
type Snapshot struct {
	Index int
	Term  uint64
	Data  string
}

// Leave room for JSON escaping and envelope fields in the peer transport.
const MaxSnapshotBytes = 128 << 10

func (s Snapshot) valid(currentTerm uint64) bool {
	return s.Index > 0 && s.Term > 0 && s.Term <= currentTerm &&
		len(s.Data) > 0 && len(s.Data) <= MaxSnapshotBytes
}

func (n *Node) Snapshot() Snapshot { return n.snapshot }
func (n *Node) Vote() int          { return n.vote }

func (n *Node) lastIndex() int     { return n.snapshot.Index + len(n.log) - 1 }
func (n *Node) at(index int) Entry { return n.log[index-n.snapshot.Index] }

func (n *Node) matches(index int, term uint64) bool {
	return index >= n.snapshot.Index && index <= n.lastIndex() && n.at(index).Term == term
}

func (n *Node) Compact(index int, data string) error {
	if index <= n.snapshot.Index || index > n.commit {
		return fmt.Errorf("cannot compact through index %d", index)
	}
	snapshot := Snapshot{Index: index, Term: n.at(index).Term, Data: data}
	if !snapshot.valid(n.term) {
		return fmt.Errorf("invalid snapshot at index %d", index)
	}
	n.install(snapshot)
	return nil
}

func (n *Node) install(snapshot Snapshot) {
	var suffix []Entry
	if n.matches(snapshot.Index, snapshot.Term) {
		suffix = slices.Clone(n.log[snapshot.Index-n.snapshot.Index+1:])
	}
	n.log = append([]Entry{{Term: snapshot.Term}}, suffix...)
	n.snapshot = snapshot
	n.commit = max(n.commit, snapshot.Index)
	n.ready.Save.Snapshot = &snapshot
}

func (n *Node) acceptSnapshot(m Message) {
	if m.Snapshot == nil || !m.Snapshot.valid(m.Term) {
		return
	}
	snapshot := *m.Snapshot
	if snapshot.Index > n.commit {
		n.install(snapshot)
	}
	n.send(m.From, Message{Kind: AppendReply, OK: true, Match: snapshot.Index})
}
