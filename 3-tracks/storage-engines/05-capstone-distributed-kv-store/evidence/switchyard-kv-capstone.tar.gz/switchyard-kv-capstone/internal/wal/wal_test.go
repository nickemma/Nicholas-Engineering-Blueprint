package wal

import (
	"bytes"
	"os"
	"path/filepath"
	"testing"

	"switchyard/metad/internal/raft"
)

func TestKlogRoundTrip(t *testing.T) {
	binary := os.Getenv("METAD_WAL_WRITER")
	if binary == "" {
		t.Skip("build the Rust writer and set METAD_WAL_WRITER")
	}
	path := filepath.Join(t.TempDir(), "peer.klog")
	w, _, _, err := Open(binary, path, 3)
	if err != nil {
		t.Fatal(err)
	}
	first := raft.Batch{Hard: &raft.HardState{Term: 3, Vote: 1}, From: 1,
		Entries: []raft.Entry{{Term: 1}, {Term: 3}}}
	err = w.Save(first)
	w.Close()
	if err != nil {
		t.Fatal(err)
	}
	info, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	w, stable, recovered, err := Open(binary, path, 3)
	if err != nil {
		t.Fatal(err)
	}
	if recovered != 0 || stable.Hard != *first.Hard || len(stable.Entries) != 2 {
		w.Close()
		t.Fatalf("wrong replay: %+v, trimmed %d bytes", stable, recovered)
	}
	err = w.Save(raft.Batch{Hard: &raft.HardState{Term: 4}, From: 2,
		Entries: []raft.Entry{{Term: 4}}})
	w.Close()
	if err != nil {
		t.Fatal(err)
	}
	w, stable, _, err = Open(binary, path, 3)
	if err != nil {
		t.Fatal(err)
	}
	w.Close()
	if len(stable.Entries) != 2 || stable.Entries[1].Term != 4 {
		t.Fatal("new suffix was not replayed", stable)
	}
	if err := os.Truncate(path, info.Size()+15); err != nil {
		t.Fatal(err)
	}
	w, stable, recovered, err = Open(binary, path, 3)
	if err != nil {
		t.Fatal(err)
	}
	w.Close()
	if recovered != 15 || stable.Hard != *first.Hard || stable.Entries[1].Term != 3 {
		t.Fatalf("wrong repair: %+v, trimmed %d bytes", stable, recovered)
	}
	t.Logf("replayed a replacement, then trimmed %d torn bytes and recovered the previous suffix", recovered)

	broken, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	broken[12] ^= 1 // A complete frame with a changed payload.
	if err := os.WriteFile(path, broken, 0600); err != nil {
		t.Fatal(err)
	}
	if w, _, _, err := Open(binary, path, 3); err == nil {
		w.Close()
		t.Fatal("opened a corrupt log")
	}
	after, err := os.ReadFile(path)
	if err != nil || !bytes.Equal(after, broken) {
		t.Fatal("startup changed the corrupt file", err)
	}
	t.Log("refused a complete damaged frame and preserved its bytes")
}
