// Package wal uses the Rust klog process as a single, locked Raft writer.
package wal

import (
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"time"

	"switchyard/metad/internal/raft"
)

const maxPayload = 1 << 20 // klog's one MiB payload ceiling

type record struct {
	Version int
	Batch   raft.Batch
}

type Writer struct {
	child        *exec.Cmd
	binary, path string
	members      int
	lock         *os.File
	stable       raft.Stable
	snapshots    int
	failed       bool
	in           *os.File
	out          *os.File
}

func Open(binary, path string, members int) (*Writer, raft.Stable, uint64, error) {
	lock, err := lockWAL(path)
	if err != nil {
		return nil, raft.Stable{}, 0, err
	}
	// An interrupted replacement is disposable. Only path is authoritative.
	if err := os.Remove(path + ".next"); err != nil && !errors.Is(err, os.ErrNotExist) {
		lock.Close()
		return nil, raft.Stable{}, 0, err
	}
	w, stable, recovered, err := openWriter(binary, path, members)
	if err != nil {
		lock.Close()
		return nil, stable, 0, err
	}
	w.lock, w.stable = lock, stable
	return w, stable, recovered, nil
}

func openWriter(binary, path string, members int) (*Writer, raft.Stable, uint64, error) {
	childIn, in, err := os.Pipe()
	if err != nil {
		return nil, raft.Stable{}, 0, err
	}
	defer childIn.Close()
	out, childOut, err := os.Pipe()
	if err != nil {
		in.Close()
		return nil, raft.Stable{}, 0, err
	}
	defer childOut.Close()
	cmd := exec.Command(binary, path)
	cmd.Stdin, cmd.Stdout, cmd.Stderr = childIn, childOut, os.Stderr
	if err := cmd.Start(); err != nil {
		in.Close()
		out.Close()
		return nil, raft.Stable{}, 0, err
	}
	childOut.Close() // Let read observe EOF if the child exits during startup.
	w := &Writer{child: cmd, in: in, out: out, binary: binary, path: path, members: members}
	stable, recovered, err := w.replay(members)
	if err != nil {
		w.closeChild()
		return nil, raft.Stable{}, 0, fmt.Errorf("replay WAL %s: %w", path, err)
	}
	return w, stable, recovered, nil
}

func (w *Writer) replay(members int) (raft.Stable, uint64, error) {
	var stable raft.Stable
	for {
		if err := w.out.SetReadDeadline(time.Now().Add(5 * time.Second)); err != nil {
			return stable, 0, err
		}
		var size uint32
		if err := binary.Read(w.out, binary.LittleEndian, &size); err != nil {
			return stable, 0, err
		}
		if size == 0 {
			var recovered uint64
			err := binary.Read(w.out, binary.LittleEndian, &recovered)
			return stable, recovered, err
		}
		if size > maxPayload {
			return stable, 0, fmt.Errorf("oversized WAL packet: %d", size)
		}
		raw := make([]byte, size)
		if _, err := io.ReadFull(w.out, raw); err != nil {
			return stable, 0, err
		}
		var r record
		if err := json.Unmarshal(raw, &r); err != nil {
			return stable, 0, err
		}
		if r.Version != 1 || r.Batch.Empty() {
			return stable, 0, errors.New("invalid WAL batch or version")
		}
		if err := stable.Apply(r.Batch, members); err != nil {
			return stable, 0, err
		}
	}
}

func (w *Writer) Save(batch raft.Batch) error {
	if w.failed {
		return errors.New("WAL writer failed; reopen and replay")
	}
	if batch.Empty() {
		return nil
	}
	if err := w.stable.Apply(batch, w.members); err != nil {
		return err
	}
	if err := w.writeBatch(batch); err != nil {
		w.failed = true
		return err
	}
	if batch.Snapshot != nil {
		w.snapshots++
		if w.snapshots == 2 {
			if err := w.reclaim(); err != nil {
				w.failed = true
				return fmt.Errorf("replace WAL: %w", err)
			}
			w.snapshots = 0
		}
	}
	return nil
}

func (w *Writer) writeBatch(batch raft.Batch) error {
	raw, err := json.Marshal(record{Version: 1, Batch: batch})
	if err != nil {
		return err
	}
	if len(raw) > maxPayload {
		return fmt.Errorf("WAL batch exceeds %d bytes", maxPayload)
	}
	deadline := time.Now().Add(5 * time.Second)
	if err := w.in.SetWriteDeadline(deadline); err != nil {
		return err
	}
	if err := w.out.SetReadDeadline(deadline); err != nil {
		return err
	}
	if err := binary.Write(w.in, binary.LittleEndian, uint32(len(raw))); err != nil {
		return err
	}
	if _, err := w.in.Write(raw); err != nil {
		return err
	}
	var ack [1]byte
	if _, err := io.ReadFull(w.out, ack[:]); err != nil {
		return err
	}
	if ack[0] != 1 {
		return errors.New("invalid WAL acknowledgment")
	}
	return nil
}

func (w *Writer) Close() {
	w.closeChild()
	w.lock.Close()
}

func (w *Writer) closeChild() {
	w.in.Close()
	w.out.Close()
	w.child.Process.Kill()
	w.child.Wait()
}
