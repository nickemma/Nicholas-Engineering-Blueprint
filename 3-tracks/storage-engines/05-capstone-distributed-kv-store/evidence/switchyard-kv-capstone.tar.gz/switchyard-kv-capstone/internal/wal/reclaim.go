package wal

import (
	"fmt"
	"os"
	"path/filepath"
	"syscall"

	"switchyard/metad/internal/raft"
)

// Keep the name locked across replacement of the data inode.
func lockWAL(path string) (*os.File, error) {
	lock, err := os.OpenFile(path+".lock", os.O_CREATE|os.O_RDWR, 0600)
	if err != nil {
		return nil, err
	}
	if err := syscall.Flock(int(lock.Fd()), syscall.LOCK_EX|syscall.LOCK_NB); err != nil {
		lock.Close()
		return nil, fmt.Errorf("lock WAL %s: %w", path, err)
	}
	return lock, nil
}

func (w *Writer) reclaim() error {
	parent := filepath.Dir(w.path)
	dir, err := os.Open(parent)
	if err != nil {
		return err
	}
	defer dir.Close()
	name := w.path + ".next"
	defer os.Remove(name)

	next, _, _, err := openWriter(w.binary, name, w.members)
	if err != nil {
		return err
	}
	defer func() {
		if next != nil {
			next.closeChild()
		}
	}()
	current := w.stable
	if err := next.writeBatch(raft.Batch{Hard: &current.Hard, Snapshot: &current.Snapshot}); err != nil {
		return err
	}
	for offset := 0; offset < len(current.Entries); offset += 16 {
		batch := raft.Batch{
			From:    current.Snapshot.Index + offset + 1,
			Entries: current.Entries[offset:min(offset+16, len(current.Entries))],
		}
		if err := next.writeBatch(batch); err != nil {
			return err
		}
	}
	if err := os.Rename(name, w.path); err != nil {
		return err
	}
	// The new writer already owns the replacement inode. Once renamed,
	// switch even if directory sync fails so the caller cannot use the old inode.
	w.closeChild()
	w.in, w.out, w.child = next.in, next.out, next.child
	next = nil
	return dir.Sync()
}
