package wal

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"switchyard/metad/internal/raft"
)

func TestReplaceWALAfterDurableSnapshot(t *testing.T) {
	binary := os.Getenv("METAD_WAL_WRITER")
	if binary == "" {
		t.Skip("build the Rust writer and set METAD_WAL_WRITER")
	}
	path := filepath.Join(t.TempDir(), "peer.klog")
	open := func() (*Writer, raft.Stable) {
		t.Helper()
		w, stable, _, err := Open(binary, path, 3)
		if err != nil {
			t.Fatal(err)
		}
		return w, stable
	}
	w, _ := open()
	save := func(batch raft.Batch) {
		t.Helper()
		if err := w.Save(batch); err != nil {
			t.Fatal(err)
		}
	}
	hard := raft.HardState{Term: 3, Vote: 2}
	entry := raft.Entry{Term: 3, Command: raft.Command{Op: "put", Key: "job", Value: strings.Repeat("x", 512)}}
	for i := 1; i <= 20; i++ {
		save(raft.Batch{Hard: &hard, From: i, Entries: []raft.Entry{entry}})
	}
	snapshot := raft.Snapshot{Index: 16, Term: 3, Data: "state-at-16"}
	save(raft.Batch{Snapshot: &snapshot})
	info, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	w.Close()
	w, restored := open()
	if restored.Snapshot != snapshot || restored.Hard != hard || len(restored.Entries) != 4 {
		t.Fatalf("snapshot with the old records present: %+v", restored)
	}
	snapshot = raft.Snapshot{Index: 17, Term: 3, Data: "state-at-17"}
	save(raft.Batch{Snapshot: &snapshot})
	snapshot = raft.Snapshot{Index: 18, Term: 3, Data: "state-at-18"}
	save(raft.Batch{Snapshot: &snapshot})
	after, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	if after.Size() >= info.Size() {
		t.Fatal("the replacement WAL did not reclaim obsolete records")
	}
	if other, _, _, err := Open(binary, path, 3); err == nil {
		other.Close()
		t.Fatal("a second writer opened the replacement generation")
	}
	// This append must reach the new inode.
	save(raft.Batch{From: 21, Entries: []raft.Entry{entry}})
	w.Close()
	w, restored = open()
	defer w.Close()
	if restored.Snapshot != snapshot || restored.Hard != hard || len(restored.Entries) != 3 ||
		restored.Entries[2] != entry {
		t.Fatalf("wrong state after reopening the replacement: %+v", restored)
	}
	t.Logf("WAL reduced from %d to %d bytes before next append; term=%d vote=%d suffix=%d",
		info.Size(), after.Size(), restored.Hard.Term, restored.Hard.Vote, len(restored.Entries))
}
