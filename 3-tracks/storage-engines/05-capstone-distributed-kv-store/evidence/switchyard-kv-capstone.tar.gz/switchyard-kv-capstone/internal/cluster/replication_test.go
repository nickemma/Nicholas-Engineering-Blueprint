package cluster

import (
	"slices"
	"testing"

	"switchyard/metad/internal/raft"
)

func TestConflictingSuffix(t *testing.T) {
	c := New(3, 7)
	c.Run(60)
	_, old := c.LatestLeader()
	write := func(id int, value string) {
		if !c.Propose(id, raft.Command{Op: "put", Key: "route", Value: value}) {
			t.Fatalf("peer %d refused %s", id, value)
		}
		c.Run(40)
	}
	write(old, "shared")
	c.Isolate(old, true)
	write(old, "isolated")
	term, leader := c.LatestLeader()
	if leader == old {
		t.Fatal("majority did not elect a leader")
	}
	write(leader, "majority")
	diverged := c.Nodes[old].Entries()
	if diverged[len(diverged)-1].Command.Value != "isolated" {
		t.Fatal("expected divergent suffix")
	}
	c.Isolate(old, false)
	c.Run(80)
	log := c.Nodes[leader].Entries()
	for _, peer := range c.Nodes[1:] {
		if !slices.Equal(peer.Entries(), log) {
			t.Fatalf("logs did not converge: %+v", peer.Entries())
		}
	}
	var values []string
	for _, entry := range log {
		if entry.Command.Op == "put" {
			values = append(values, entry.Command.Value)
		}
	}
	if !slices.Equal(values, []string{"shared", "majority"}) {
		t.Fatalf("unexpected final log: %+v", log)
	}
	t.Logf("peer %d replaced peer %d's uncommitted suffix in term %d; shared prefix retained", leader, old, term)
}

func TestMinorityCannotCommit(t *testing.T) {
	c := New(3, 7)
	c.Run(60)
	_, old := c.LatestLeader()
	before := c.Applied[old]
	c.Isolate(old, true)
	if !c.Propose(old, raft.Command{Op: "put", Key: "route", Value: "isolated"}) {
		t.Fatal("expected the old leader to accept a local proposal")
	}
	c.Run(100)
	if c.Applied[old] != before {
		t.Fatal("minority leader applied an entry")
	}
	for _, entry := range c.Committed {
		if entry.Command.Value == "isolated" {
			t.Fatal("isolated value was committed")
		}
	}
	t.Logf("isolated peer %d kept its applied index at %d", old, before)
}
