package cluster

import (
	"fmt"
	"testing"

	"switchyard/metad/internal/raft"
)

func TestLaggingPeerInstallsSnapshot(t *testing.T) {
	c := New(3, 13)
	c.Run(100)
	_, leader := c.LatestLeader()
	lagging := leader%3 + 1
	c.Isolate(lagging, true)
	for i := range 8 {
		if !c.Propose(leader, raft.Command{Op: "put", Key: "job", Value: fmt.Sprint(i)}) {
			t.Fatal("lost leader while holding a majority")
		}
		c.Run(2)
	}
	index := c.Applied[leader]
	if index <= c.Applied[lagging] {
		t.Fatal("fixture needs a lagging follower")
	}
	if err := c.Nodes[leader].Compact(index, "job=7"); err != nil {
		t.Fatal(err)
	}
	c.flush(leader)
	// A stopped peer cannot increment its term while the link is blocked.
	c.Crash(lagging)
	c.Restart(lagging)
	c.Isolate(lagging, false)
	c.Run(100)
	got := c.Nodes[lagging].Snapshot()
	if got.Index != index || got.Data != "job=7" || c.Applied[lagging] < index {
		t.Fatalf("lagging peer did not install snapshot: %+v", got)
	}
	t.Logf("lagging peer %d installed snapshot at index %d", lagging, index)
}
