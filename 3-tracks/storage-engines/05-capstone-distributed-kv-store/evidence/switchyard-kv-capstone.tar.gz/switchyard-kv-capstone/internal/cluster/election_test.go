package cluster

import (
	"testing"

	"switchyard/metad/internal/raft"
)

func TestPartitionElectsHigherTerm(t *testing.T) {
	c := New(3, 7)
	c.Run(60)
	before, old := c.LatestLeader()
	if old == 0 {
		t.Fatal("no initial leader")
	}
	c.Isolate(old, true)
	c.Run(100)
	after, elected := c.LatestLeader()
	if after <= before || elected == old || c.Nodes[old].Role() != raft.Leader {
		t.Fatalf("before=%d/%d after=%d/%d", before, old, after, elected)
	}
	c.Isolate(old, false)
	c.Run(60)
	if c.Nodes[old].Role() != raft.Follower {
		t.Fatal("old leader failed to step down")
	}
	t.Logf("term %d elected peer %d; partition elected peer %d in term %d", before, old, elected, after)
}

func TestSplitVoteRetries(t *testing.T) {
	c := New(3, 7)
	c.Isolate(1, true)
	c.Isolate(2, true)
	c.Run(24) // Everybody runs an election, but nobody can gather two votes.
	for id := 1; id <= 3; id++ {
		if c.Nodes[id].Role() != raft.Candidate {
			t.Fatalf("peer %d was %s", id, c.Nodes[id].Role())
		}
	}
	if term, _ := c.LatestLeader(); term != 0 {
		t.Fatalf("elected a leader without a quorum")
	}
	c.Isolate(1, false)
	c.Isolate(2, false)
	c.Run(100)
	term, winner := c.LatestLeader()
	if term < 2 || winner == 0 {
		t.Fatalf("failed to retry: term=%d winner=%d", term, winner)
	}
	t.Logf("three self-votes in term 1; peer %d won term %d after healing", winner, term)
}

func TestElectionStorm(t *testing.T) {
	for seed := int64(1); seed <= 100; seed++ {
		c := New(5, seed)
		c.Net.Loss, c.Net.Delay = 20, 5
		c.Run(200)
		c.Isolate(1, true)
		c.Run(200)
		c.Isolate(1, false)
		c.Net.Loss, c.Net.Delay = 0, 1
		c.Run(100)
		if _, leader := c.LatestLeader(); leader == 0 {
			t.Fatalf("seed %d did not elect a leader", seed)
		}
	}
	t.Log("checked election safety across 100 seeds")
}
