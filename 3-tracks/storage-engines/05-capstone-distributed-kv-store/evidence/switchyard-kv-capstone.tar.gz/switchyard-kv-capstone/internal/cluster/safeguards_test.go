package cluster

import (
	"testing"

	"switchyard/metad/internal/raft"
)

func TestPartialPartitionKeepsHealthyLeader(t *testing.T) {
	for _, enabled := range []bool{false, true} {
		c := New(3, 13)
		if enabled {
			for _, peer := range c.Nodes[1:] {
				peer.EnableElectionSafeguards()
			}
		}
		c.Run(100)
		term, leader := c.LatestLeader()
		lagging := leader%3 + 1
		c.Net.Block(leader, lagging, true)
		c.Net.Block(lagging, leader, true)
		c.Run(100)
		_, leaderNow := c.LatestLeader()
		if !enabled {
			if c.Nodes[leader].Term() <= term {
				t.Fatal("control did not disrupt the old leader")
			}
			t.Logf("without safeguards: original leader advanced from term %d to %d", term, c.Nodes[leader].Term())
			continue
		}
		if c.Nodes[leader].Term() != term || leaderNow != leader || c.Nodes[leader].Role() != raft.Leader {
			t.Fatalf("healthy majority lost its leader in term %d", term)
		}
		before := c.Applied[leader]
		if !c.Propose(leader, raft.Command{Op: "put", Key: "job", Value: "queued"}) {
			t.Fatal("healthy leader refused write")
		}
		c.Run(8)
		if c.Applied[leader] != before+1 {
			t.Fatal("majority did not complete the write")
		}
		t.Logf("with PreVote: majority committed in unchanged term %d", term)
	}
}

func TestLeaderStepsDownWithoutQuorum(t *testing.T) {
	c := New(3, 13)
	for _, peer := range c.Nodes[1:] {
		peer.EnableElectionSafeguards()
	}
	c.Run(100)
	term, leader := c.LatestLeader()
	c.Isolate(leader, true)
	// A contact from the previous window can permit one more window.
	c.Run(24)
	if c.Nodes[leader].Role() == raft.Leader || c.Nodes[leader].Term() != term {
		t.Fatal("isolated leader did not step down locally")
	}
	t.Log("CheckQuorum stepped down the minority leader within two windows")
}

func TestReturningFollowerDoesNotRaiseTerm(t *testing.T) {
	c := New(3, 13)
	for _, peer := range c.Nodes[1:] {
		peer.EnableElectionSafeguards()
	}
	c.Run(100)
	term, leader := c.LatestLeader()
	returning := leader%3 + 1
	c.Isolate(returning, true)
	c.Run(100)
	c.Isolate(returning, false)
	c.Run(60)
	if c.Nodes[leader].Role() != raft.Leader || c.Nodes[returning].Term() != term {
		t.Fatal("returning follower disrupted the leader")
	}
	t.Logf("returning peer recognized the leader in term %d", term)
}
