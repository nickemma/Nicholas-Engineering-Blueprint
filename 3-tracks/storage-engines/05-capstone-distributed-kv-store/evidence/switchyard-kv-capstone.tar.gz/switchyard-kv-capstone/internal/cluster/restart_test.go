package cluster

import (
	"fmt"
	"math/rand"
	"testing"

	"switchyard/metad/internal/raft"
)

func TestCrashRecoveryStorm(t *testing.T) {
	for seed := int64(1); seed <= 100; seed++ {
		c := New(3, seed)
		rng := rand.New(rand.NewSource(seed))
		c.Net.Loss, c.Net.Delay = 10, 4
		c.Run(100)
		for event := range 12 {
			id := rng.Intn(3) + 1
			if _, leader := c.LatestLeader(); leader != 0 {
				c.Propose(leader, raft.Command{Op: "put", Key: "route", Value: fmt.Sprint(event)})
			}
			c.Run(rng.Intn(12) + 1)
			c.Crash(id)
			c.Run(rng.Intn(30) + 1)
			c.Restart(id)
			c.Run(40)
		}
		c.Net.Loss, c.Net.Delay = 0, 1
		c.Run(200)
		_, leader := c.LatestLeader()
		if leader == 0 || !c.Propose(leader, raft.Command{Op: "put", Key: "route", Value: "after healing"}) {
			t.Fatalf("seed %d: no leader after healing", seed)
		}
		c.Run(160)
		last := c.Applied[leader]
		if c.Committed[last].Command.Value != "after healing" || c.Applied[1] != last ||
			c.Applied[2] != last || c.Applied[3] != last {
			t.Fatalf("seed %d: applied indexes %v", seed, c.Applied)
		}
	}
	t.Log("100 seeds preserved election and state machine safety across 1,200 peer restarts")
}
