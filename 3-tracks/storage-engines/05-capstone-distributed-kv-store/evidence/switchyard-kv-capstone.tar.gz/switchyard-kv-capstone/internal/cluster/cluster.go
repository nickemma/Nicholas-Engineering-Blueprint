// Package cluster drives the Raft core without sockets or wall-clock time.
package cluster

import (
	"fmt"

	"switchyard/metad/internal/raft"
	"switchyard/metad/internal/simnet"
)

type Cluster struct {
	Net       *simnet.Network[raft.Message]
	Nodes     []*raft.Node // slot zero is unused
	Leaders   map[uint64]int
	Committed map[int]raft.Entry
	Applied   []int
	disks     []raft.Stable
}

func New(count int, seed int64) *Cluster {
	c := &Cluster{
		Net:       simnet.New[raft.Message](seed),
		Nodes:     make([]*raft.Node, count+1),
		Leaders:   make(map[uint64]int),
		Committed: make(map[int]raft.Entry),
		Applied:   make([]int, count+1),
		disks:     make([]raft.Stable, count+1),
	}
	for id := 1; id <= count; id++ {
		c.Nodes[id] = raft.New(id, count, seed*31+int64(id))
	}
	return c
}

func (c *Cluster) flush(id int) {
	node := c.Nodes[id]
	ready := node.Take()
	if err := c.disks[id].Apply(ready.Save, len(c.Nodes)-1); err != nil {
		panic(err)
	}
	if node.Role() == raft.Leader {
		term := node.Term()
		if other := c.Leaders[term]; other != 0 && other != id {
			panic(fmt.Sprintf("term %d elected both %d and %d", term, other, id))
		}
		c.Leaders[term] = id
	}
	for _, m := range ready.Messages {
		c.Net.Send(m.From, m.To, m)
	}
	if snap := ready.Save.Snapshot; snap != nil {
		c.Applied[id] = max(c.Applied[id], snap.Index)
	}
	for _, applied := range ready.Applied {
		if entry, exists := c.Committed[applied.Index]; exists && entry != applied.Entry {
			panic(fmt.Sprintf("different commands applied at index %d", applied.Index))
		}
		c.Committed[applied.Index] = applied.Entry
		c.Applied[id] = applied.Index
	}
}

func (c *Cluster) Run(ticks int) {
	for range ticks {
		for _, d := range c.Net.Advance() {
			if node := c.Nodes[d.To]; node != nil {
				node.Step(d.Value)
				c.flush(d.To)
			}
		}
		for id, node := range c.Nodes {
			if node != nil {
				node.Tick()
				c.flush(id)
			}
		}
	}
}

func (c *Cluster) Isolate(id int, blocked bool) {
	for peer := 1; peer < len(c.Nodes); peer++ {
		if peer != id {
			c.Net.Block(id, peer, blocked)
			c.Net.Block(peer, id, blocked)
		}
	}
}

func (c *Cluster) LatestLeader() (uint64, int) {
	var latest uint64
	for term := range c.Leaders {
		latest = max(term, latest)
	}
	return latest, c.Leaders[latest]
}

func (c *Cluster) Propose(id int, command raft.Command) bool {
	_, _, accepted := c.Nodes[id].Propose(command)
	c.flush(id)
	return accepted
}

func (c *Cluster) Crash(id int) {
	c.Nodes[id] = nil
	c.Applied[id] = 0
}

func (c *Cluster) Restart(id int) {
	c.Nodes[id] = raft.Restore(id, len(c.Nodes)-1, int64(c.Net.Now*31+id), c.disks[id])
	c.Applied[id] = c.disks[id].Snapshot.Index
}
