// Package ring assigns cache keys to fixed points on a hash circle.
package ring

import (
	"crypto/sha256"
	"encoding/binary"
	"slices"
	"sort"
	"strconv"
)

type point struct {
	hash uint64
	node string
}

type Ring struct {
	points []point
}

func hash(key string) uint64 {
	sum := sha256.Sum256([]byte(key))
	return binary.BigEndian.Uint64(sum[:8])
}

func New(nodes []string, replicas int) Ring {
	var ring Ring
	nodes = slices.Clone(nodes)
	slices.Sort(nodes)
	for _, node := range slices.Compact(nodes) {
		for replica := range replicas {
			position := hash(node + "#" + strconv.Itoa(replica))
			ring.points = append(ring.points, point{hash: position, node: node})
		}
	}
	// Stable sorting gives colliding points an order independent of input order.
	sort.SliceStable(ring.points, func(i, j int) bool { return ring.points[i].hash < ring.points[j].hash })
	return ring
}

func (r Ring) Owner(key string) (string, bool) {
	if len(r.points) == 0 {
		return "", false
	}
	position := hash(key)
	next := sort.Search(len(r.points), func(i int) bool { return r.points[i].hash >= position })
	if next == len(r.points) {
		next = 0
	}
	return r.points[next].node, true
}

func Modulo(nodes []string, key string) (string, bool) {
	if len(nodes) == 0 {
		return "", false
	}
	return nodes[hash(key)%uint64(len(nodes))], true
}
