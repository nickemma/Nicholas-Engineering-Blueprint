package ring

// Cache wraps an immutable origin in this lab. Each member has its own
// memory. Reassignment can be a miss because the origin still has the value.
type Cache struct {
	ring   Ring
	shards map[string]map[string]string
}

func (c *Cache) SetNodes(nodes []string) {
	next := make(map[string]map[string]string, len(nodes))
	for _, node := range nodes {
		next[node] = c.shards[node]
		if next[node] == nil {
			next[node] = make(map[string]string)
		}
	}
	c.shards = next
	c.ring = New(nodes, 128)
}

func (c *Cache) Get(key string, origin func(string) string) string {
	owner, present := c.ring.Owner(key)
	if !present {
		return origin(key)
	}
	shard := c.shards[owner]
	value, hit := shard[key]
	if !hit {
		value = origin(key)
		shard[key] = value
	}
	return value
}
