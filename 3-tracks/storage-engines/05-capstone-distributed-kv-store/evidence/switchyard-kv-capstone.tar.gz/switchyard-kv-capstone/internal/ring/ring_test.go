package ring

import (
	"fmt"
	"testing"
)

func TestAddAndRemoveOnlyMoveAffectedKeys(t *testing.T) {
	first, expanded := New([]string{"A", "B", "C"}, 128), New([]string{"D", "C", "B", "A"}, 128)
	reordered := New([]string{"B", "C", "A"}, 128)
	moved := 0
	for i := range 10_000 {
		key := fmt.Sprintf("job/%d", i)
		old, _ := first.Owner(key)
		want, _ := reordered.Owner(key)
		got, _ := expanded.Owner(key)
		if old != want {
			t.Fatalf("input order changed %s", key)
		}
		if got != old {
			moved++
			if got != "D" {
				t.Fatalf("unaffected key %s went from %s to %s", key, old, got)
			}
		}
	}
	if moved < 1500 || moved > 3500 {
		t.Fatalf("D took an unexpected share: %d", moved)
	}
	t.Logf("add D or remove it again: %d of 10,000 keys move, all to or from D", moved)
}

func TestCacheUsesOriginOnlyForChangedOwners(t *testing.T) {
	before := []string{"A", "B", "C"}
	after := []string{"A", "B", "C", "D"}
	var cache Cache
	loads := 0
	origin := func(key string) string {
		loads++
		return "metadata for " + key
	}
	cache.SetNodes(before)
	for i := range 1000 {
		cache.Get(fmt.Sprint(i), origin)
	}
	cache.SetNodes(after)
	loads = 0
	changes := 0
	original := New(before, 128)
	for i := range 1000 {
		key := fmt.Sprint(i)
		was, _ := original.Owner(key)
		now, _ := cache.ring.Owner(key)
		if was != now {
			changes++
		}
		if value := cache.Get(key, origin); value != "metadata for "+key {
			t.Fatal("lost origin value", key, value)
		}
	}
	if changes == 0 || changes != loads {
		t.Fatalf("changed=%d cache misses=%d", changes, loads)
	}
	cache.SetNodes(nil)
	if got := cache.Get("42", origin); got != "metadata for 42" || loads != changes+1 {
		t.Fatal("failed to bypass an empty ring", got)
	}
	t.Logf("%d reassigned keys caused exactly %d cold misses", changes, changes)
}

func TestRemovingAMemberKeepsOtherKeysInPlace(t *testing.T) {
	before := New([]string{"A", "B", "C", "D"}, 128)
	after := New([]string{"A", "C", "D"}, 128)
	shifted := 0
	for i := range 1000 {
		key := fmt.Sprint(i)
		old, _ := before.Owner(key)
		now, found := after.Owner(key)
		if !found || (old != now) != (old == "B") {
			t.Fatalf("unexpected move for %s: %s to %s", key, old, now)
		}
		if old != now {
			shifted++
		}
	}
	if shifted == 0 {
		t.Fatal("no keys were owned by B")
	}
}
