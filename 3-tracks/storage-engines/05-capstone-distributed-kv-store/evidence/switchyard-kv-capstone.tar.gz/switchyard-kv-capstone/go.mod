module switchyard/metad

go 1.26

require github.com/anishathalye/porcupine v1.3.1
